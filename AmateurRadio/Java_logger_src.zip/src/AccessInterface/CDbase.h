//File		:CDbase.h
//Date		:5-25-03
//Author		:esj
//Contents	:definitions for DB access class
#include <afxtempl.h>
#include <afxole.h>
#include <dbdao.h>

#ifdef _DEBUG
#pragma comment ( lib, "ddao35d.lib" )
#else
#pragma comment ( lib, "ddao35.lib" )
#endif

#include "utillib.h"

//#define DBVERS	1
#define DBVERS	2

typedef enum
	{
	EQSLCC,
	DIRECT,
	VIABURO
	}QSLTYPE;

class LogRec
	{
	public:
		LogRec();
		void ClearRec();
		CString			RecKey;
		CString			CallSign;
		int				nContacts;
		CString			Name;
		CString			Band;
		int				BandIx;
		double			Freq;
		CString			City;
		CString			State;
		int				StateIx;
		CString			Country;
		CString			Mode;
		int				iMode;
		int				numXmit;
		CString			Class;
		int				ixClass;
		CString			Section;
		int				ixSection;
		CString			Sig_Rep;
		CString			Comment;
		COleDateTime	RecTime;
		double			UTC_Time;
	//version 2
		bool				bQSL;
		bool				bQSL_Sent;
		QSLTYPE			QSLType;
		int				XmitPower;
	};

typedef CArray<LogRec, LogRec &> LRecArray ;

class Dbase
{
	private:
		CdbDBEngine  *dbEng;
		CdbWorkspace *dbWks;
		CdbDatabase  dbsLogger;


		char			OpenName[256];
		bool			bDBok;
		CString		RawLink;

	public:
		//modified to allow this, to support DB converter
		Dbase ();	//private def. ctor disallows auto construction

		Dbase(const char *DBname);
		~Dbase();
		//access
		 
		//DB utility
		int	operator!			();
		bool  IsOk () {return bDBok;}
		bool	ChangeDB				(const char *NewN = NULL);
		bool	GetName				(CString &name);
		//ACTUALLY JUST GET FILE NAME
		void	GetNewDB				(char *Name, bool bReg = true);
		
		//converter functions
//		bool ConvertDB(char *);
		void ConvertVer();

		//create a new DB current version, empty
		bool	CreateDB (char *Name);

		void		GetAllLogRecs (long &, LRecArray *&);
		int		GetNumberofStates();
		int		GetTotal();
		LogRec	*GetRecByCallSign (CString &);
		LogRec	*GetRecByKey (CString &);
		int		GetNumContacts (CString &);
		void		PutNewLogEntry (LogRec &);
		void		EditLogEntry (LogRec &);
		void		DeleteRecbyKey (CString &);
		LRecArray* GetForeignRecs (COleDateTime &);
		LRecArray* GetRecsNewerThan (COleDateTime &);
		LRecArray* GetQSLReqs (COleDateTime &);
};//DB