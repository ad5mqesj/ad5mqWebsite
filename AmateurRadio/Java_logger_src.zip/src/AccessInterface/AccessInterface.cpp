// AccessInterface.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "AccessInterface.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

BOOL APIENTRY DllMain(HANDLE, DWORD ul_reason_for_call, LPVOID)
{
	switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
	}
	return TRUE;
}
