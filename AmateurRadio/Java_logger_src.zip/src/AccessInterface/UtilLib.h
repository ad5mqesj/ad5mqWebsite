//FILE		: UtilLib.h
//Date		: 9-6-99
//Contents	: genericly usefule functions 
//Author	: esj,ebo 

#ifndef _INC_UTILLIB
#define _INC_UTILLIB

#if _MSC_VER >= 1000
#pragma once									//	Only Include Once!
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
#error include 'afxwin.h' before including this file 
#endif

#include "TransEx.h"

typedef enum 
		{
		FatalError,
		USevereError,
		RecoverableError,
		Warning,
		Information
		}UESeverity;

typedef enum 
		{
		ufInfo,
		ufDebug,
		ufError,
		ufDataBase,
		}UFileDest;

#define	UDispDest	unsigned short
#define	UMsgBox		0x01
#define  UConsole		0x02
#define	UFile			0x08
#define	UddFMB		0x09
#define	UddFCN		0x0a

typedef struct
		{
		CString	Module;
		CString	Function;
		CString	Extra;
		}MSGSRC;

typedef struct 
		{
		UESeverity	Severity;
		UFileDest	FileDest;
		UDispDest	DispDest;
		MSGSRC		MsgSource;
		CString		Message;
		}ERRMSG;

class CUtilMessage
	{
	private :
		char _ErrorFile[256];
		char _InfoFile[256];
		char _DebugFile[256];

		BOOL WriteMsgtoFile (const char *, ERRMSG);
		CString WriteMsgtoString (ERRMSG);

	public :
		CUtilMessage  (void);
		CUtilMessage  (ERRMSG, int level = 0);
		~CUtilMessage (void);
		
		BOOL	PutMsg	(ERRMSG, int level = 0);
		BOOL	PutMsg	(UESeverity, UFileDest, MSGSRC mSrc,
							 CString message, UDispDest = UddFMB, int level = 0);

		// set the paths
		BOOL	SetFiles	 (void);   // set default log files based on system registry info
		BOOL	SetErrorFile (char *); // set the error log file
		BOOL	SetInfoFile  (char *); // set the information log file
		BOOL	SetDebugFile (char *); // set the debug log file

		// report the various file names
		const char * ErrorFile (void);
		const char * InfoFile  (void);
		const char * DebugFile (void);

		// priority leveling
		const int ErrorLevel    (void);
		const int LnfoLevel     (void);
		const int DebugLevel    (void);

		BOOL      SetErrorLevel (int);
		BOOL      SetInfoLevel  (int);
		BOOL      SetDebugLevel (int);
	};//end of CUtilMessage

typedef unsigned __int64 QWORD;

class CHiResTimer

	{

	public:

		CHiResTimer();
		~CHiResTimer();

		void Start ( void );
		void Stop  ( void );

		double ElapsedTimeInSeconds ( void );

	private:

		QWORD qwBegTime;
		QWORD qwEndTime;
		QWORD qwFrequency;
	};


CString	GenUUID							( void );
CString	GetMachineProfileString		( LPCTSTR lpszSection, LPCTSTR lpszEntry, LPCTSTR lpszDefault = NULL );
BOOL		WriteMachineProfileString	( LPCTSTR lpszSection, LPCTSTR lpszEntry, LPCTSTR lpszValue );

UINT		GetMachineProfileInt			( LPCTSTR lpszSection, LPCTSTR lpszEntry, int nDefault = 0 );
BOOL		WriteMachineProfileInt		( LPCTSTR lpszSection, LPCTSTR lpszEntry, int nValue );

#endif

