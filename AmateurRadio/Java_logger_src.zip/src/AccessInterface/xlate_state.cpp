//xlate_state.cpp
//29 Oct 2007
//implements class used to translate old state abbreviations into new 2 letter abbreviations
#include "stdafx.h"
#include "xlate_state.h"

extern void logDebug (const char* message);

xlateStates::xlateStates(char *file)
	{
	CStdioFile	cFile;
	char FName[256];
	CString s;
	int pos, ixCnt, len;

	numStates = 0;
	States = NULL;

	if (file != NULL)
		strcpy (FName,file);
	else
		sprintf (FName, ".\\States_xlate.csv");
		
	logDebug ("Entered xlateStates ctor()");

	cFile.Open (FName, CFile::modeRead|CFile::shareExclusive);
	if (cFile.m_hFile == CFile::hFileNull)
		return;
	logDebug ("Opened xlate file.");
	while (cFile.ReadString (s))
		numStates++;
	if (!numStates)
		return;

	cFile.SeekToBegin();
	States = new STAT_STRUCT[numStates];

	for (ixCnt = 0; cFile.ReadString (s) && ixCnt < numStates; ixCnt++)
		{
		len = s.GetLength();
		pos = s.Find (",");
		States[ixCnt].OldAbbr = s.Left(pos);
		States[ixCnt].OldAbbr.TrimLeft();

		s = s.Right (len - pos-1);
		s.TrimLeft();
		States[ixCnt].NewAbbr = s;
		}	
	char temps[256];
	sprintf (temps, "Found %d states.",numStates);
	logDebug (temps);
	cFile.Close();
	}//Country CTOR

xlateStates::~xlateStates()
	{
	if (States)
		delete [] States;
	States = NULL;
	numStates = 0;
	}


CString xlateStates::FindNewState (CString &OldState)
	{
	CString leftPart;
	CString returnCnt;
	char temps[256];


	sprintf (temps, "looking for %s",(LPCSTR)OldState);
	logDebug (temps);
	
	returnCnt.Empty();
	if (!numStates || !States)
		return returnCnt;
		
	
	for (int ixCnt = 0; ixCnt < numStates; ixCnt++)
		if (States[ixCnt].OldAbbr.Find (OldState) != -1)
			{
			returnCnt = States[ixCnt].NewAbbr;
			sprintf (temps, "found %s",(LPCSTR)returnCnt);
			logDebug (temps);
			break;
			}
	return returnCnt;
	}//FindNewState