//File		:CDbase.cpp
//Date		:7-28-03
//Author		:esj
//Contents	:implemantation for DB access class
#include "stdafx.h"
#include <fstream>
#include <stdio.h>
#include "CDbase.h"
#include "Transex.h"
#include "resource.h"
#include "JDate.h"

using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
extern void logDebug (const char* message);

#pragma warning (disable : 4701 4189)
LogRec::LogRec()
	{
	RecKey.Empty();
	CallSign.Empty();
	nContacts = 0;
	Name.Empty();
	Band.Empty();
	BandIx = -1;
	Freq = 0.0;
	City.Empty();
	State.Empty();
	StateIx = -1;
	Mode.Empty();
	iMode = -1;
	numXmit = 1;
	Class.Empty();
	ixClass = 0;
	Section.Empty();
	ixSection = -1;
	Sig_Rep = "5:9:9";
	Comment.Empty();
	RecTime = COleDateTime::GetCurrentTime();
	UTC_Time = GetCurrentJdTime();
	bQSL = false;
	bQSL_Sent = false;
	QSLType = (QSLTYPE)-1;
	XmitPower = 0;
	}

void LogRec::ClearRec()
	{
	RecKey.Empty();
	CallSign.Empty();
	nContacts = 1;
	Name.Empty();
	Band.Empty();
	BandIx = -1;
	Freq = 0.0;
	City.Empty();
	State.Empty();
	StateIx = -1;
	Mode.Empty();
	iMode = -1;
	numXmit = 1;
	Class.Empty();
	ixClass = 0;
	Section.Empty();
	ixSection = -1;
	Sig_Rep = "5:9:9";
	Comment.Empty();
	bQSL = false;
	bQSL_Sent = false;
	QSLType = (QSLTYPE)-1;
	XmitPower = 0;
	}

Dbase::Dbase ()
	{
	//assign workspace for converter
	try
		{
		dbEng= new CdbDBEngine;
		
		dbWks   = &(dbEng->Workspaces[0L]);
		}
	catch (...)
		{
		bDBok = false;
		}
	bDBok = false;
	memset (OpenName,0,sizeof (OpenName));
	} //std ctor for TEST ONLY - Normally not available

Dbase::Dbase (const char *name)
	{
	CdbRecordset		dbVers;
	ifstream				ifs;
	char					NewName[256];
	int					ver;

 	CUtilMessage		errmsg;
 	MSGSRC				src;
	CString				terr;


	src.Function = "Dbase - ctor";
	src.Module =	"Logger";

	strcpy (NewName, name);
	ifs.open (name, ios::in);

	if (!ifs)
		GetNewDB (NewName);
	else
		ifs.close();
	strcpy (OpenName, NewName);
	try
		{
		//open DB and connect record sets to tables
		dbEng= new CdbDBEngine;
		//MessageBox (NULL,"created engine","info",MB_OK);
		if (dbEng)
			{
			dbWks   = &(dbEng->Workspaces[0L]);
		   dbsLogger  = dbWks->OpenDatabase (NewName);
			}
		else
			{
			bDBok = false;
			return;
			}
		//check for new or old DB
		try
			{
			dbVers = dbsLogger.OpenRecordset ("LoggerDBVersion");
			}
		catch (CdbException)
			{
			//if we get here not a new style DB
			if (MessageBox (NULL,"This appears to be an old Logger data base.  Convert?",
				 "User Input",MB_YESNO|MB_SYSTEMMODAL) == IDNO)
				 {
				 bDBok = false;
				 return;
				 }
			dbsLogger.Close();
//			ConvertDB (NewName);
			return;
			}
		//if we get here version table exists
		dbVers.MoveLast();
		//get version number
		ver   =   int (dbVers.GetField("Version").lVal);
		//close
		dbVers.Close();
		//check version number
		if (ver < DBVERS)
			ConvertVer();

		bDBok = true;
		}
	catch (CdbException)
		{
		terr = "Database Error : ";
///!No Longer supported
//		terr += dbEng->Errors[0L].GetDescription();
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		sprintf (OpenName,"");
		bDBok = false;
		}
	catch (AccessViolation acv)
		{
		terr = "Access violation in Dbase - ctor.";
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		sprintf (OpenName,"");
		bDBok = false;
		}
	catch (...)
		{
		terr = "Unknown error in Dbase - ctor.";
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		sprintf (OpenName,"");
		bDBok = false;
		}
	}//ctor - by name

Dbase::~Dbase()
	{
	if (bDBok)
		{
		dbsLogger.Close();
		}
	bDBok = false;
	}//dtor
/*
bool Dbase::ConvertDB(char *Name)
	{
	CString				NewOldname;
	CdbDatabase			OldDB;


	src.Function = "Dbase - ConvertDB";
	src.Module =	"Logger";

	try
		{
		}
	catch (CdbException)
		{
		terr = "Database Error : ";
		terr += dbEng->Errors[0L].GetDescription();
		errmsg.PutMsg (VSevereError, vfError, src, terr, VFile);
		sprintf (OpenName,"");
		if (si)
			delete (si);
		if (RawPts)
			delete [] RawPts;
		if (RHdr)
			delete RHdr;
		if (bOSI)
			rstSysInfo.Close();
		if (bORaw)
			rstRawHdr.Close();
		if (bORD)
			rstRawDat.Close();
		if (bODB)
			OldDB.Close();
		bDBok = false;
		return false;
		}
	catch (AccessViolation acv)
		{
		terr = "Access violation in Dbase - ConvertDB.";
		errmsg.PutMsg (VSevereError, vfError, src, terr, VFile);
		sprintf (OpenName,"");
		bDBok = false;
		if (si)
			delete (si);
		if (bOSI)
			rstSysInfo.Close();
		if (bORaw)
			rstRawHdr.Close();
		if (bODB)
			OldDB.Close();
		return false;
		}
	return true;
	}//ConvertDB
*/
void Dbase::ConvertVer()
	{
	int				ver;
	CString			Query;
	CdbRecordset	dbVers;

 	CUtilMessage		errmsg;
 	MSGSRC				src;
	CString				terr;


	src.Function = "Dbase::ConvertVer";
	src.Module =	"Logger";


	if (!bDBok)
		return;
	try
		{
		//boolean QSL desired? (1,,0)
		Query.Format ("ALTER TABLE Log ADD COLUMN QSL INTEGER;");
		dbsLogger.Execute (Query);
		//boolean QSL Sent? (1,,0)
		Query.Format ("ALTER TABLE Log ADD COLUMN QSLSENT INTEGER;");
		dbsLogger.Execute (Query);
		//ENUM QSLTYPE	
		Query.Format ("ALTER TABLE Log ADD COLUMN QSLTYPE INTEGER;");
		dbsLogger.Execute (Query);
		//Xmit Power	
		Query.Format ("ALTER TABLE Log ADD COLUMN XmitPower INTEGER;");
		dbsLogger.Execute (Query);
		//fix version number

		//set vewrsion number
		dbVers = dbsLogger.OpenRecordset ("LoggerDBVersion");
		dbVers.MoveLast();
		//make record
		dbVers.Edit();
		//set (only) field
		dbVers.SetField ("Version",COleVariant ((long)DBVERS));
		//write
		dbVers.Update();
		//re-query to synchronize
		dbVers.MoveLast();
		ver   =   int (dbVers.GetField("Version").lVal);
		//close
		dbVers.Close();
		//No new versions yet so just return
		return;
		}
	catch (CdbException)
		{
		terr = "Database Error : ";
///!No Longer supported
//		terr += dbEng->Errors[0L].GetDescription();
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		sprintf (OpenName,"");
		bDBok = false;
		}
	catch (AccessViolation acv)
		{
		terr = "Access violation in Dbase - ConvertVer.";
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		sprintf (OpenName,"");
		bDBok = false;
		}
	return;
	}//ConvertVer

#include "DBDef.h"
bool Dbase::CreateDB (char *Name)
	{
	CdbRecordset		dbVers;
	ifstream				ifs;
	char					NewName[256];
	int					i,ver;

 	CUtilMessage		errmsg;
 	MSGSRC				src;
	CString				terr;


	src.Function = "Dbase - ctor";
	src.Module =	"Logger";

	strcpy (NewName, Name);
	//check for DB exist
	ifs.open (Name, ios::in);
	if (ifs)
		{
		ifs.close();
		if (MessageBox (NULL,"DB Already exists - Delete?","Error",MB_OKCANCEL)==IDOK)
			DeleteFile (Name);
		else
			return false;
		}
	strcpy (OpenName, NewName);
	try
		{
		//open DB and connect record sets to tables
		dbWks   = &(dbEng->Workspaces[0L]);
		dbWks->CreateDatabase (OpenName,dbLangGeneral);
	   dbsLogger  = dbWks->OpenDatabase (NewName);
		for (i = 0; i < CTables::numTables; i++)
			dbsLogger.Execute (CTables::Tables[i]);

		//set vewrsion number
		dbVers = dbsLogger.OpenRecordset ("LoggerDBVersion");
		//make record
		dbVers.AddNew();
		//set (only) field
		dbVers.SetField ("Version",COleVariant ((long)DBVERS));
		//write
		dbVers.Update();
		//re-query to synchronize
		dbVers.MoveLast();
		ver   =   int (dbVers.GetField("Version").lVal);
		//close
		dbVers.Close();

		//open record sets
		bDBok = true;
		}
	catch (CdbException)
		{
		terr = "Database Error : ";
///!No Longer supported
//		terr += dbEng->Errors[0L].GetDescription();
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		sprintf (OpenName,"");
		bDBok = false;
		}
	catch (AccessViolation acv)
		{
		terr = "Access violation in Dbase - ctor.";
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		sprintf (OpenName,"");
		bDBok = false;
		}
	return bDBok;
	}

bool Dbase::GetName (CString &name)
	{
	name = OpenName;
	return true;
	}

int Dbase::operator!()
	{
	if (bDBok)
		return (0);
	else
		return (1);
	}

void Dbase::GetNewDB (char *Name, bool bReg)
	{
/*	char			szDirectory	[ _MAX_PATH ];
	CString			strDirectory;
	CString			strSelected;
	static char		szFilter[]			=	"Access Database (*.mdb)|"	"*.mdb|" "|";


 	CUtilMessage errmsg;
 	MSGSRC		 src;
	CString		 terr;


	src.Function = "Dbase::GetNewDB()";
	src.Module =	"Logger";

	try
		{
	//MessageBox (NULL,"In get New DB","info",MB_OK);

		CChgDbDlg SelectDlg (TRUE, "mdb", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter, AfxGetApp()->m_pMainWnd);
		SelectDlg.m_ofn.lpstrTitle = "Open an Existing Database or Create a New Database";
		memset ( szDirectory, '\0', sizeof szDirectory );
		strDirectory = AfxGetApp()->GetProfileString ( "Change", "Directory", "" );
		strcpy ( szDirectory,	strDirectory	);

		SelectDlg.m_ofn.lpstrInitialDir	=	szDirectory;

	//MessageBox (NULL,"ready for open dialog","info",MB_OK);
		if ( SelectDlg.DoModal() == IDCANCEL )
			return;

		strSelected = SelectDlg.GetPathName();
		strcpy (Name, strSelected);
		if (bReg)
			{
			//check if file exists
			if ( GetFileAttributes ( strSelected ) == 0xFFFFFFFFL )
				{
				//create if not
				CreateDB (Name);
				strDirectory = strSelected.Left ( strSelected.ReverseFind ( '\\' ) );
				AfxGetApp()->WriteProfileString ( "Change", "Directory", strDirectory );
				return;
				}
			strcpy (Name, strSelected);
			strDirectory = strSelected.Left ( strSelected.ReverseFind ( '\\' ) );
			AfxGetApp()->WriteProfileString ( "Change", "Directory", strDirectory );
			}

		}//try
	catch (AccessViolation acv)
		{
		terr = "Access violation in Dbase::GetNewDB().";
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		}
	catch (CString err)
		{
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		}
	*/
	}//GetNewDB

bool Dbase::ChangeDB(const char *NewN)
	{
	char					Name[256];
	char					OldName[256];

	CdbRecordset		dbVers;
	int					ver;
	bool					bNoConv = true;

 	CUtilMessage		errmsg;
 	MSGSRC				src;
	CString				terr;


	src.Function = "Dbase::ChangeDB";
	src.Module =	"Logger";

	if (bDBok)
		{
		dbsLogger.Close();
		bDBok = false;
		}
	//get new name if nesc
	strcpy (Name, OpenName);
	strcpy (OldName, OpenName);
	if (!NewN)
		GetNewDB (Name);
	else
		strcpy (Name, NewN);
	try
		{
		//open DB and connect record sets to tables
		dbWks   = &(dbEng->Workspaces[0L]);
	   dbsLogger  = dbWks->OpenDatabase (Name);
		//check for new or old DB
		try
			{
			dbVers = dbsLogger.OpenRecordset ("LoggerDBVersion");
			bDBok = true;
			}
		catch (CdbException)
			{
			bNoConv = false;
			//if we get here not a new style DB
			if (MessageBox (NULL,"This appears to be an old Logger data-base.  Convert?",
				 "User Input",MB_YESNO|MB_SYSTEMMODAL) == IDNO)
				{
	 			dbsLogger.Close();
				bDBok = false;
				}
			dbsLogger.Close();
//			ConvertDB (Name);
			}
		if (bDBok && bNoConv)
			{ 
			//if we get here version table exists
			dbVers.MoveLast();
			//get version number
			ver   =   int (dbVers.GetField("Version").lVal);
			//close
			dbVers.Close();
			//check version number
			if (ver < DBVERS)
				ConvertVer();
			}//if we didnt convert an old one and open OK
		}
	catch (CdbException)
		{
		terr = "Attempting to open new DB - Database Error : ";
///!No Longer supported
//		terr += dbEng->Errors[0L].GetDescription();
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		bDBok = false;
		}
	catch (AccessViolation acv)
		{
		terr = "Attempting to open new DB - Access violation in Dbase::ChangeDB.";
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		bDBok = false;
		}
	//if Open failed for any reason restore old DB
	if (bDBok)
		{
		strcpy (OpenName, Name);
		//write change to registry...This should really be elsewhere!!
		WriteMachineProfileString	("Logger","CurDB",(LPCSTR)OpenName);
		return true;
		}
	if (strlen (OldName))
		::MessageBox (NULL, "Open failed - attemting to revert to old DB.",
						  "Database Error", MB_OK|MB_SYSTEMMODAL);
	else
		{
		::MessageBox (NULL, "Open failed - no old DB to revert to!",
						  "Database Error", MB_OK|MB_SYSTEMMODAL);
		return false;
		}
	try
		{
		//open DB and connect record sets to tables
		dbWks   = &(dbEng->Workspaces[0L]);
	   dbsLogger  = dbWks->OpenDatabase (OldName);
		strcpy (OpenName, OldName);
		bDBok = true;
		}
	catch (CdbException)
		{
		terr = "Attempting to re-open old DB - Database Error : ";
///!No Longer supported
//		terr += dbEng->Errors[0L].GetDescription();
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		bDBok = false;
		}
	catch (AccessViolation acv)
		{
		terr = "Attempting to re-open old DB - Access violation in Dbase::ChangeDB.";
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		bDBok = false;
		}
	return (bDBok);
	}//ChangeDB

void Dbase::GetAllLogRecs (long &num, LRecArray *&pArray)
	{
	CString				Query;
	CdbRecordset		logrec;
	LogRec				curRec;
	int					i;

 	CUtilMessage		errmsg;
 	MSGSRC				src;
	CString				terr;


	src.Function = "Dbase::GetAllLogRecs";
	src.Module =	"Logger";

	try{
		if (!bDBok)
			return;
		Query.Format ("SELECT * FROM Log ORDER by RecTime");
		logrec = dbsLogger.OpenRecordset (Query);
		logrec.MoveLast();
		num = logrec.GetRecordCount();
		if (pArray)
			delete pArray;
		pArray = NULL;
		if (!num)
			return;
		pArray = new LRecArray;
		pArray->SetSize (num);
		for (logrec.MoveFirst(), i = 0; !logrec.GetEOF(); logrec.MoveNext(), i++)
			{
			curRec.RecKey   =   CString ((LPCSTR)logrec.GetField("LogKey").bstrVal);
			curRec.CallSign =   CString ((LPCSTR)logrec.GetField("CallSign").bstrVal);
			curRec.nContacts =  int             (logrec.GetField("NumContacts").lVal);
			curRec.Name     =   CString ((LPCSTR)logrec.GetField("Name").bstrVal);
			curRec.Band     =   CString ((LPCSTR)logrec.GetField("Band").bstrVal);
			curRec.Freq     =   double          (logrec.GetField("Frequency").dblVal);
			curRec.City     =   CString ((LPCSTR)logrec.GetField("City").bstrVal);
			curRec.State    =   CString ((LPCSTR)logrec.GetField("State").bstrVal);
			curRec.Country  =   CString ((LPCSTR)logrec.GetField("Country").bstrVal);
			curRec.Mode     =   CString ((LPCSTR)logrec.GetField("Mode").bstrVal);
			curRec.numXmit  =   int             (logrec.GetField("NumXmitter").lVal);
			curRec.Class    =   CString ((LPCSTR)logrec.GetField("Class").bstrVal);
			curRec.Section  =   CString ((LPCSTR)logrec.GetField("Section").bstrVal);
			curRec.Sig_Rep  =   CString ((LPCSTR)logrec.GetField("Signal_Report").bstrVal);
			curRec.Comment  =   CString ((LPCSTR)logrec.GetField("Comment").bstrVal);
			curRec.UTC_Time =   double          (logrec.GetField("ContTime").dblVal);
			curRec.RecTime  =   COleDateTime    (logrec.GetField ("RecTime").date);
			//added at DB version 2
			curRec.bQSL		 =					  (int(logrec.GetField("QSL").lVal))?true:false;
			curRec.bQSL_Sent=					  (int(logrec.GetField("QSLSENT").lVal))?true:false;
			curRec.QSLType  =   (QSLTYPE) ((int )logrec.GetField("QSLTYPE").lVal);
			curRec.XmitPower=   int             (logrec.GetField("XmitPower").lVal);

			pArray->SetAt (i, curRec);
			}//for each record in DB

		logrec.Close();
		}//try
	catch (CdbException)
		{
		terr = "Dbase::GetAllLogRecs - Database Error : ";
///!No Longer supported
//		terr += dbEng->Errors[0L].GetDescription();
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		bDBok = false;
		}
	catch (AccessViolation acv)
		{
		terr = "Access violation in Dbase::GetAllLogRecs.";
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		bDBok = false;
		}
	}//GetAllLogRecs

int Dbase::GetNumberofStates ()
	{
	CString				Query;
	CdbRecordset		logrec;
	int					ret;

 	CUtilMessage		errmsg;
 	MSGSRC				src;
	CString				terr;


	src.Function = "Dbase::GetNumberofStates";
	src.Module =	"Logger";

	try{
		if  (!bDBok)
			return false;
		Query.Format ("SELECT DISTINCT State FROM Log WHERE State <> \"\"");
		logrec = dbsLogger.OpenRecordset (Query);
		logrec.MoveLast();
		
		ret = logrec.GetRecordCount();
		logrec.Close();
		}//try
	catch (CdbException)
		{
		terr = "Dbase::GetNumberofStates - Database Error : ";
///!No Longer supported
//		terr += dbEng->Errors[0L].GetDescription();
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		}
	catch (AccessViolation acv)
		{
		terr = "Access violation in Dbase::GetNumberofStates.";
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		}
	return ret;
	}//GetNumberofStates

int Dbase::GetTotal ()
	{
	CString				Query;
	CdbRecordset		logrec;
	int					ret;

 	CUtilMessage		errmsg;
 	MSGSRC				src;
	CString				terr;


	src.Function = "Dbase::GetTotal";
	src.Module =	"Logger";

	try{
		if  (!bDBok)
			return false;
		Query.Format ("SELECT * FROM Log");
		logrec = dbsLogger.OpenRecordset (Query);
		logrec.MoveLast();
		
		ret = logrec.GetRecordCount();
		logrec.Close();
		}//try
	catch (CdbException)
		{
		terr = "Dbase::GetTotal - Database Error : ";
///!No Longer supported
//		terr += dbEng->Errors[0L].GetDescription();
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		}
	catch (AccessViolation acv)
		{
		terr = "Access violation in Dbase::GetTotal.";
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		}
	return ret;
	}//GetTotal

LogRec *Dbase::GetRecByCallSign (CString &CallSign)
	{
	CString				Query;
	CdbRecordset		logrec;
	LogRec				*curRec = NULL;
	int					n;

 	CUtilMessage		errmsg;
 	MSGSRC				src;
	CString				terr;


	src.Function = "Dbase::GetRecByCallSign";
	src.Module =	"Logger";

	try{
		if (!CallSign.GetLength())
			return NULL;
		Query.Format ("SELECT * FROM Log WHERE CallSign = \"%s\"",CallSign);
		logrec = dbsLogger.OpenRecordset (Query);
		logrec.MoveLast();
		
		n = logrec.GetRecordCount();
		if (n)
			{
			curRec = new LogRec;
			curRec->RecKey   =   CString ((LPCSTR)logrec.GetField("LogKey").bstrVal);
			curRec->CallSign =   CString ((LPCSTR)logrec.GetField("CallSign").bstrVal);
			curRec->nContacts =  int             (logrec.GetField("NumContacts").lVal);
			curRec->Name     =   CString ((LPCSTR)logrec.GetField("Name").bstrVal);
			curRec->Band     =   CString ((LPCSTR)logrec.GetField("Band").bstrVal);
			curRec->Freq     =   double          (logrec.GetField("Frequency").dblVal);
			curRec->City     =   CString ((LPCSTR)logrec.GetField("City").bstrVal);
			curRec->State    =   CString ((LPCSTR)logrec.GetField("State").bstrVal);
			curRec->Country  =   CString ((LPCSTR)logrec.GetField("Country").bstrVal);
			curRec->Mode     =   CString ((LPCSTR)logrec.GetField("Mode").bstrVal);
			curRec->numXmit  =   int             (logrec.GetField("NumXmitter").lVal);
			curRec->Class    =   CString ((LPCSTR)logrec.GetField("Class").bstrVal);
			curRec->Section  =   CString ((LPCSTR)logrec.GetField("Section").bstrVal);
			curRec->Sig_Rep  =   CString ((LPCSTR)logrec.GetField("Signal_Report").bstrVal);
			curRec->Comment  =   CString ((LPCSTR)logrec.GetField("Comment").bstrVal);
			curRec->UTC_Time =   double          (logrec.GetField("ContTime").dblVal);
			curRec->RecTime  =   COleDateTime    (logrec.GetField ("RecTime").date);
			//added at DB version 2
			curRec->bQSL		 =				   (int(logrec.GetField("QSL").lVal))?true:false;
			curRec->bQSL_Sent=				   (int(logrec.GetField("QSLSENT").lVal))?true:false;
			curRec->QSLType  =   (QSLTYPE) ((int )logrec.GetField("QSLTYPE").lVal);
			curRec->XmitPower=   int             (logrec.GetField("XmitPower").lVal);
			}
		logrec.Close();
		}//try
	catch (CdbException)
		{
		terr = "Dbase::GetRecByCallSign - Database Error : ";
///!No Longer supported
//		terr += dbEng->Errors[0L].GetDescription();
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		}
	catch (AccessViolation acv)
		{
		terr = "Access violation in Dbase::GetRecByCallSign.";
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		}
	return curRec;
	}//GetRecByCallSign

LogRec *Dbase::GetRecByKey (CString &Key)
	{
	CString				Query;
	CdbRecordset		logrec;
	LogRec				*curRec = NULL;
	int					n;

 	CUtilMessage		errmsg;
 	MSGSRC				src;
	CString				terr;


	src.Function = "Dbase::GetRecByKey";
	src.Module =	"Logger";

	try{
		if (!Key.GetLength())
			return NULL;
		Query.Format ("SELECT * FROM Log WHERE LogKey = \"%s\"",Key);
		logrec = dbsLogger.OpenRecordset (Query);
		logrec.MoveLast();
		
		n = logrec.GetRecordCount();
		if (n)
			{
			curRec = new LogRec;
			curRec->RecKey   =   CString ((LPCSTR)logrec.GetField("LogKey").bstrVal);
			curRec->CallSign =   CString ((LPCSTR)logrec.GetField("CallSign").bstrVal);
			curRec->nContacts =  int             (logrec.GetField("NumContacts").lVal);
			curRec->Name     =   CString ((LPCSTR)logrec.GetField("Name").bstrVal);
			curRec->Band     =   CString ((LPCSTR)logrec.GetField("Band").bstrVal);
			curRec->Freq     =   double          (logrec.GetField("Frequency").dblVal);
			curRec->City     =   CString ((LPCSTR)logrec.GetField("City").bstrVal);
			curRec->State    =   CString ((LPCSTR)logrec.GetField("State").bstrVal);
			curRec->Country  =   CString ((LPCSTR)logrec.GetField("Country").bstrVal);
			curRec->Mode     =   CString ((LPCSTR)logrec.GetField("Mode").bstrVal);
			curRec->numXmit  =   int             (logrec.GetField("NumXmitter").lVal);
			curRec->Class    =   CString ((LPCSTR)logrec.GetField("Class").bstrVal);
			curRec->Section  =   CString ((LPCSTR)logrec.GetField("Section").bstrVal);
			curRec->Sig_Rep  =   CString ((LPCSTR)logrec.GetField("Signal_Report").bstrVal);
			curRec->Comment  =   CString ((LPCSTR)logrec.GetField("Comment").bstrVal);
			curRec->UTC_Time =   double          (logrec.GetField("ContTime").dblVal);
			curRec->RecTime  =   COleDateTime    (logrec.GetField ("RecTime").date);
			//added at DB version 2
			curRec->bQSL		 =				   (int(logrec.GetField("QSL").lVal))?true:false;
			curRec->bQSL_Sent=				   (int(logrec.GetField("QSLSENT").lVal))?true:false;
			curRec->QSLType  =   (QSLTYPE) ((int )logrec.GetField("QSLTYPE").lVal);
			curRec->XmitPower=   int             (logrec.GetField("XmitPower").lVal);
			}
		logrec.Close();
		}//try
	catch (CdbException)
		{
		terr = "Dbase::GetRecByKey - Database Error : ";
///!No Longer supported
//		terr += dbEng->Errors[0L].GetDescription();
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		}
	catch (AccessViolation acv)
		{
		terr = "Access violation in Dbase::GetRecByKey.";
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		}
	return curRec;
	}//GetRecByKey


int Dbase::GetNumContacts (CString &CallSign)
	{
	CString				Query;
	CdbRecordset		logrec;
	int					ret=0;

 	CUtilMessage		errmsg;
 	MSGSRC				src;
	CString				terr;


	src.Function = "Dbase::GetNumContacts";
	src.Module =	"Logger";

	try{
		Query.Format ("SELECT * FROM Log WHERE CallSign = \"%s\"",CallSign);
		logrec = dbsLogger.OpenRecordset (Query);
		logrec.MoveLast();
		
		ret = logrec.GetRecordCount();
		logrec.Close();
		}//try
	catch (CdbException)
		{
		terr = "Dbase::GetNumContacts - Database Error : ";
///!No Longer supported
//		terr += dbEng->Errors[0L].GetDescription();
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		}
	catch (AccessViolation acv)
		{
		terr = "Access violation in Dbase::GetNumContacts.";
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		}
		if (ret < 0)
			ret = 0;
	return ret;
	}//GetNumContacts

void Dbase::PutNewLogEntry (LogRec &rec)
	{
	CString				Query;
	CdbRecordset		logrec, prevrec;
	CString				Call_Rec_Back;
	UUID					MyUuid;
	unsigned char		*szUuid = NULL;

 	CUtilMessage		errmsg;
 	MSGSRC				src;
	CString				terr;


	src.Function = "Dbase::GetNumContacts";
	src.Module =	"Logger";

	try{
		//initially there is no predecessor record
		Call_Rec_Back.Empty();
		//make an ID for the current record
		UuidCreate ( &MyUuid );
		UuidToString ( &MyUuid, &szUuid );
		rec.RecKey = szUuid;
		RpcStringFree (&szUuid);
		szUuid = NULL;

		//look for a record with same call sign
		LogRec *pRec = GetRecByCallSign (rec.CallSign);
		if (pRec)
			{
			Query.Format ("SELECT * FROM Log WHERE CallSign = \"%s\"",rec.CallSign);
			prevrec = dbsLogger.OpenRecordset (Query);
			prevrec.MoveLast();
			prevrec.Edit();
			prevrec.SetField ("Call_ChainF",COleVariant (CString (rec.RecKey), VT_BSTRT));
			Call_Rec_Back  =   CString ((LPCSTR)prevrec.GetField("LogKey").bstrVal);
			prevrec.Update();
			prevrec.MoveLast();
			prevrec.Close();
			}


		logrec   = dbsLogger.OpenRecordset ("Log");
		//create a new record
		logrec.AddNew();
		if (Call_Rec_Back.GetLength())
			logrec.SetField ("Call_ChainB",COleVariant (CString (Call_Rec_Back), VT_BSTRT));
		logrec.SetField ("LogKey",COleVariant (CString (rec.RecKey), VT_BSTRT));
		logrec.SetField ("CallSign",COleVariant (CString (rec.CallSign), VT_BSTRT));
		logrec.SetField ("NumContacts",COleVariant ((long)rec.nContacts));
		logrec.SetField ("Name",COleVariant (CString (rec.Name), VT_BSTRT));
		logrec.SetField ("Band",COleVariant (CString (rec.Band), VT_BSTRT));
		logrec.SetField ("Frequency",COleVariant (rec.Freq));
		logrec.SetField ("City",COleVariant (CString (rec.City), VT_BSTRT));
		logrec.SetField ("State",COleVariant (CString (rec.State), VT_BSTRT));
		logrec.SetField ("Country",COleVariant (CString (rec.Country), VT_BSTRT));
		logrec.SetField ("Mode",COleVariant (CString (rec.Mode), VT_BSTRT));
		logrec.SetField ("NumXmitter",COleVariant ((long)rec.numXmit));
		logrec.SetField ("Class",COleVariant (CString (rec.Class), VT_BSTRT));
		logrec.SetField ("Section",COleVariant (CString (rec.Section), VT_BSTRT));
		logrec.SetField ("Signal_Report",COleVariant (CString (rec.Sig_Rep), VT_BSTRT));
		logrec.SetField ("Comment",COleVariant (CString (rec.Comment), VT_BSTRT));
		logrec.SetField ("ContTime",COleVariant (rec.UTC_Time));
		logrec.SetField ("RecTime",COleVariant (rec.RecTime));

		//added at DB version 2
		logrec.SetField ("QSL",COleVariant ((long)(rec.bQSL?1:0)));
		logrec.SetField ("QSLSENT",COleVariant ((long)(rec.bQSL_Sent?1:0)));
		logrec.SetField ("QSLTYPE",COleVariant ((long)rec.QSLType));
		logrec.SetField ("XmitPower",COleVariant ((long)rec.XmitPower));

		logrec.Update();
		logrec.MoveLast();
		//re-query
		Call_Rec_Back   =   CString ((LPCSTR)logrec.GetField("LogKey").bstrVal);
		logrec.Close();
		}//try
	catch (CdbException)
		{
		terr = "Dbase::PutNewLogEntry - Database Error : ";
///!No Longer supported
//		terr += dbEng->Errors[0L].GetDescription();
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		}
	catch (AccessViolation acv)
		{
		terr = "Access violation in Dbase::PutNewLogEntry.";
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		}
	return;
	}//PutNewLogEntry

void Dbase::EditLogEntry (LogRec &rec)
	{
	CString				Query;
	CdbRecordset		logrec, prevrec;
	CString				Call_Rec_Back;

 	CUtilMessage		errmsg;
 	MSGSRC				src;
	CString				terr;


	src.Function = "Dbase::EditLogEntry";
	src.Module =	"Logger";

	try{
		//initially there is no predecessor record
		Call_Rec_Back.Empty();

		//look for a record with same key
		LogRec *pRec = GetRecByKey (rec.RecKey);
		if (pRec)
			{
			Query.Format ("SELECT * FROM Log WHERE LogKey = \"%s\"",rec.RecKey);
			prevrec = dbsLogger.OpenRecordset (Query);
			prevrec.MoveLast();
			prevrec.Edit();
			prevrec.SetField ("CallSign",COleVariant (CString (rec.CallSign), VT_BSTRT));
			prevrec.SetField ("NumContacts",COleVariant ((long)rec.nContacts));
			prevrec.SetField ("Name",COleVariant (CString (rec.Name), VT_BSTRT));
			prevrec.SetField ("Band",COleVariant (CString (rec.Band), VT_BSTRT));
			prevrec.SetField ("Frequency",COleVariant (rec.Freq));
			prevrec.SetField ("City",COleVariant (CString (rec.City), VT_BSTRT));
			prevrec.SetField ("State",COleVariant (CString (rec.State), VT_BSTRT));
			prevrec.SetField ("Country",COleVariant (CString (rec.Country), VT_BSTRT));
			prevrec.SetField ("Mode",COleVariant (CString (rec.Mode), VT_BSTRT));
			prevrec.SetField ("NumXmitter",COleVariant ((long)rec.numXmit));
			prevrec.SetField ("Class",COleVariant (CString (rec.Class), VT_BSTRT));
			prevrec.SetField ("Section",COleVariant (CString (rec.Section), VT_BSTRT));
			prevrec.SetField ("Signal_Report",COleVariant (CString (rec.Sig_Rep), VT_BSTRT));
			prevrec.SetField ("Comment",COleVariant (CString (rec.Comment), VT_BSTRT));
			prevrec.SetField ("ContTime",COleVariant (rec.UTC_Time));
			prevrec.SetField ("RecTime",COleVariant (rec.RecTime));

			//added at DB version 2
			prevrec.SetField ("QSL",COleVariant ((long)(rec.bQSL?1:0)));
			prevrec.SetField ("QSLSENT",COleVariant ((long)(rec.bQSL_Sent?1:0)));
			prevrec.SetField ("QSLTYPE",COleVariant ((long)rec.QSLType));
			prevrec.SetField ("XmitPower",COleVariant ((long)rec.XmitPower));

			prevrec.Update();
			prevrec.MoveLast();
			prevrec.Close();
			}
		delete pRec;
		pRec = NULL;
		}//try
	catch (CdbException)
		{
		terr = "Dbase::EditLogEntry - Database Error : ";
///!No Longer supported
//		terr += dbEng->Errors[0L].GetDescription();
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		}
	catch (AccessViolation acv)
		{
		terr = "Access violation in Dbase::EditLogEntry.";
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		}
	return;
	}//EditLogEntry


void Dbase::DeleteRecbyKey (CString &RecKey)
	{
	}//DeleteRecbyKey

LRecArray * Dbase::GetForeignRecs (COleDateTime &dt)
	{
	CString				Query,day;
	CdbRecordset		logrec;
	LogRec				curRec;
	int					i,num;
	LRecArray			*pArray=NULL;

 	CUtilMessage		errmsg;
 	MSGSRC				src;
	CString				terr;


	src.Function = "Dbase::GetForeignRecs";
	src.Module =	"Logger";

	try{
		day  = dt.Format ("%m/%d/%Y");
		Query.Format ("SELECT * FROM Log WHERE Country <> \"USA\" AND RecTime > #%s#",(LPCSTR)day);
		logrec = dbsLogger.OpenRecordset (Query);
		logrec.MoveLast();
		num = logrec.GetRecordCount();
		if (pArray)
			delete pArray;
		pArray = NULL;
		if (!num)
			return NULL;
		pArray = new LRecArray;
		pArray->SetSize (num);
		for (logrec.MoveFirst(), i = 0; !logrec.GetEOF(); logrec.MoveNext(), i++)
			{
			curRec.RecKey   =   CString ((LPCSTR)logrec.GetField("LogKey").bstrVal);
			curRec.CallSign =   CString ((LPCSTR)logrec.GetField("CallSign").bstrVal);
			curRec.nContacts =  int             (logrec.GetField("NumContacts").lVal);
			curRec.Name     =   CString ((LPCSTR)logrec.GetField("Name").bstrVal);
			curRec.Band     =   CString ((LPCSTR)logrec.GetField("Band").bstrVal);
			curRec.Freq     =   double          (logrec.GetField("Frequency").dblVal);
			curRec.City     =   CString ((LPCSTR)logrec.GetField("City").bstrVal);
			curRec.State    =   CString ((LPCSTR)logrec.GetField("State").bstrVal);
			curRec.Country  =   CString ((LPCSTR)logrec.GetField("Country").bstrVal);
			curRec.Mode     =   CString ((LPCSTR)logrec.GetField("Mode").bstrVal);
			curRec.numXmit  =   int             (logrec.GetField("NumXmitter").lVal);
			curRec.Class    =   CString ((LPCSTR)logrec.GetField("Class").bstrVal);
			curRec.Section  =   CString ((LPCSTR)logrec.GetField("Section").bstrVal);
			curRec.Sig_Rep  =   CString ((LPCSTR)logrec.GetField("Signal_Report").bstrVal);
			curRec.Comment  =   CString ((LPCSTR)logrec.GetField("Comment").bstrVal);
			curRec.UTC_Time =   double          (logrec.GetField("ContTime").dblVal);
			curRec.RecTime  =   COleDateTime    (logrec.GetField ("RecTime").date);
			//added at DB version 2
			curRec.bQSL		 =					  (int(logrec.GetField("QSL").lVal))?true:false;
			curRec.bQSL_Sent=					  (int(logrec.GetField("QSLSENT").lVal))?true:false;
			curRec.QSLType  =   (QSLTYPE) ((int )logrec.GetField("QSLTYPE").lVal);
			pArray->SetAt (i, curRec);
			}//for each record in DB

		logrec.Close();
		}//try
	catch (CdbException)
		{
		terr = "Dbase::GetForeignRecs - Database Error : ";
///!No Longer supported
//		terr += dbEng->Errors[0L].GetDescription();
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		bDBok = false;
		}
	catch (AccessViolation acv)
		{
		terr = "Access violation in Dbase::GetForeignRecs.";
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		bDBok = false;
		}
	return pArray;
	}//GetForeignRecs

LRecArray * Dbase::GetRecsNewerThan (COleDateTime &dt)
	{
	CString				Query,day;
	CdbRecordset		logrec;
	LogRec				curRec;
	int					i,num;
	LRecArray			*pArray=NULL;

 	CUtilMessage		errmsg;
 	MSGSRC				src;
	CString				terr;


	src.Function = "Dbase::GetRecsNewerThan";
	src.Module =	"Logger";

	try{
		day  = dt.Format ("%m/%d/%Y");
		Query.Format ("SELECT * FROM Log WHERE RecTime >= #%s# ORDER BY CallSign",(LPCSTR)day);
		logrec = dbsLogger.OpenRecordset (Query);
		logrec.MoveLast();
		num = logrec.GetRecordCount();
		if (pArray)
			delete pArray;
		pArray = NULL;
		if (!num)
			return NULL;
		pArray = new LRecArray;
		pArray->SetSize (num);
		for (logrec.MoveFirst(), i = 0; !logrec.GetEOF(); logrec.MoveNext(), i++)
			{
			curRec.RecKey   =   CString ((LPCSTR)logrec.GetField("LogKey").bstrVal);
			curRec.CallSign =   CString ((LPCSTR)logrec.GetField("CallSign").bstrVal);
			curRec.nContacts =  int             (logrec.GetField("NumContacts").lVal);
			curRec.Name     =   CString ((LPCSTR)logrec.GetField("Name").bstrVal);
			curRec.Band     =   CString ((LPCSTR)logrec.GetField("Band").bstrVal);
			curRec.Freq     =   double          (logrec.GetField("Frequency").dblVal);
			curRec.City     =   CString ((LPCSTR)logrec.GetField("City").bstrVal);
			curRec.State    =   CString ((LPCSTR)logrec.GetField("State").bstrVal);
			curRec.Country  =   CString ((LPCSTR)logrec.GetField("Country").bstrVal);
			curRec.Mode     =   CString ((LPCSTR)logrec.GetField("Mode").bstrVal);
			curRec.numXmit  =   int             (logrec.GetField("NumXmitter").lVal);
			curRec.Class    =   CString ((LPCSTR)logrec.GetField("Class").bstrVal);
			curRec.Section  =   CString ((LPCSTR)logrec.GetField("Section").bstrVal);
			curRec.Sig_Rep  =   CString ((LPCSTR)logrec.GetField("Signal_Report").bstrVal);
			curRec.Comment  =   CString ((LPCSTR)logrec.GetField("Comment").bstrVal);
			curRec.UTC_Time =   double          (logrec.GetField("ContTime").dblVal);
			curRec.RecTime  =   COleDateTime    (logrec.GetField ("RecTime").date);
			//added at DB version 2
			curRec.bQSL		 =					  (int(logrec.GetField("QSL").lVal))?true:false;
			curRec.bQSL_Sent=					  (int(logrec.GetField("QSLSENT").lVal))?true:false;
			curRec.QSLType  =   (QSLTYPE) ((int )logrec.GetField("QSLTYPE").lVal);
			pArray->SetAt (i, curRec);
			}//for each record in DB

		logrec.Close();
		}//try
	catch (CdbException)
		{
		terr = "Dbase::GetRecsNewerThan - Database Error : ";
///!No Longer supported
//		terr += dbEng->Errors[0L].GetDescription();
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		bDBok = false;
		}
	catch (AccessViolation acv)
		{
		terr = "Access violation in Dbase::GetRecsNewerThan.";
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		bDBok = false;
		}
	return pArray;
	}//GetRecsNewerThan


LRecArray * Dbase::GetQSLReqs (COleDateTime &dt)
	{
	CString				Query,day;
	CdbRecordset		logrec;
	LogRec				curRec;
	int					i,num;
	LRecArray			*pArray=NULL;

 	CUtilMessage		errmsg;
 	MSGSRC				src;
	CString				terr;


	src.Function = "Dbase::GetQSLReqs";
	src.Module =	"Logger";

	try{
		day  = dt.Format ("%m/%d/%Y");
		//NOTE: ONLY MS-Jet uses * standard is to use % instead
		Query.Format ("SELECT * FROM Log WHERE (Comment LIKE \"*QSL*\" OR QSL = 1) AND RecTime > #%s#",(LPCSTR)day);
		logrec = dbsLogger.OpenRecordset (Query);
		logrec.MoveLast();
		num = logrec.GetRecordCount();
		if (pArray)
			delete pArray;
		pArray = NULL;
		if (!num)
			return NULL;
		pArray = new LRecArray;
		pArray->SetSize (num);
		for (logrec.MoveFirst(), i = 0; !logrec.GetEOF(); logrec.MoveNext(), i++)
			{
			curRec.RecKey   =   CString ((LPCSTR)logrec.GetField("LogKey").bstrVal);
			curRec.CallSign =   CString ((LPCSTR)logrec.GetField("CallSign").bstrVal);
			curRec.nContacts =  int             (logrec.GetField("NumContacts").lVal);
			curRec.Name     =   CString ((LPCSTR)logrec.GetField("Name").bstrVal);
			curRec.Band     =   CString ((LPCSTR)logrec.GetField("Band").bstrVal);
			curRec.Freq     =   double          (logrec.GetField("Frequency").dblVal);
			curRec.City     =   CString ((LPCSTR)logrec.GetField("City").bstrVal);
			curRec.State    =   CString ((LPCSTR)logrec.GetField("State").bstrVal);
			curRec.Country  =   CString ((LPCSTR)logrec.GetField("Country").bstrVal);
			curRec.Mode     =   CString ((LPCSTR)logrec.GetField("Mode").bstrVal);
			curRec.numXmit  =   int             (logrec.GetField("NumXmitter").lVal);
			curRec.Class    =   CString ((LPCSTR)logrec.GetField("Class").bstrVal);
			curRec.Section  =   CString ((LPCSTR)logrec.GetField("Section").bstrVal);
			curRec.Sig_Rep  =   CString ((LPCSTR)logrec.GetField("Signal_Report").bstrVal);
			curRec.Comment  =   CString ((LPCSTR)logrec.GetField("Comment").bstrVal);
			curRec.UTC_Time =   double          (logrec.GetField("ContTime").dblVal);
			curRec.RecTime  =   COleDateTime    (logrec.GetField ("RecTime").date);
			//added at DB version 2
			curRec.bQSL		 =					  (int(logrec.GetField("QSL").lVal))?true:false;
			curRec.bQSL_Sent=					  (int(logrec.GetField("QSLSENT").lVal))?true:false;
			curRec.QSLType  =   (QSLTYPE) ((int )logrec.GetField("QSLTYPE").lVal);
			pArray->SetAt (i, curRec);
			}//for each record in DB

		logrec.Close();
		}//try
	catch (CdbException)
		{
		terr = "Dbase::GetQSLReqs - Database Error : ";
///!No Longer supported
//		terr += dbEng->Errors[0L].GetDescription();
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		bDBok = false;
		}
	catch (AccessViolation acv)
		{
		terr = "Access violation in Dbase::GetQSLReqs.";
		errmsg.PutMsg (USevereError, ufError, src, terr, UFile);
		if (logrec)
			logrec.Close();
		bDBok = false;
		}
	return pArray;
	}//GetQSLReqs
