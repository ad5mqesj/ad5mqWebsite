//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AccessInterface.RC
//

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define IDD_CHG_DB_DLG                  23015
#define IDC_RECENT_DB_LIST              55353
#define IDC_TEXT_STRING                 55354

#define _APS_NEXT_RESOURCE_VALUE	2000
#define _APS_NEXT_CONTROL_VALUE		2000
#define _APS_NEXT_SYMED_VALUE		2000
#define _APS_NEXT_COMMAND_VALUE		32771
#endif
#endif
