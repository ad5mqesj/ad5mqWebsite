//File		: jdate.cpp
//Date		: 2-6-96
//Contents	: DAAAC 4.0 (Dave) Julian Date time class	
//Author		: Ed Johnson - Borrowed heavily from Cass' jdate.c

#include <math.h>
#include <afxwin.h>
#include <afxdisp.h>
#include "jdate.h"
#include <rpc.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//here are the class functions

long JDATE::gd ( int month, int day, int year )

{
int days[13] = { 0,0,-31,306,275,245,214,184,153,122,92,61,31 };
int bias[13] = { 0,1,1,0,0,0,0,0,0,0,0,0,0 };
long years, date;

    years = year - bias[month];

    date = ( ( years / 100 ) * 146097l ) / 4
         + ( ( years % 100 ) *   1461 ) / 4
         - days[month]
         + day;

    return ( date );
}

void JDATE::cd ( long gd, int * month, int * day, int * year )

{
static int bias[12] = { 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, -10, -10 };
long       x, y, m, d;

    x = 4 * ( gd + 306 ) - 1;
    y = ( x / 146097l ) * 100;
    d = ( x % 146097l ) /   4;

    x = 4 * d + 3;
    y = ( x / 1461 )     + y;
    d = ( x % 1461 ) / 4 + 1;

    x = 5 * d - 3;
    m = ( x / 153 )     + 1;
    d = ( x % 153 ) / 5 + 1;

    *month = ( int ) ( m + bias[m-1] );
    *day   = ( int ) ( d );
    *year  = ( int ) ( y + m/11 );
}

double JDATE::jd ( int Mo, int Dy, int Year, int hh, int mm, int ss, int ms )

{
    return ( ( double ) gd ( Mo, Dy, Year ) /* Gregorian Day Index        */

           + ( double ) hh /       24.0     /* Hours Fraction             */
           + ( double ) mm /     1440.0     /* Minutes Fraction           */
           + ( double ) ss /    86400.0     /* Seconds Fraction           */
           + ( double ) ms / 86400000.0     /* Milliseconds Fraction      */

           + 1721424.5 );                   /* Julian Day Number Constant */
}

void JDATE::Year2DST ( int Year, double * Beg, double * End )

{
int Mo, Dy;

/*
 *  Compute the first day of Daylight Savings Time for the specified Year
 *
 *  Note:   Remember that the gd() of the last day of the prior month is the
 *          same as the gd() of day zero of the current month.  The expression
 *          Lo = gd ( 5, 0, Year ), or day zero of May, returns the Gregorian
 *          Day Index of April 30 of the specified year.  By taking advantage
 *          of the fact that the Gregorian Day Index, modulo 7, returns a value
 *          of 0 - 6 where 0 = Sunday, the expression "Lo = gd(5,0,Year)/7*7;"
 *          effectively truncates the date to the last sunday of the prior
 *          month (April).
 *
 *          The expression "Lo = gd(4,0,Year)/7*7 + 7;" takes advantage of the
 *          fact that the first Sunday of the current month occurs 7 days after
 *          the last Sunday of the prior month.
 *
 *          It starts at 2:00 a.m. (3:00 a.m. DST)
 *          It ends   at 1:00 a.m. (2:00 a.m. DST)
 */
    if ( Year < 1987 ) {                /*  Last  Sunday of April           */

        cd ( gd ( 5, 0, Year ) / 7 * 7, &Mo, &Dy, &Year );

        * Beg = jd ( Mo, Dy, Year, 2, 0, 0, 0 );

    } else {                            /*  First Sunday of April           */

        cd ( gd ( 4, 0, Year ) / 7 * 7 + 7, &Mo, &Dy, &Year );

        * Beg = jd ( Mo, Dy, Year, 2, 0, 0, 0 );
    }


/*
 *  Compute the last day of Daylight Savings Time for the specified Year
 */
    cd ( gd ( 11, 0, Year ) / 7 * 7, &Mo, &Dy, &Year );

    * End = jd ( Mo, Dy, Year, 1, 0, 0, 0 );
}

/*******************************************************************************
*                                                                              *
*    The New Grolier Electronic Encyclopedia (TM)                              *
*   (c) 1991 Grolier Electronic Publishing, Inc.                               *
*                                                                              *
*   Daylight Saving Time                                                       *
*                                                                              *
*    Daylight Saving Time (DST) provides more usable hours of daylight for     *
*   human activities by setting clocks ahead one hour in the spring.           *
*   Although the total amount of daylight remains the same, more daylight      *
*   hours are allowed for outdoor work and recreation in the late afternoon    *
*   and evening.  Daylight Saving Time can also reduce power requirements      *
*   for lighting.  In most parts of the United States, year-round Daylight     *
*   Saving Time was adopted during World War II.  Now it is in effect only     *
*   during that part of the year when daylight hours are the longest.          *
*   Congress fixed this period as extending, as of 1987, from the first        *
*   (previously the last) Sunday in April to the last Sunday in October.       *
*   Daylight Saving Time was extended during 1974 and 1975 because of the      *
*   U.S. energy crisis.                                                        *
*                                                                              *
*******************************************************************************/

double JDATE::Now ( void )

{
double Time;
SYSTEMTIME	S; 

  //THIS IS OPERATING SYSTEM DEPENDANT!!!
  GetSystemTime (&S);

/*
 *  Convert the integer dates and times to the floating point Julian Day Number
 */
    Time = jd (S.wMonth, S.wDay, S.wYear, S.wHour, S.wMinute,
					S.wSecond, S.wMilliseconds);

    return ( Time );
}

void JDATE::JD2GMT ( double JD,
              int * Mo, int * Dy, int * Year,
              int * hh, int * mm, int * ss, int * ms )

{
long   time;
double GD;

/*
 *  Convert the Julian Day Number to the Gregorian Day Number
 */
    GD = JD - 1721424.5;                /* Julian Day Number Constant   */

/*
 *  Convert the Gregorian Day to the Gregorian Calendar Month, Day and Year
 */
    cd ( ( long ) GD, Mo, Dy, Year );   /* Gregorian Day Index          */

/*
 *  Extract the Gregorian Day Fraction ( 0.0 <= fraction < 1.0 ) and convert
 *  it into Milliseconds per Day:
 *
 *  Milliseconds per Day = Milliseconds per Second
 *                       * Seconds      per Minute
 *                       * Minutes      per Hour
 *                       * Hours        per Day
 *
 *  1000 * 60 * 60 * 24 = 86400000
 *
 *  ( 0 <= time < 86400000 )
 */
    time = ( long ) ( ( GD - ( double ) ( ( long ) GD ) ) * 86400000.0 + 0.5 );

/*
 *  Convert the Milliseconds to Hours, Minutes, Seconds and Milliseconds:
 *
 *  Unit = mod ( Milliseconds / Milliseconds per Unit, Units )
 */
    * hh = ( int ) ( ( time /  3600000L ) %   24L );    /* Hours        */
    * mm = ( int ) ( ( time /    60000L ) %   60L );    /* Minutes      */
    * ss = ( int ) ( ( time /     1000L ) %   60L );    /* Seconds      */
    * ms = ( int ) ( ( time /        1L ) % 1000L );    /* Milliseconds */
}

/*******************************************************************
*	Convert From Civil COleDateTime to JDate GMT Julian Day Number  *
*******************************************************************/

JDate JDATE::CvtCOleDateTime ( COleDateTime Time )

	{
	double beg, end, Civil, GMT;

	if ( Time.GetStatus() != COleDateTime::valid )
		return 0.0;

	//	Time.m_dt is a double with 0.0 = 00:00:00 12/30/1899
	//	The Julian Day Number offset for this is 2,415,018.5

	Civil = Time.m_dt + 2415018.5;	//	Convert COleDateTime into JDate

   // Compensate for Daylight Savings Time

	//	! Warning ! There is 1 hour per year where this will not work!
	//	On the last Sunday in October, 2:00 a.m MDT becomes 1:00 a.m. MST.
	//	The COleDateTime for this period does not distinguish between
	//	MDT and MST during this period.

   if ( _daylight )
      {
      Year2DST ( Time.GetYear(), &beg, &end );
      if ( Civil >= beg && Civil < end )
         {
         Civil -= 1.0 / 24.0;
         }
      }

   // Compensate for GMT:  _timezone is long offset in seconds

   GMT = Civil + ( ( double ) _timezone / 86400.0 );

	return GMT;
	}
	
COleDateTime CurrentGmtTime ( void )

   {
   SYSTEMTIME stSystemTime;

   GetSystemTime ( &stSystemTime );

   return COleDateTime ( stSystemTime );
   }

/******************************************************
*	Convert from GMT (UTC) COleDateTime to Civil Time  *
******************************************************/

COleDateTime ConvertGmtTime ( COleDateTime OleGmtTime )

   {
   int                     nMonth, nDay, nYear, nHour, nMinute, nSecond, nMilliseconds;
   long                    ixGregorianDay;
   double                  JulianDay;
   JDATE                   Jd;
   TIME_ZONE_INFORMATION   TimeZoneInfo;
   SYSTEMTIME              stGmtTime, stLocTime;
	DWORD							dErr, dwVersion;
	CString terr;
	LPVOID lpMsgBuf;

   // Convert to SYSTEMTIME
	dwVersion = GetVersion();
   dErr = GetTimeZoneInformation ( &TimeZoneInfo );
	///!!!----------------HACK ALERT------------------
	//debug only!!! if used send error to log
	if (dErr == -1)
		{
		FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_SYSTEM,
							NULL,GetLastError(),MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), 
							(LPTSTR) &lpMsgBuf,0,NULL);
		terr.Format("Error %s from GetTimeZoneInformation!\n", lpMsgBuf);
		MessageBox (NULL, terr, "System Error", MB_OK);
		}

   JulianDay = OleGmtTime.m_dt + 2415018.5;

	if (dwVersion >= 0x80000000)
		{
		JulianDay -= (double)TimeZoneInfo.Bias / (60.0 * 24.0);
		if (dErr == TIME_ZONE_ID_DAYLIGHT)
			JulianDay -= 1.0/24.0;
		}
	//	Convert to GMT (UTC) SYSTEMTIME Structure

   Jd.JD2GMT ( JulianDay, &nMonth, &nDay, &nYear, &nHour, &nMinute, &nSecond, &nMilliseconds );

   ixGregorianDay = ( long ) ( JulianDay - 1721424.5 );

   stGmtTime.wYear         = ( WORD ) nYear;
   stGmtTime.wMonth        = ( WORD ) nMonth;
   stGmtTime.wDayOfWeek    = ( WORD ) ( ixGregorianDay % 7 );
   stGmtTime.wDay          = ( WORD ) nDay;
   stGmtTime.wHour         = ( WORD ) nHour;
   stGmtTime.wMinute       = ( WORD ) nMinute;
   stGmtTime.wSecond       = ( WORD ) nSecond;
   stGmtTime.wMilliseconds = ( WORD ) nMilliseconds;

   // Convert to Local Time

	if (dwVersion < 0x80000000)
	   SystemTimeToTzSpecificLocalTime ( &TimeZoneInfo, &stGmtTime, &stLocTime );
	else
		stLocTime = stGmtTime;
   return COleDateTime ( stLocTime );
   }

//	Get the Current GMT Time

JDate GetCurrentJdTime ( void )

	{
	TIMESTAMP_STRUCT	stTimeStamp		= GetCurrentTimeStamp();
	JDate					jdCurrentTime	= TimeStampToJulianDay ( stTimeStamp );

	return jdCurrentTime;

	}	//	GetCurrentJdTime()

TIMESTAMP_STRUCT GetCurrentTimeStamp ( void )

   {
   TIMESTAMP_STRUCT stTimeStamp;
   SYSTEMTIME       stSystemTime;

	//	Get Universal Coordinated Time (UTC) - Equivalent to Greenwich Mean Time (GMT)

   GetSystemTime ( &stSystemTime );

	//	See:  "Extended C Data Types" for TIMESTAMP_STRUCT Definition

   stTimeStamp.year     = stSystemTime.wYear;
   stTimeStamp.month    = stSystemTime.wMonth;
   stTimeStamp.day      = stSystemTime.wDay;
   stTimeStamp.hour     = stSystemTime.wHour;
   stTimeStamp.minute   = stSystemTime.wMinute;
   stTimeStamp.second   = stSystemTime.wSecond;
   stTimeStamp.fraction = stSystemTime.wMilliseconds * 1000000UL;	//	Billionths of a second

   return stTimeStamp;

   }	//	GetCurrentTimeStamp()

//	Convert the JDate Date and Time into a TIMESTAMP_STRUCT

TIMESTAMP_STRUCT JDateToTimeStamp ( JDate jdDateTime )

	{
	TIMESTAMP_STRUCT	stTimeStamp;
	JDATE					Jd;
	int					MM, DD, YY, hh, mm, ss, ms;

	Jd.JD2GMT ( jdDateTime, &MM, &DD, &YY, &hh, &mm, &ss, &ms );

//	typedef struct tagTIMESTAMP_STRUCT
//	{
//		SQLSMALLINT		year;
//		SQLUSMALLINT	month;
//		SQLUSMALLINT	day;
//		SQLUSMALLINT	hour;
//		SQLUSMALLINT	minute;
//		SQLUSMALLINT	second;
//		SQLUINTEGER		fraction;
//	} TIMESTAMP_STRUCT;

	//	See:  "Extended C Data Types" for TIMESTAMP_STRUCT Definition

	stTimeStamp.year     = ( SQLSMALLINT	) YY;
	stTimeStamp.month    = ( SQLUSMALLINT	) MM;
	stTimeStamp.day      = ( SQLUSMALLINT	) DD;
	stTimeStamp.hour     = ( SQLUSMALLINT	) hh;
	stTimeStamp.minute   = ( SQLUSMALLINT	) mm;
	stTimeStamp.second   = ( SQLUSMALLINT	) ss;
	stTimeStamp.fraction = ( SQLUINTEGER	) ( ms * 1000000UL );	//	Billionths of a second

	return stTimeStamp;

	}	//	JDateToTimeStamp()
CTime TimeStampToCTime ( TIMESTAMP_STRUCT &stGmtTimeStamp )

	{
	JDATE Jd;
	long lDays;

	// Compute Days Since January 1, 1970

	lDays = Jd.gd ( stGmtTimeStamp.month, stGmtTimeStamp.day, stGmtTimeStamp.year ) - 719163;

	// Compute Seconds Since January 1, 1970

	long lTime = lDays                 * 86400L  // days    * seconds/day
				  + stGmtTimeStamp.hour   *  3600L  // hours   * seconds/hour
				  + stGmtTimeStamp.minute *    60L  // minutes * seconds/minute
				  + stGmtTimeStamp.second;          // seconds

// printf ( "lTime = %s\n", CTime ( lTime ).FormatGmt ( "%H:%M:%S %m/%d/%Y" ) );

	// Convert to CString

	return CTime ( lTime );
	}

COleDateTime TimeStampToCOleDateTime ( TIMESTAMP_STRUCT &stGmtTimeStamp )

   {
   JDATE       Jd;
   long        ixGregorianDay;
   SYSTEMTIME  stGmtTime;

   ixGregorianDay = Jd.gd ( stGmtTimeStamp.month, stGmtTimeStamp.day, stGmtTimeStamp.year );

   stGmtTime.wYear         = ( WORD ) stGmtTimeStamp.year;
   stGmtTime.wMonth        = ( WORD ) stGmtTimeStamp.month;
   stGmtTime.wDayOfWeek    = ( WORD ) ( ixGregorianDay % 7 );
   stGmtTime.wDay          = ( WORD ) stGmtTimeStamp.day;
   stGmtTime.wHour         = ( WORD ) stGmtTimeStamp.hour;
   stGmtTime.wMinute       = ( WORD ) stGmtTimeStamp.minute;
   stGmtTime.wSecond       = ( WORD ) stGmtTimeStamp.second;
   stGmtTime.wMilliseconds = ( WORD ) ( stGmtTimeStamp.fraction / 1000000UL );

   return COleDateTime ( stGmtTime );
   }

double TimeStampToJulianDay ( TIMESTAMP_STRUCT &stGmtTimeStamp )

   {

   COleDateTime OleGmtTime ( TimeStampToCOleDateTime ( stGmtTimeStamp ) );

   return OleGmtTime.m_dt + 2415018.5;
   }
