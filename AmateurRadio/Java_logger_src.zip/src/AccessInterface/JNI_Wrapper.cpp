#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include "ad5mq_AccessImport.h"
#include "CDbase.h"
#include "xlate_state.h"

#ifdef _WIN32
#pragma warning (disable : 4018 4267)
#endif

Dbase *pDbase;

// A reference to the JVM is cached on library instantiation to allow a callback to occur
// into the Java code
JavaVM *cached_vm = NULL;

// Log4J object reference

jobject m_loggerObj = NULL;
jmethodID jni_logInfoMethod = NULL;
jmethodID jni_logDebugMethod = NULL;
jmethodID jni_logErrorMethod = NULL;


/**
 * This function is called on library load. It caches a reference to the current VM
 * The return value indicates that JNI Version 1.4 is required, as this DLL uses the NIO
 * ByteBuffer capability added as part of release 1.4.
 */
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *) 
{
	cached_vm = vm;
	return JNI_VERSION_1_4;
}

/**
 * This function is called on library unload. Make sure that any GlobalRefs are destroyed
 * before the VM is completely unloaded to avoid unpleasant surprises.
 */
JNIEXPORT void JNICALL JNI_OnUnLoad(JavaVM *vm, void *) 
{
	JNIEnv *env;
	if (m_loggerObj != NULL)  
	{
		if (0 == vm->GetEnv((void**)&env, JNI_VERSION_1_4)) 
		{
			env->DeleteGlobalRef( m_loggerObj );
		}
	}
}

/**
 * Logging utility methods - sends logging output to Log4J
 *
 **/
void initLogger(JNIEnv *env, jobject loggerObj)
{
	// get the loggerObj passed in and create a GlobalRef that can be used by other methods
	jclass clazz = env->GetObjectClass(loggerObj);
	jni_logInfoMethod = env->GetMethodID(clazz, "info", "(Ljava/lang/Object;)V");
	jni_logDebugMethod = env->GetMethodID(clazz, "debug", "(Ljava/lang/Object;)V");
	jni_logErrorMethod = env->GetMethodID(clazz, "error", "(Ljava/lang/Object;)V");

	if (m_loggerObj != NULL)  
		{
		env->DeleteGlobalRef( m_loggerObj );
		}
	m_loggerObj = env->NewGlobalRef( loggerObj );
}

void log (const char* message, jmethodID logMethod)
{
	JNIEnv *env;
	if (0 == cached_vm->AttachCurrentThread((void **)&env, NULL)) {
		if ((m_loggerObj != NULL) && (logMethod != NULL))  {
			env->CallVoidMethod(m_loggerObj, logMethod, env->NewStringUTF(message));
		}
	}
}

extern void logInfo (const char* message)
{
	log(message, jni_logInfoMethod);
}
extern void logDebug (const char* message)
{
	log(message, jni_logDebugMethod);
}
extern void logError (const char* message)
{
	log(message, jni_logErrorMethod);
}

#ifdef _WIN32
/*
 * Windows Error Exception utility function
 */
void ThrowWin32Error(JNIEnv * env)
{    
	const char * lpMsgBuf;
    LONG  error = GetLastError();
    FormatMessage ( FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_SYSTEM,
					NULL,                    
					error,                    
					MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
					(LPTSTR) &lpMsgBuf,
					0,
					NULL);
    jclass newExcCls=env->FindClass("java/lang/Exception");
    if (newExcCls!=NULL )
		{
       env->ThrowNew(newExcCls, lpMsgBuf);
		}    // Free the buffer.
    LocalFree ((void *)lpMsgBuf);
}

#endif
/*
 * Class:     ad5mq_AccessImport
 * Method:    AccessOpen
 * Signature: (Lorg/apache/log4j/Logger;Ljava/lang/String;)Z
 */
JNIEXPORT jboolean JNICALL Java_ad5mq_AccessImport_AccessOpen
  (JNIEnv *env, jobject, jobject  loggerObj, jstring name)
  {
  const char *str = env->GetStringUTFChars(name, 0);
	jboolean ret = 0;
	try
		{	
		//call this here since we have to open the db before doing anything else
		initLogger(env, loggerObj);
		
		logInfo("attempting to open database ");
		pDbase = new Dbase(str);
		ret = (pDbase->IsOk()?1:0);
		}
	catch (...)
		{
		logError ("Failed to open db!"); 
		}
	logInfo("Database opened.");
	env->ReleaseStringUTFChars(name, str);
	return ret;
  }//AccessOpen

/*
 * Class:     ad5mq_AccessImport
 * Method:    AccessClose
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_ad5mq_AccessImport_AccessClose (JNIEnv *, jobject)
	{
	if (pDbase)
		delete pDbase;
	pDbase = NULL;
	logInfo("Database closed.");
	}//AccessClose
	
/*
 * Class:     ad5mq_AccessImport
 * Method:    GetAllRecs
 * Signature: ()Ljava/util/Vector;
 */
JNIEXPORT jobject JNICALL Java_ad5mq_AccessImport_GetAllRecs (JNIEnv *env, jobject)
	{
   LRecArray *plogrecs=NULL;
	LogRec Rec;
	long num=0;
	char message[256];

	logDebug ("Checking for null pDbase");
   if (!pDbase)
      {
      logError ("Target db not open.");
      return 0;
      }
	logDebug ("calling pDbase->getalllogrecs");
	pDbase->GetAllLogRecs (num, plogrecs);
   if (num <= 0)
      {
      logError ("No records found in target db.");
      return 0;
      }
	sprintf (message,"called pDbase->getalllogrecs got %d recs",num);
	logDebug (message);
	
   jclass clsvec = env->FindClass("java/util/Vector");
	jmethodID vecconst = env->GetMethodID(clsvec,"<init>","()V");
   jmethodID mid = env->GetMethodID( clsvec, "addElement", "(Ljava/lang/Object;)V");
	jmethodID jsize = env->GetMethodID( clsvec, "size", "()I");

   jclass clsdbc = env->FindClass("ad5mq/dbContact");
   jmethodID dbcConst = env->GetMethodID(clsdbc,"<init>","()V");

	jclass clsTstmp = env->FindClass ("java/sql/Timestamp");
	jmethodID tsCstr = env->GetMethodID (clsTstmp, "<init>","(J)V");
	xlateStates *statXlt = new xlateStates(NULL);
	
	jfieldID fid; 
	jstring jstr;
   jdouble jdbl;
   jint    jnt;
   extern double GetCurrentJdTime();
   double da = GetCurrentJdTime();

   jclass retv = (jclass)env->NewObject(clsvec, vecconst);
   for (int i = 0; i < num; i++)
      {
		Rec = plogrecs->GetAt (i);
      jclass JdbC = (jclass)env->NewObject(clsdbc, dbcConst);
		
		fid = env->GetFieldID (clsdbc, "Key", "Ljava/lang/String;");
      jstr = env->NewStringUTF ((LPCSTR)Rec.RecKey);
		env->SetObjectField (JdbC, fid, jstr);

		fid = env->GetFieldID (clsdbc, "CallSign", "Ljava/lang/String;");
      jstr = env->NewStringUTF ((LPCSTR)Rec.CallSign);
		env->SetObjectField (JdbC, fid, jstr);

		fid = env->GetFieldID (clsdbc, "Name", "Ljava/lang/String;");
      jstr = env->NewStringUTF ((LPCSTR)Rec.Name);
		env->SetObjectField (JdbC, fid, jstr);

		fid = env->GetFieldID (clsdbc, "City", "Ljava/lang/String;");
      jstr = env->NewStringUTF ((LPCSTR)Rec.City);
		env->SetObjectField (JdbC, fid, jstr);

		fid = env->GetFieldID (clsdbc, "State", "Ljava/lang/String;");
		if (Rec.Country.Find ("USA") != -1)
	      jstr = env->NewStringUTF ((LPCSTR)statXlt->FindNewState(Rec.State));
		else
	      jstr = env->NewStringUTF ((LPCSTR)Rec.State);
		env->SetObjectField (JdbC, fid, jstr);

		fid = env->GetFieldID (clsdbc, "Country", "Ljava/lang/String;");
      jstr = env->NewStringUTF ((LPCSTR)Rec.Country);
		env->SetObjectField (JdbC, fid, jstr);

		fid = env->GetFieldID (clsdbc, "ContTime", "Ljava/sql/Timestamp;");
		__int64 time;
		time = (__int64)((Rec.UTC_Time-2440587.5)*86400.0)*1000;
      jclass Stmp = (jclass)env->NewObject(clsTstmp, tsCstr,(jlong)time);
		env->SetObjectField (JdbC, fid, Stmp);

		fid = env->GetFieldID (clsdbc, "Mode", "Ljava/lang/String;");
      jstr = env->NewStringUTF ((LPCSTR)Rec.Mode);
		env->SetObjectField (JdbC, fid, jstr);

		fid = env->GetFieldID (clsdbc, "Band", "Ljava/lang/String;");
      jstr = env->NewStringUTF ((LPCSTR)Rec.Band);
		env->SetObjectField (JdbC, fid, jstr);

		fid = env->GetFieldID (clsdbc, "Freq", "D");
      jdbl = (jdouble)Rec.Freq;
		env->SetDoubleField (JdbC, fid, jdbl);

		fid = env->GetFieldID (clsdbc, "SigRep", "Ljava/lang/String;");
      jstr = env->NewStringUTF ((LPCSTR)Rec.Sig_Rep);
		env->SetObjectField (JdbC, fid, jstr);

		fid = env->GetFieldID (clsdbc, "Comment", "Ljava/lang/String;");
      jstr = env->NewStringUTF ((LPCSTR)Rec.Comment);
		env->SetObjectField (JdbC, fid, jstr);

		fid = env->GetFieldID (clsdbc, "Class", "Ljava/lang/String;");
      jstr = env->NewStringUTF ((LPCSTR)Rec.Class);
		env->SetObjectField (JdbC, fid, jstr);

		fid = env->GetFieldID (clsdbc, "numXmit", "I");
      jnt = (jint)Rec.numXmit;
		env->SetIntField (JdbC, fid, jnt);

		fid = env->GetFieldID (clsdbc, "numPrev", "I");
      jnt = (jint)Rec.nContacts;
		env->SetIntField (JdbC, fid, jnt);

		fid = env->GetFieldID (clsdbc, "Section", "Ljava/lang/String;");
      jstr = env->NewStringUTF ((LPCSTR)Rec.Section);
		env->SetObjectField (JdbC, fid, jstr);

		fid = env->GetFieldID (clsdbc, "XmitPwr", "I");
      jnt = (jint)Rec.XmitPower;
		env->SetIntField (JdbC, fid, jnt);

		fid = env->GetFieldID (clsdbc, "QSL", "I");
      jnt = (jint)(Rec.bQSL?1:0);
		env->SetIntField (JdbC, fid, jnt);

		fid = env->GetFieldID (clsdbc, "QSLSENT", "I");
      jnt = (jint)(Rec.bQSL_Sent?1:0);
		env->SetIntField (JdbC, fid, jnt);

		fid = env->GetFieldID (clsdbc, "QSLType", "I");
      jnt = (jint)Rec.QSLType;
		env->SetIntField (JdbC, fid, jnt);
      
      env->CallVoidMethod (retv, mid, JdbC);
      }//for each returned AccessDB record
     delete statXlt;
   return retv;
   }//GetAllRecs


