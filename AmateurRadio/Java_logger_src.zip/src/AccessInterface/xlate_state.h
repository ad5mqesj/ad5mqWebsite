//xlate_state.h
//contains definition of class which associates call signs with countries via
//an external file called (by default) country.txt

typedef struct {
	CString	OldAbbr;
	CString NewAbbr;
	}STAT_STRUCT;

class xlateStates
{
private:
	STAT_STRUCT	*States;
	int			numStates;
	bool		   Inited;
public:
	xlateStates(char *File = NULL);
	~xlateStates();

	operator !();
	CString FindNewState (CString &OldState);
};
