package ad5mq;

public interface ITabChngCallBack 
{
	public void CallBack (int oldval, int newval, boolean brow);
	public void CellSelCallBack (int row, int col);
}
