package ad5mq;

import java.io.*;

public class StateFile 
{
	private int NumStates = 0;
	private String [] StateNames = null;
	private String [] StateAbbr = null;
	
	public void ReadStateFile ()
		{
		try
			{
			FileReader fr = new FileReader("config/States.txt");
	        BufferedReader br = new BufferedReader(fr);
	        StreamTokenizer st = new StreamTokenizer(br);
	        st.resetSyntax();
	        st.slashStarComments(true);
	        st.whitespaceChars(',', ',');
	        st.whitespaceChars('\t', '\t');
	        st.wordChars('A', 'Z');
	        st.wordChars('a', 'z');
	        st.wordChars(' ', ' ');
	        int tok, ix = 0;
	        String s[] = new String [2];
	        String [] Names;
	        String [] abbr;
	        while ((tok = st.nextToken()) != StreamTokenizer.TT_EOF) 
	        	{
	        	if (tok == StreamTokenizer.TT_WORD)
	        		{
	        		s[ix++] = st.sval;
	        		//get 3 so thats a new user
	        		if (ix == 2)
	        			{
	        			Names = new String [NumStates+1];
	        			abbr = new String [NumStates+1];
	        			for (int i = 0; i < NumStates+1; i++)
	        				{
	        				if (i==NumStates)
	        					{
	        					Names[i] = s[0].trim();
	        					abbr[i] = new String (s[1].trim().substring(0,2));//get 2 chars only
	        					NumStates++;
	        					//put new array on top of users array
	        					StateNames = Names;
	        					StateAbbr = abbr;
	        					ix = 0;
	        					break;
	        					}
	        				else
	        					{
	        					Names[i] = StateNames[i];
	        					abbr[i] = StateAbbr[i];
	        					}
	        				ix = 0;
	        				}
	        			}//2 tokens is assumed to be a user line
	        		}//if token is a word
	        	}//while there is more input
	        br.close();	        
			}
		//if there is no file - create back door user to start
		catch (IOException e)
			{
			}
		
		}//ReadStateFile
	public int GetNumStates()
		{
		return NumStates;
		}
	public String GetStateAt (int ix)
		{
		if (ix < NumStates && ix >= 0)
			return StateNames[ix];
		return new String();
		}
	public String GetStateAbbrAt (int ix)
		{
		if (ix < NumStates && ix >= 0)
			return StateAbbr[ix];
		return new String();
		}
	public String FindAbbrByState (String state)
		{
		int ix = -1;
		for (int i = 0; i < NumStates; i++)
			if (StateNames[i].contains(state))
			{ix = i; break;}
		if (ix >= 0)
			return StateAbbr[ix];
		return new String();
		}
	public String FindStateByAbbr (String state)
		{
		int ix = -1;
		for (int i = 0; i < NumStates; i++)
			if (StateAbbr[i].contains(state))
			{ix = i; break;}
		if (ix >= 0)
			return StateNames[ix];
		return new String();
		}
}//StateFile
