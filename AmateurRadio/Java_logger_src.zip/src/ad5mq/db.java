package ad5mq;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.UUID;
import java.util.Vector;

import org.apache.log4j.Logger;

public class db
{
	static Logger logger = Logger.getLogger(db.class.getName());
// define the driver to use 
	String driver = "org.apache.derby.jdbc.EmbeddedDriver";
// the database name  
	String dbName=null;
// define the Derby connection URL to use 
	String connectionURL = null;
	Connection conn = null;
	Statement s;
	PreparedStatement psInsert;
    boolean bDBok = false;
    int totalrecs = 0;
    /*
     * If you make changes to the DB defn then increase this numer
     * so you can detect that the version has changed and perform 
     * a conversion
     */
    static final int VERSION = 2;
    
	String createStr1 = "CREATE TABLE LoggerDBVersion ("
					  + "Version INTEGER NOT NULL)"; 

	String createStr2 = "CREATE TABLE Log ("
+"  LogKey	    VARCHAR(64) NOT NULL,"  // Primary key for sysinfo
+"  Call_ChainF	VARCHAR(64),"      		// chain to next record 
+"  Call_ChainB VARCHAR(64),"	   		// chain to previous record 
+"  ContTime	TIMESTAMP NOT NULL,"  		// UTC Julian date time of contact
+"  CallSign	VARCHAR(64) NOT NULL,"  // Call Sign
+"  NumContacts INTEGER NOT NULL,"  	// number of contacts with this call Sign
+"  Name		VARCHAR(64),"	   		// Name
+"  City		VARCHAR(64),"	   		// City of contact
+"  State		VARCHAR(64),"	   		// state of contact
+"  Country     VARCHAR(64) NOT NULL,"  // country of operation of contact
+"  Mode        VARCHAR(64),"	   		// operating mode for contact
+"  Band        VARCHAR(64),"	   		// Band (e.g. 80m) for contact
+"  Frequency	DOUBLE,"	   			// Frequency of contact
+"  Signal_Report VARCHAR(64),"      	// signal report
+"  MySig_Rep   VARCHAR(64),"      		// my signal report
+"  Comment     VARCHAR(1024),"      	// comments 
+"  Class       VARCHAR(64),"	   		// Field day operating class
+"  NumXmitter  INTEGER,"	   			// number of transmitters for field day
+"  Section     VARCHAR(64),"	   		// Field day ARRL/RAC section of contact
+"  QSL  		INTEGER,"	   			// QSL desired ? 1,0
+"  QSLSENT		INTEGER,"	   			// QSL sent ? 1,0
+"  QSLTYPE		INTEGER,"	   			// QSL type enum
+"  XmitPower	INTEGER,"	   			// BLOODY OBVIOUS
 
+"   CONSTRAINT LKPriKey  PRIMARY KEY (LogKey)" // make the key the primary key
+")";
	String answer;
   
	private static final db INSTANCE = new db();
	private db ()
		{
		
		}
	public static final db getInstance() 
		{
	    return INSTANCE;
	    }

	boolean IsOpen() {return bDBok;}
	boolean Open (String dname)
      {
      try	        
         {
         dbName = dname;
         connectionURL = new String ("jdbc:derby:");
         connectionURL = connectionURL + dbName + ";create=true";

         Class.forName(driver); 
         System.out.println(driver + " loaded. ");
         conn = DriverManager.getConnection(connectionURL);	
         logger.info("Connected to database " + dbName);
            
         //   Create a statement to issue simple commands.  
         s = conn.createStatement();
         // Call utility method to check if table exists.
         // Create the tables if needed
         if (!Chk4Table(conn))
            {
        	logger.info("Creating tables for new DB "+dbName); 
            s.execute(createStr1);
            s.execute(createStr2);
            psInsert = conn.prepareStatement("insert into LoggerDBVersion(Version) values (?)");
            psInsert.setInt(1, VERSION);
            psInsert.execute();
            psInsert.close();
            }
         //now check version and convert if nesc
         ResultSet versres;
         versres = s.executeQuery("Select Version FROM LoggerDBVersion");
         versres.next();	//there should be only one
         if (versres.getInt(1) < VERSION)
         	{
        	ConvertDB(); 
         	}
         versres.close();
         s.close();
         bDBok = true;
         } 
      catch(java.lang.ClassNotFoundException e)     
          {
    	  logger.error("Class not found exception");
    	  logger.error(e.getMessage());
    	  logger.error("Can't find Derby DB jars, check classpath");
    	  bDBok = false;
          }
      catch (SQLException se)
         {
         SQLExceptionPrint (se);
         bDBok = false;
         }
      return bDBok;
      }//Open
	
   void Close()
	{
	try
	   {
	   conn.close();
	   logger.info("Closed DB: " + dbName);
       try 
        {
        DriverManager.getConnection("jdbc:derby:;shutdown=true");
        } 
       catch (SQLException se)  
		{	
		if (se.getSQLState().equals("XJ015")) 
		   {		
		   logger.info("Derby shutdown successful");
		   }
		 }
	   }
	catch (SQLException se)
	     {
	     SQLExceptionPrint (se);
	     bDBok = false;
	     }
	bDBok = false;
	}//Close
   
   void CloseDbOnly()
   	{
	try
	   {
	   conn.close();
	   logger.info("Closed DB: " + dbName);
	   }
   catch (SQLException se)
      {
      SQLExceptionPrint (se);
      bDBok = false;
      }
	bDBok = false;
   }

   static void SQLExceptionPrint(SQLException sqle) 
      {
      while (sqle != null) 
          {
    	  logger.error("\n---SQLException Caught---\n");
    	  logger.error("SQLState:   " + (sqle).getSQLState());
    	  logger.error("Severity: " + (sqle).getErrorCode());
    	  logger.error("Message:  " + (sqle).getMessage()); 
          sqle.printStackTrace();  
          sqle = sqle.getNextException();
          }
      }

   boolean Chk4Table (Connection conTst)  throws SQLException
      {
      try 
         {
         Statement s = conTst.createStatement();
         s.execute("SELECT * FROM LoggerDBVersion");
         s.close();
         }  
      catch (SQLException sqle) 
         {
         String theError = (sqle).getSQLState();
         //   System.out.println("  Utils GOT:  " + theError);
         if (theError.equals("42X05"))   // Table does not exist
            {  return false;  }
         else
            throw sqle;
         }
      return true;
      }//Chk4Table
   void ConvertDB()
   	{
	try
	  {
	  ResultSet versres;
      Statement s = conn.createStatement();
	  versres = s.executeQuery("Select Version FROM LoggerDBVersion");
	  versres.next();	//there should be only one
	  int actualvers = versres.getInt(1);
	  if (actualvers == 1)
	  	{
		logger.info("Converting version 1 database to version 2.");
		s.execute("ALTER TABLE Log ADD COLUMN QSL INTEGER");  
		s.execute("ALTER TABLE Log ADD COLUMN QSLSENT INTEGER");  
		s.execute("ALTER TABLE Log ADD COLUMN QSLTYPE INTEGER");  
		s.execute("ALTER TABLE Log ADD COLUMN XmitPower INTEGER");
		s.execute("UPDATE LoggerDBVersion SET Verson = 2");
	  	}
	  //add else case here for version 2 to 3 ...
	  versres.close();
	  s.close();
	  }//try
    catch (SQLException se)
	    {
	    SQLExceptionPrint (se);
	    bDBok = false;
	    }
   	}//ConvertDB
   
   public boolean CreateDB (String dbname)
   	{
	boolean bret = false;   
    String connection = new String ("jdbc:derby:");
    connection = connection + dbname + ";create=true";
    try
    	{
    	Connection con = DriverManager.getConnection(connection);	
        logger.info("Connected to database " + dbname);
           
        //   Create a statement to issue simple commands.  
        s = con.createStatement();
        // Call utility method to check if table exists.
        // Create the tables if needed
       	logger.info("Creating tables for new DB "+dbName); 
        s.execute(createStr1);
        s.execute(createStr2);
        psInsert = con.prepareStatement("insert into LoggerDBVersion(Version) values (?)");
        psInsert.setInt(1, VERSION);
        psInsert.execute();
        psInsert.close();
        s.close();
        con.close();
        bret = true;
    	}//try
    catch (SQLException se)
	    {
	    SQLExceptionPrint (se);
	    bret = false;
	    }
    return bret;   
   	}//createDB
   
public Vector<dbContact> GetAllLogRecs ()
   {
   Vector<dbContact> retrecs = new Vector<dbContact>();
   dbContact lrec;
   ResultSet logrecs = null;
   try 
	    {
	   totalrecs = 0;
	    Statement s = conn.createStatement();
	    logrecs = s.executeQuery("SELECT * FROM Log ORDER BY ContTime DESC");
	    while (logrecs.next())
	    	{
	    	lrec = new dbContact();
	    	lrec.BackChain = logrecs.getString("Call_ChainB");
	    	lrec.Band = logrecs.getString("Band");
	    	lrec.CallSign = logrecs.getString("CallSign");
	    	lrec.City = logrecs.getString("City");
	    	lrec.Class = logrecs.getString("Class");
	    	lrec.Comment = logrecs.getString("Comment");
	    	lrec.ContTime = logrecs.getTimestamp("ContTime");
	    	lrec.Country = logrecs.getString("Country");
	    	lrec.ForwardChain = logrecs.getString("Call_ChainF");
	    	lrec.Freq = logrecs.getDouble("Frequency");
	    	lrec.Key = logrecs.getString("LogKey");
	    	lrec.Mode = logrecs.getString("Mode");
	    	lrec.MySigRep = logrecs.getString("MySig_Rep");
	    	lrec.Name = logrecs.getString("Name");
	    	lrec.numPrev = logrecs.getInt("NumContacts");
	    	lrec.numXmit = logrecs.getInt("NumXmitter");
	    	lrec.QSL = logrecs.getInt("QSL");
	    	lrec.QSLSENT = logrecs.getInt("QSLSENT");
	    	lrec.QSLType = logrecs.getInt("QSLTYPE");
	    	lrec.Section = logrecs.getString("Section");
	    	lrec.SigRep = logrecs.getString("Signal_Report");
	    	lrec.State = logrecs.getString("State");
	    	lrec.XmitPwr = logrecs.getInt("XmitPower");
	    	retrecs.add(lrec);
	    	}//while there is another record
	    logrecs.close();
	    s.close();
	    }  
	 catch (SQLException sqle) 
	    {
		SQLExceptionPrint (sqle);
	    }
	totalrecs = retrecs.size();
	return retrecs;
   }//GetAllLogRecs

public int GetTotalConts () {return totalrecs;}
public int GetNumStates ()
	{
	int num = 0;
    ResultSet logrecs = null;
    try 
		{
		Statement s = conn.createStatement();
		logrecs = s.executeQuery("SELECT DISTINCT State FROM Log WHERE State <> ''");
		while (logrecs.next()) num++;
		logrecs.close();
		s.close();
		}  
    catch (SQLException sqle) 
	    {
		SQLExceptionPrint (sqle);
	    }
	
	return num;
	}//GetNumStates

public int GetNumCountries ()
	{
	int num = 0;
	ResultSet logrecs = null;
	try 
		{
		Statement s = conn.createStatement();
		logrecs = s.executeQuery("SELECT DISTINCT Country FROM Log WHERE Country <> ''");
		while (logrecs.next()) num++;
		logrecs.close();
		s.close();
		}  
	catch (SQLException sqle) 
	    {
		SQLExceptionPrint (sqle);
	    }
	
	return num;
	}//GetNumCountries

public dbContact GetRecbyCallSign (String call)
	{
	dbContact lrec = null;
	ResultSet logrecs = null;
	String Query = null;
    try 
	    {
	    Statement s = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
	    Query = new String ("SELECT * FROM Log WHERE CallSign = '");
	    Query = Query + call;
	    Query = Query + "' ORDER BY ContTime DESC";
	    logrecs = s.executeQuery(Query);
///THIS DOESNT  WORK?
//	    boolean b = logrecs.isFirst() && logrecs.isLast();
//    	int row = logrecs.getFetchSize();
//	    int row = logrecs.getRow();
//	    if (row <= 0)
//	    	return null;
	    logrecs.first();
	    	{
	    	lrec = new dbContact();
	    	lrec.BackChain = logrecs.getString("Call_ChainB");
	    	lrec.Band = logrecs.getString("Band");
	    	lrec.CallSign = logrecs.getString("CallSign");
	    	lrec.City = logrecs.getString("City");
	    	lrec.Class = logrecs.getString("Class");
	    	lrec.Comment = logrecs.getString("Comment");
	    	lrec.ContTime = logrecs.getTimestamp("ContTime");
	    	lrec.Country = logrecs.getString("Country");
	    	lrec.ForwardChain = logrecs.getString("Call_ChainF");
	    	lrec.Freq = logrecs.getDouble("Frequency");
	    	lrec.Key = logrecs.getString("LogKey");
	    	lrec.Mode = logrecs.getString("Mode");
	    	lrec.MySigRep = logrecs.getString("MySig_Rep");
	    	lrec.Name = logrecs.getString("Name");
	    	lrec.numPrev = logrecs.getInt("NumContacts");
	    	lrec.numXmit = logrecs.getInt("NumXmitter");
	    	lrec.QSL = logrecs.getInt("QSL");
	    	lrec.QSLSENT = logrecs.getInt("QSLSENT");
	    	lrec.QSLType = logrecs.getInt("QSLTYPE");
	    	lrec.Section = logrecs.getString("Section");
	    	lrec.SigRep = logrecs.getString("Signal_Report");
	    	lrec.State = logrecs.getString("State");
	    	lrec.XmitPwr = logrecs.getInt("XmitPower");
	    	}//while there is another record
	    logrecs.close();
	    s.close();
	    }  
	 catch (SQLException sqle) 
	    {
		 if (sqle.getSQLState().equals("24000") && sqle.getErrorCode()==20000)
			 return null;
	    logger.error ("Error in GetRecbyCallSign()");
		SQLExceptionPrint (sqle);
		lrec = null;
	    }
	
	return lrec;
	}

public dbContact GetRecbyKey (String key)
	{
	dbContact lrec = null;
	ResultSet logrecs = null;
	String Query = null;
	try 
	    {
	    Statement s = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
	    Query = new String ("SELECT * FROM Log WHERE LogKey = '");
	    Query = Query + key;
	    Query = Query + "'";
	    logrecs = s.executeQuery(Query);
	    logrecs.last();
	    int row = logrecs.getRow();
	    if (row <= 0)
	    	return null;
    	{
    	lrec = new dbContact();
    	lrec.BackChain = logrecs.getString("Call_ChainB");
    	lrec.Band = logrecs.getString("Band");
    	lrec.CallSign = logrecs.getString("CallSign");
    	lrec.City = logrecs.getString("City");
    	lrec.Class = logrecs.getString("Class");
    	lrec.Comment = logrecs.getString("Comment");
    	lrec.ContTime = logrecs.getTimestamp("ContTime");
    	lrec.Country = logrecs.getString("Country");
    	lrec.ForwardChain = logrecs.getString("Call_ChainF");
    	lrec.Freq = logrecs.getDouble("CallSign");
    	lrec.Key = logrecs.getString("LogKey");
    	lrec.Mode = logrecs.getString("Mode");
    	lrec.MySigRep = logrecs.getString("MySig_Rep");
    	lrec.Name = logrecs.getString("Name");
    	lrec.numPrev = logrecs.getInt("NumContacts");
    	lrec.numXmit = logrecs.getInt("NumXmitter");
    	lrec.QSL = logrecs.getInt("QSL");
    	lrec.QSLSENT = logrecs.getInt("QSLSENT");
    	lrec.QSLType = logrecs.getInt("QSLTYPE");
    	lrec.Section = logrecs.getString("Section");
    	lrec.SigRep = logrecs.getString("Signal_Report");
    	lrec.State = logrecs.getString("State");
    	lrec.XmitPwr = logrecs.getInt("XmitPower");
    	}//while there is another record
	    logrecs.close();
	    s.close();
	    }  
	 catch (SQLException sqle) 
	    {
		SQLExceptionPrint (sqle);
	    }
	
	return lrec;
	}//GetRecbyKey

public int GetNumContacts (String call)
	{
	int ret = 0;
	ResultSet logrecs = null;
	String Query = null;
    try 
	    {
	    Statement s = conn.createStatement();
	    Query = new String ("SELECT * FROM Log WHERE CallSign='");
	    Query = Query + call;
	    Query = Query + "' ORDER BY ContTime";
	    logrecs = s.executeQuery(Query);
	    while (logrecs.next()) ret++;
	    logrecs.close();
	    s.close();
	    }
	 catch (SQLException sqle) 
	    {
		SQLExceptionPrint (sqle);
	    }
	
	return ret;
	}//GetNumContacts (for callsign)

public void PutNewLogEntry (dbContact contact)
	{
	String query;
	contact.Key = UUID.randomUUID().toString();
	try
		{
		dbContact lrec = GetRecbyCallSign (contact.CallSign);
		if (lrec != null)
			{
		    Statement s = conn.createStatement();
			lrec.ForwardChain = contact.Key;
			query = new String ("UPDATE Log SET Call_ChainF = '");
			query += contact.Key;
			query += "'";
			s.execute(query);
			s.close();
			contact.BackChain = lrec.Key;
			contact.numPrev = lrec.numPrev+1;
			}
		query = new String ("insert into Log (Call_ChainB,Band,");
		query += "CallSign,City,Class,Comment,ContTime,Country,Call_ChainF,";
		query += "Frequency,LogKey,Mode,MySig_Rep,Name,NumContacts,";
		query += "NumXmitter,QSL,QSLSENT,QSLTYPE,Section,Signal_Report,";
		query += "State,XmitPower) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        psInsert = conn.prepareStatement(query);
        psInsert.setString (1, contact.BackChain);
        psInsert.setString (2, contact.Band);
        psInsert.setString (3, contact.CallSign);
        psInsert.setString (4, contact.City);
        psInsert.setString (5, contact.Class);
        psInsert.setString (6, contact.Comment);
        psInsert.setTimestamp (7, contact.ContTime);
        psInsert.setString (8, contact.Country);
        psInsert.setString (9, contact.ForwardChain);
        psInsert.setDouble (10, contact.Freq);
        psInsert.setString (11, contact.Key);
        psInsert.setString (12, contact.Mode);
        psInsert.setString (13, contact.MySigRep);
        psInsert.setString (14, contact.Name);
        psInsert.setInt    (15, contact.numPrev);
        psInsert.setInt    (16, contact.numXmit);
        psInsert.setInt    (17, contact.QSL);
        psInsert.setInt    (18, contact.QSLSENT);
        psInsert.setInt    (19, contact.QSLType);
        psInsert.setString (20, contact.Section);
        psInsert.setString (21, contact.SigRep);
        psInsert.setString (22, contact.State);
        psInsert.setInt    (23, contact.XmitPwr);
        psInsert.execute();
        psInsert.close();
		}//try
	 catch (SQLException sqle) 
	    {
	    String theError = (sqle).getSQLState();
	    String theMsg = (sqle).getMessage();
	    logger.error("Error in PutNewLogEntry "+theError+" :"+theMsg);
	    logger.error("Code :"+(sqle).getErrorCode());	    
	    }
	}//PutNewLogEntry

public void EditLogEntry (dbContact contact)
{
String query;
try
	{
	query = new String ("update Log set Band = (?),");
	query += "CallSign=(?),City=(?),Class=(?),Comment=(?),ContTime=(?),";
	query += "Country=(?),Frequency=(?),";
	query += "Mode=(?),MySig_Rep=(?),Name=(?),NumContacts=(?),NumXmitter=(?),";
	query += "QSL=(?),QSLSENT=(?),QSLTYPE=(?),Section=(?),Signal_Report=(?),";
	query += "State=(?),XmitPower=(?) WHERE LogKey='";
	query += contact.Key;
	query += "'";
    psInsert = conn.prepareStatement(query);
    psInsert.setString (1, contact.Band);
    psInsert.setString (2, contact.CallSign);
    psInsert.setString (3, contact.City);
    psInsert.setString (4, contact.Class);
    psInsert.setString (5, contact.Comment);
    psInsert.setTimestamp (6, contact.ContTime);
    psInsert.setString (7, contact.Country);
    psInsert.setDouble (8, contact.Freq);
    psInsert.setString (9, contact.Mode);
    psInsert.setString (10, contact.MySigRep);
    psInsert.setString (11, contact.Name);
    psInsert.setInt    (12, contact.numPrev);
    psInsert.setInt    (13, contact.numXmit);
    psInsert.setInt    (14, contact.QSL);
    psInsert.setInt    (15, contact.QSLSENT);
    psInsert.setInt    (16, contact.QSLType);
    psInsert.setString (17, contact.Section);
    psInsert.setString (18, contact.SigRep);
    psInsert.setString (19, contact.State);
    psInsert.setInt    (20, contact.XmitPwr);
    psInsert.execute();
    psInsert.close();
	}//try
 catch (SQLException sqle) 
    {
    String theError = (sqle).getSQLState();
    String theMsg = (sqle).getMessage();
    logger.error("Error in EditLogEntry "+theError+" :"+theMsg);
    logger.error("Code :"+(sqle).getErrorCode());	    
    }
}//EditLogEntry

public Vector<dbContact> GetForeignRecs (Timestamp dt)
{
Vector<dbContact> retrecs = new Vector<dbContact>();
dbContact lrec;
ResultSet logrecs = null;
try 
	    {
	    Statement s = conn.createStatement();
	    String query = new String ("SELECT * FROM Log WHERE Country <> 'USA' AND ContTime > '");
	    query += dt.toString();
	    query += "'";
	    logrecs = s.executeQuery(query);
	    while (logrecs.next())
	    	{
	    	lrec = new dbContact();
	    	lrec.BackChain = logrecs.getString("Call_ChainB");
	    	lrec.Band = logrecs.getString("Band");
	    	lrec.CallSign = logrecs.getString("CallSign");
	    	lrec.City = logrecs.getString("City");
	    	lrec.Class = logrecs.getString("Class");
	    	lrec.Comment = logrecs.getString("Comment");
	    	lrec.ContTime = logrecs.getTimestamp("ContTime");
	    	lrec.Country = logrecs.getString("Country");
	    	lrec.ForwardChain = logrecs.getString("Call_ChainF");
	    	lrec.Freq = logrecs.getDouble("Frequency");
	    	lrec.Key = logrecs.getString("LogKey");
	    	lrec.Mode = logrecs.getString("Mode");
	    	lrec.MySigRep = logrecs.getString("MySig_Rep");
	    	lrec.Name = logrecs.getString("Name");
	    	lrec.numPrev = logrecs.getInt("NumContacts");
	    	lrec.numXmit = logrecs.getInt("NumXmitter");
	    	lrec.QSL = logrecs.getInt("QSL");
	    	lrec.QSLSENT = logrecs.getInt("QSLSENT");
	    	lrec.QSLType = logrecs.getInt("QSLTYPE");
	    	lrec.Section = logrecs.getString("Section");
	    	lrec.SigRep = logrecs.getString("Signal_Report");
	    	lrec.State = logrecs.getString("State");
	    	lrec.XmitPwr = logrecs.getInt("XmitPower");
	    	retrecs.add(lrec);
	    	}//while there is another record
	    logrecs.close();
	    s.close();
	    }  
	 catch (SQLException sqle) 
	    {
		 if (sqle.getSQLState().equals("24000") && sqle.getErrorCode()==20000)
			 return null;
	    String theError = (sqle).getSQLState();
	    String theMsg = (sqle).getMessage();
	    logger.error("Error in GetForeignRecs "+theError+" :"+theMsg);
	    logger.error("Code :"+(sqle).getErrorCode());	    
	    }
	
	return retrecs;
}//GetForeignRecs

public Vector<dbContact> GetRecsNewerThan (Timestamp dt)
{
Vector<dbContact> retrecs = new Vector<dbContact>();
dbContact lrec;
ResultSet logrecs = null;
try 
	    {
	    Statement s = conn.createStatement();
	    String query = new String ("SELECT * FROM Log WHERE ContTime > ");
	    query += dt.toString();
	    logrecs = s.executeQuery(query);
	    while (logrecs.next())
	    	{
	    	lrec = new dbContact();
	    	lrec.BackChain = logrecs.getString("Call_ChainB");
	    	lrec.Band = logrecs.getString("Band");
	    	lrec.CallSign = logrecs.getString("CallSign");
	    	lrec.City = logrecs.getString("City");
	    	lrec.Class = logrecs.getString("Class");
	    	lrec.Comment = logrecs.getString("Comment");
	    	lrec.ContTime = logrecs.getTimestamp("ContTime");
	    	lrec.Country = logrecs.getString("Country");
	    	lrec.ForwardChain = logrecs.getString("Call_ChainF");
	    	lrec.Freq = logrecs.getDouble("Frequency");
	    	lrec.Key = logrecs.getString("LogKey");
	    	lrec.Mode = logrecs.getString("Mode");
	    	lrec.MySigRep = logrecs.getString("MySig_Rep");
	    	lrec.Name = logrecs.getString("Name");
	    	lrec.numPrev = logrecs.getInt("NumContacts");
	    	lrec.numXmit = logrecs.getInt("NumXmitter");
	    	lrec.QSL = logrecs.getInt("QSL");
	    	lrec.QSLSENT = logrecs.getInt("QSLSENT");
	    	lrec.QSLType = logrecs.getInt("QSLTYPE");
	    	lrec.Section = logrecs.getString("Section");
	    	lrec.SigRep = logrecs.getString("Signal_Report");
	    	lrec.State = logrecs.getString("State");
	    	lrec.XmitPwr = logrecs.getInt("XmitPower");
	    	retrecs.add(lrec);
	    	}//while there is another record
	    logrecs.close();
	    s.close();
	    }  
	 catch (SQLException sqle) 
	    {
		 if (sqle.getSQLState().equals("24000") && sqle.getErrorCode()==20000)
			 return null;
	    String theError = (sqle).getSQLState();
	    String theMsg = (sqle).getMessage();
	    logger.error("Error in GetRecsNewerThan "+theError+" :"+theMsg);
	    logger.error("Code :"+(sqle).getErrorCode());	    
	    }
	
	return retrecs;
}//GetRecsNewerThan

public Vector<dbContact> GetQSLReqs (Timestamp dt)
{
Vector<dbContact> retrecs = new Vector<dbContact>();
dbContact lrec;
ResultSet logrecs = null;
try 
	    {
	    Statement s = conn.createStatement();
	    String query = new String ("SELECT * FROM Log WHERE (Comment LIKE \"*QSL*\" OR QSL = 1) AND ContTime > ");
	    query += dt.toString();
	    logrecs = s.executeQuery(query);
	    while (logrecs.next())
	    	{
	    	lrec = new dbContact();
	    	lrec.BackChain = logrecs.getString("Call_ChainB");
	    	lrec.Band = logrecs.getString("Band");
	    	lrec.CallSign = logrecs.getString("CallSign");
	    	lrec.City = logrecs.getString("City");
	    	lrec.Class = logrecs.getString("Class");
	    	lrec.Comment = logrecs.getString("Comment");
	    	lrec.ContTime = logrecs.getTimestamp("ContTime");
	    	lrec.Country = logrecs.getString("Country");
	    	lrec.ForwardChain = logrecs.getString("Call_ChainF");
	    	lrec.Freq = logrecs.getDouble("Frequency");
	    	lrec.Key = logrecs.getString("LogKey");
	    	lrec.Mode = logrecs.getString("Mode");
	    	lrec.MySigRep = logrecs.getString("MySig_Rep");
	    	lrec.Name = logrecs.getString("Name");
	    	lrec.numPrev = logrecs.getInt("NumContacts");
	    	lrec.numXmit = logrecs.getInt("NumXmitter");
	    	lrec.QSL = logrecs.getInt("QSL");
	    	lrec.QSLSENT = logrecs.getInt("QSLSENT");
	    	lrec.QSLType = logrecs.getInt("QSLTYPE");
	    	lrec.Section = logrecs.getString("Section");
	    	lrec.SigRep = logrecs.getString("Signal_Report");
	    	lrec.State = logrecs.getString("State");
	    	lrec.XmitPwr = logrecs.getInt("XmitPower");
	    	retrecs.add(lrec);
	    	}//while there is another record
	    logrecs.close();
	    s.close();
	    }  
	 catch (SQLException sqle) 
	    {
		 if (sqle.getSQLState().equals("24000") && sqle.getErrorCode()==20000)
			 return null;
	    String theError = (sqle).getSQLState();
	    String theMsg = (sqle).getMessage();
	    logger.error("Error in GetQSLReqs "+theError+" :"+theMsg);
	    logger.error("Code :"+(sqle).getErrorCode());	    
	    }
	
	return retrecs;
}//GetQSLReqs

}