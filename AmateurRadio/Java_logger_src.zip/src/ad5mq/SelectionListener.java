package ad5mq;

import javax.swing.DefaultListSelectionModel;
import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class SelectionListener  implements ListSelectionListener 
	{
    JTable table;
    ITabChngCallBack cbclass;
    
    // It is necessary to keep the table since it is not possible
    // to determine the table from the event's source
    SelectionListener(JTable table) 
    	{
        this.table = table;
    	}
    public void SetCallback (ITabChngCallBack cls)
    	{
    	cbclass = cls;
    	}
    public void valueChanged(ListSelectionEvent e) 
    	{
        // If cell selection is enabled, both row and column change events are fired
        if (e.getSource() == table.getSelectionModel()
              && table.getRowSelectionAllowed()) 
        	{
            // Row selection changed
            int first = e.getFirstIndex();
            //don't fire spurious extra events
            if (((DefaultListSelectionModel)e.getSource()).getValueIsAdjusting())
        	   return;
            int newrow = ((DefaultListSelectionModel)e.getSource()).getAnchorSelectionIndex();
            cbclass.CallBack(first,newrow,true);
        	}
        else if (e.getSource() == table.getColumnModel().getSelectionModel()
               && table.getColumnSelectionAllowed() )
        	{
            // Column selection changed
        	return;
        	}
        else 	//its a cell selection
        	{
            if (((DefaultListSelectionModel)e.getSource()).getValueIsAdjusting())
         	   return;
            int newrow = table.getSelectedRow();//((DefaultListSelectionModel)e.getSource()).getAnchorSelectionIndex();
            int newcol = table.getSelectedColumn();
            cbclass.CellSelCallBack(newrow, newcol);
            return;
        	}
        if (e.getValueIsAdjusting()) 
        	{
            // The mouse button has not yet been released
            return;
        	}
    	}//valueChanged
	}//SelectionListener
