package ad5mq;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StreamTokenizer;
import java.util.Vector;

import org.apache.log4j.Logger;

public class Countries 
{
	public class CNT_STRCT {
		String Start;
		String End;
		String Country;
		public CNT_STRCT ()
			{
			Start = new String();
			End = new String();
			Country = new String();
			}
		}//country "struct"
	Vector<CNT_STRCT> VCountries;
	private int NumCountries = 0;
	
	static Logger logger = Logger.getLogger(Countries.class.getName());

	public Countries ()
		{
		FileReader fr;
		try {
			fr = new FileReader("config/Countries.txt");
	        BufferedReader br = new BufferedReader(fr);
	        StreamTokenizer st = new StreamTokenizer(br);
	        st.resetSyntax();
	        st.slashStarComments(true);
	        st.whitespaceChars(',', ',');
	        st.whitespaceChars('\t', '\t');
	        st.wordChars('A', 'Z');
	        st.wordChars('a', 'z');
	        st.wordChars('0', '9');
	        st.wordChars(' ', ' ');
	        st.wordChars('.', '.');
	        st.wordChars('&', '&');
	        st.wordChars('(', '(');
	        st.wordChars(')', ')');
	        st.wordChars('-', '-');
	        int tok, ix = 0;
	        String s[] = new String [3];
	        VCountries = new Vector<CNT_STRCT>();
	        CNT_STRCT nwCntSt;
	        while ((tok = st.nextToken()) != StreamTokenizer.TT_EOF) 
	        	{
	        	if (tok == StreamTokenizer.TT_WORD)
	        		{
	        		s[ix++] = st.sval;
	        		//got 3 so thats a new entry
	        		if (ix == 3)
	        			{
	        			nwCntSt = new CNT_STRCT();
    					nwCntSt.Start = s[0].trim();
    					nwCntSt.End = s[1].trim();
    					nwCntSt.Country = s[2].trim();
    					VCountries.add(nwCntSt);
       					NumCountries++;
        				ix = 0;
	        			}
	        		}//if its a word
	        	}//while there is another token
	        br.close();	        
			} //try
		catch (FileNotFoundException e) 
			{
			logger.error("Can't find Countries.txt");
			e.printStackTrace();
			}
		catch (IOException e)
			{
			logger.error("I/O error reading Countries.txt");
			}
		}//ctor - read passed file
	public int GetNumCountries()
		{
		return NumCountries;
		}
	public CNT_STRCT GetCountryAt (int ix)
		{
		if (ix < NumCountries && ix >= 0)
			return VCountries.elementAt (ix);
		return new CNT_STRCT();
		}
	
	public String FindCountry (String call)
		{
		String retcnt = new String ();
		int len;
		String leftPart;
		CNT_STRCT country;
		if (NumCountries == 0 || VCountries.size() == 0)
			return retcnt;

		if (call.length() > 3)
			leftPart = call.substring(0, 2);
		else if (call.length() != 0)
			leftPart = call;
		else
			return retcnt;
		len = leftPart.length();

		for (int ixCnt = 0; ixCnt < NumCountries; ixCnt++)
			{
			country = VCountries.elementAt(ixCnt);
			if (country.Start.substring(0,len).compareToIgnoreCase(leftPart) <= 0)
				{
				if (country.End.substring(0,len).compareToIgnoreCase(leftPart) >= 0)
					{
					retcnt = country.Country;
					break;
					} 
				}//if left part > start
			else if (ixCnt != 0 && country.End.substring(0,len).compareToIgnoreCase(leftPart) <= 0)
				{
				if (country.End.substring(0,len).compareToIgnoreCase(leftPart) >= 0)
					{
					retcnt = country.Country;
					break;
					} 
				}
			}//for each country in list
		return retcnt;
	 	}//FindCountry
}
