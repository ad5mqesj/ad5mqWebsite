package ad5mq;

import java.sql.Timestamp;
import java.util.Vector;

import org.apache.log4j.Logger;

public class AccessImport 
{
	static Logger logger = Logger.getLogger(AccessImport.class.getName());
	private boolean connected = false;
	private String DBName = null;

	public void setName (String nm)
		{
		DBName = nm;
		}

	public boolean open ()
		{
		System.loadLibrary("AccessInterface");
		connected = AccessOpen (logger,DBName);
		return connected;
		}
	
	public boolean open (String nm)
		{
		System.load("C:/source/ContactLogger/src/AccessInterface/Debug/AccessInterface.dll");
		DBName = nm;
		connected = AccessOpen (logger,DBName);
		return connected;
		}

	public void cleanUp()
		{
		AccessClose();
		connected = false;
		}
	public boolean IsOpen () { return connected; }

	public Vector<dbContact> GetAll()
		{
		Vector<dbContact> contacts = GetAllRecs();
		return (contacts);
		}
	
	private native boolean AccessOpen (Logger jniLogger, String dbName);
	private native void AccessClose();
	
	private native Vector<dbContact> GetAllRecs();
}
