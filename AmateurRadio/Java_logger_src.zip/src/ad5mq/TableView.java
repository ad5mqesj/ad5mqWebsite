package ad5mq;

import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;

import java.awt.Rectangle;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Vector;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class TableView extends JScrollPane {

	private static final long serialVersionUID = 1L;
	private static JTable MainTable = null;
	private JScrollPane jScrollPane = null;
	private TableSorter sorter;
	private DefaultTableModel model = null;
	private static String columns[] = {"Call", "#","Name", "City", "State", "Country","Mode","Time","Comment"};
	private static int [] ColWids;// = {60,20,100,100,60,70,50,160,300};
	public dbContact currec;
	public int currow = 0;
	public Vector <dbContact> allrecs;
	
	private static final TableView instance = new TableView();
	public static TableView getInstance () {return instance;}
	private TableView() 
		{
		super();
//		initialize();
		}
	public static int [] getWids() {
		for (int i = 0; i < columns.length; i++)
		{
		TableColumn col = MainTable.getColumnModel().getColumn(i);
		ColWids[i] = col.getWidth();
		}
		return ColWids;
		}
	public static void setWids (int [] inw) {
		ColWids = new int [inw.length];
		for (int i = 0; i < inw.length; i++)
			ColWids[i] = inw[i];
	}
	
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	public void initialize() 
		{
		this.setSize(850, 375);
		this.add(getJScrollPane(), null);
		this.setViewportView(getMainTable());
		PopulateTable();
		}

	public void PopulateTable()
		{
		int rows = model.getRowCount();
		for (int ix = rows-1; ix >= 0; ix--)
			model.removeRow(ix);
		db DB = db.getInstance();
		allrecs = DB.GetAllLogRecs();
		for (int i = 0; i < allrecs.size(); i++)
			{
			AddRow (allrecs.get(i));
			}
		currow = 0;
		if (allrecs.size() > 0)
			{
			currec = allrecs.get(currow);
			Contact ct = Contact.getInstance();
			ct.contDat = currec;
			ct.ShowSet();
			}
		}
	public void AddRow (dbContact cnt)
		{
		NumberFormat formatter = new DecimalFormat("###");
		Object [] Row = new Object [columns.length];
		Row[0] = cnt.CallSign;
		String s = formatter.format(cnt.numPrev);
		Row[1] = s;
		Row[2] = cnt.Name;
		Row[3] = cnt.City;
		Row[4] = cnt.State;
		Row[5] = cnt.Country;
		Row[6] = cnt.Mode;
//		SimpleDateFormat sdf = new SimpleDateFormat ("hh:mm MMM dd yyyy ", Locale.US);
		Row[7] = cnt.ContTime;//sdf.format(cnt.ContTime);
		Row[8] = cnt.Comment;
		model.addRow(Row);
		}
	
	/**
	 * This method initializes jScrollPane	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane() 
		{
		if (jScrollPane == null) 
			{
			jScrollPane = new JScrollPane();
			jScrollPane.setBounds(new Rectangle(10, 20, 730, 330));
			jScrollPane.setViewportView(getMainTable());
			}
		return jScrollPane;
		}
	/**
	 * This method initializes MainTable	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getMainTable() 
		{
		if (MainTable == null) 
			{
			model = new DefaultTableModel (columns, 0);
		    sorter = new TableSorter(model);
			MainTable = new JTable(sorter);      
			sorter.addMouseListenerToHeaderInTable(MainTable); 
//			MainTable = new JTable(model);
//			MainTable.setAutoCreateRowSorter(true);
			MainTable.setRowHeight(20);
			SelectionListener listener = new SelectionListener(MainTable);
			MainTable.getSelectionModel().addListSelectionListener(listener);
			MainTable.getColumnModel().getSelectionModel().addListSelectionListener(listener);
			MainTable.setRowSelectionAllowed (true);
			MainTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			tableCallback tbcb = new tableCallback();
			listener.SetCallback(tbcb);
			for (int i = 0; i < columns.length; i++)
				{
				TableColumn col = MainTable.getColumnModel().getColumn(i);
				col.setPreferredWidth(ColWids[i]);
				col.setWidth(ColWids[i]);
				col.setMaxWidth((int)(ColWids[i]*1.75));
				}
			}
		return MainTable;
		}
	
	private class tableCallback implements ITabChngCallBack
		{
		public void CallBack (int oldval, int newval, boolean brow)
			{
			if (brow)
				{
				if (newval < 0 || newval > model.getRowCount())
					return;
				currow = sorter.convertRowIndexToModel(newval);
//				currow = MainTable.convertRowIndexToModel(newval);
				if (currow >-1)
					{
					currec = allrecs.get(currow);
					Contact ct = Contact.getInstance();
					ct.contDat = currec;
					ct.ShowSet();
					}
				}
			return;	//dont care about row/column selections
		    }//CallBack
		public void CellSelCallBack (int row, int col)
			{
			return;
			}
		}//tableCallback

}  //  @jve:decl-index=0:visual-constraint="10,10"
