package ad5mq;

import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.SwingConstants;
import javax.swing.KeyStroke;
import java.awt.Point;

import javax.swing.ImageIcon;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JMenuItem;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JFrame;
import javax.swing.JDialog;
import org.apache.log4j.Logger;
import java.io.Externalizable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.sql.Timestamp;
import java.util.Random;
import java.util.Vector;

public class ContactLogger  extends JFrame implements Externalizable
{

	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(ContactLogger.class.getName());
	private static final ContactLogger INSTANCE = new ContactLogger();

	static final int MIN_WIDTH = 580;
    static final int MIN_HEIGHT = 630;
	public  ScaledCtrlRect scr;
	public static Font LargeFont;
	public static Font MedFont;
	public static Font SmallFont;
	public static Font CurrentFont;
	private db DB;
	final JFileChooser fc = new JFileChooser();
	public String Name;
	public String Call;
	private String Grid;
	private String Qth;
	private Dimension stSize;
	public boolean bFDMode = false;
	public String dbName;
	public int [] ColWids;// = {60,20,100,100,60,70,50,160,300};
	
	private JFrame jFrame = null;  //  @jve:decl-index=0:visual-constraint="9,38"
	private JPanel jContentPane = null;
	private JMenuBar jJMenuBar = null;
	private JMenu fileMenu = null;
	private JMenu exportsMenu = null;
	private JMenu editMenu = null;
	private JMenu helpMenu = null;
	private JMenuItem exitMenuItem = null;
	private JMenuItem aboutMenuItem = null;
	private JMenuItem prefsMenuItem = null;
	private JCheckBoxMenuItem fdMenuItem = null;
	private JMenuItem newMenuItem = null;
	private JMenuItem InsertMenuItem = null;
	private JMenuItem ForConRept;
	private JMenuItem expForConts;
	private JMenuItem expADIF;
	private JMenuItem expFldDay;
	private JMenuItem expQSLs;
	private JDialog aboutDialog = null;
	private JPanel aboutContentPane = null;
	private JLabel aboutVersionLabel = null;

	public static final ContactLogger getInstance() 
		{
	    return INSTANCE;
	    }
	private ContactLogger()
		{
		super();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setDefaultLookAndFeelDecorated(true);
		setJMenuBar(getJJMenuBar());
    	try
			{
			ObjectInputStream i = new ObjectInputStream(
					new FileInputStream("config/ContactLogger.out"));
			this.readExternal(i);
			i.close();
			}//try
		catch (IOException ex)
			{
			logger.debug("IO Exception - failed to read stored state.");
			dbName = new String ("MasterDB");
			bFDMode = false;
			Name = new String ("Ed");
			Call = new String ("AD5MQ");
			Grid = new String ("DM64nb");
			Qth = new String ("Socorro, New Mexico; USA");
			stSize = new Dimension (880, 630);
			int [] dcw = {60,20,100,100,60,70,50,160,300};
			ColWids = new int [dcw.length];
			for (int i = 0; i < dcw.length; i++)
				ColWids[i] = dcw[i];
			}
		catch (ClassNotFoundException ex)
			{
			logger.debug("Exception ClassNotFoundException - failed to read stored state.");
			dbName = new String ("MasterDB");
			bFDMode = false;
			Name = new String ("Ed");
			Call = new String ("AD5MQ");
			Grid = new String ("DM64nb");
			Qth = new String ("Socorro, New Mexico; USA");
			stSize = new Dimension (880, 630);
			int [] dcw = {60,20,100,100,60,70,50,160,300};
			ColWids = new int [dcw.length];
			for (int i = 0; i < dcw.length; i++)
				ColWids[i] = dcw[i];
			}

		setSize(stSize);
		DB = db.getInstance();
		if (!DB.IsOpen())
			DB.Open(dbName);
		TableView.setWids(ColWids);
		LargeFont = new Font("Dialog", Font.BOLD, 20);
		MedFont = new Font("Dialog", Font.BOLD, 12);
		SmallFont = new Font("Dialog", Font.BOLD, 6);
		scr = ScaledCtrlRect.getInstance();

		setContentPane(getJContentPane());
		Image img = createImageIcon("Log.gif").getImage();
		setIconImage(img);
		setTitle("Station Log for " + Call);
		fdMenuItem.setSelected(bFDMode);
		jFrame = this;
		//do it again so FD mode is handled correctly
		Contact ct = Contact.getInstance();
		ct.FDMode = bFDMode;
		ct.ShowSet();
		setLocationRelativeTo(null);
		this.addWindowListener(new WindowAdapter() 
			{
		    // save state
		    public void windowClosing( WindowEvent event )
		      	{
		    	CleanUp();
		      	}
		  	} // end anonymous inner class
			); // end call to addWindowListener	
		}//ctor
	
	private void CleanUp()
		{
		logger.info("Saving state at exit.");
    	try
    		{
    		ObjectOutputStream o = new ObjectOutputStream(
    				new FileOutputStream("config/ContactLogger.out"));
    		//write direct so we dont get extra crap thats unneeded
    		o.writeObject(dbName);
    		o.writeBoolean (bFDMode);
    		o.writeObject(Name);
    		o.writeObject(Call);
    		o.writeObject(Grid);
    		o.writeObject(Qth);
    		stSize = this.getSize();
    		ColWids = TableView.getWids();
    		o.writeObject(stSize);
			o.writeInt(ColWids.length);
    		for (int i = 0; i < ColWids.length; i++)
    			o.writeInt(ColWids[i]);
    		o.close();
    		DB.Close();
    		}//try
    	catch (IOException ex)
    		{
    		logger.debug("Exception - failed to save state.");
    		}
		}
	public JFrame getJFrame (){return jFrame;}
	
	public void writeExternal(ObjectOutput out)	throws IOException 
    	{
		out.writeObject(dbName);
		out.writeBoolean (bFDMode);
		out.writeObject(Name);
		out.writeObject(Call);
		out.writeObject(Grid);
		out.writeObject(Qth);
		stSize = this.getSize();
		out.writeObject(stSize);
		out.writeInt(ColWids.length);
		for (int i = 0; i < ColWids.length; i++)
			out.writeInt(ColWids[i]);
		}//serializer write
	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException
		{
		dbName = new String ((String)in.readObject ());
		bFDMode = (boolean)in.readBoolean();
		Name = new String ((String)in.readObject ());
		Call = new String ((String)in.readObject ());
		Grid = new String ((String)in.readObject ());
		Qth = new String ((String)in.readObject ());
		stSize = new Dimension ((Dimension)in.readObject());
		int  sz = in.readInt();
		ColWids = new int [sz];
		for (int i = 0; i < sz; i++)
			ColWids[i] = in.readInt();
		}//serialzer read

    protected static ImageIcon createImageIcon(String path) 
		{
	    java.net.URL imgURL = MainTabbed.class.getResource(path);
	    if (imgURL != null) 
	    	{
	        return new ImageIcon(imgURL);
	    	} 
	    else 
	    	{
	        System.err.println("Couldn't find file: " + path);
	        return null;
	    	}
		}//createImageIcon
	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new MainTabbed();
			jContentPane.setVisible(true);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jJMenuBar	
	 * 	
	 * @return javax.swing.JMenuBar	
	 */
	private JMenuBar getJJMenuBar() {
		if (jJMenuBar == null) {
			jJMenuBar = new JMenuBar();
			jJMenuBar.add(getFileMenu());
			jJMenuBar.add(getEditMenu());
			jJMenuBar.add(getHelpMenu());
		}
		return jJMenuBar;
	}

	/**
	 * This method initializes jMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getFileMenu() {
		if (fileMenu == null) {
			fileMenu = new JMenu();
			fileMenu.setText("File");
			fileMenu.add(getNewMenuItem());
			fileMenu.addSeparator();
			fileMenu.add(getExportMenu());
			fileMenu.addSeparator();
			fileMenu.add(getInsertMenuItem());
			fileMenu.add(getExitMenuItem());
		}
		return fileMenu;
	}

	private JMenuItem getExportMenu() {
		if (exportsMenu == null) {
			exportsMenu = new JMenu();
			exportsMenu.setText("Exports");
//			exportsMenu.add(getForConRept());
			exportsMenu.add(getexpForConts());
			exportsMenu.add(getexpADIF());
			exportsMenu.add(getexpFldDay());
			exportsMenu.add(getexpQSLs());
			}
		return exportsMenu;
	}
	/**
	 * This method initializes jMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getEditMenu() {
		if (editMenu == null) {
			editMenu = new JMenu();
			editMenu.setText("Edit");
			editMenu.add(getPrefsMenuItem());
			editMenu.add(getFdMenuItem());
		}
		return editMenu;
	}

	/**
	 * This method initializes jMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getHelpMenu() {
		if (helpMenu == null) {
			helpMenu = new JMenu();
			helpMenu.setText("Help");
			helpMenu.add(getAboutMenuItem());
		}
		return helpMenu;
	}

	/**
	 * This method initializes jMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getExitMenuItem() {
		if (exitMenuItem == null) {
			exitMenuItem = new JMenuItem();
			exitMenuItem.setText("Exit");
			exitMenuItem.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) 
					{
					CleanUp();
					System.exit(0);
					}
				});
		}
		return exitMenuItem;
	}

	/**
	 * This method initializes jMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getAboutMenuItem() {
		if (aboutMenuItem == null) {
			aboutMenuItem = new JMenuItem();
			aboutMenuItem.setText("About");
			aboutMenuItem.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JDialog aboutDialog = getAboutDialog();
					aboutDialog.pack();
					Point loc = getJFrame().getLocation();
					loc.translate(20, 20);
					aboutDialog.setLocation(loc);
					aboutDialog.setVisible(true);
				}
			});
		}
		return aboutMenuItem;
	}

	/**
	 * This method initializes aboutDialog	
	 * 	
	 * @return javax.swing.JDialog
	 */
	private JDialog getAboutDialog() {
		if (aboutDialog == null) {
			aboutDialog = new JDialog(getJFrame(), true);
			aboutDialog.setTitle("About Contact Logger");
			aboutDialog.setContentPane(getAboutContentPane());
		}
		return aboutDialog;
	}

	/**
	 * This method initializes aboutContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getAboutContentPane() {
		if (aboutContentPane == null) {
			aboutContentPane = new JPanel();
			aboutContentPane.setLayout(new BorderLayout());
			aboutContentPane.add(getAboutVersionLabel(), BorderLayout.CENTER);
		}
		return aboutContentPane;
	}

	/**
	 * This method initializes aboutVersionLabel	
	 * 	
	 * @return javax.swing.JLabel	
	 */
	private JLabel getAboutVersionLabel() {
		if (aboutVersionLabel == null) {
			aboutVersionLabel = new JLabel();
			aboutVersionLabel.setText("Version 1.0");
			aboutVersionLabel.setHorizontalAlignment(SwingConstants.CENTER);
		}
		return aboutVersionLabel;
	}

	/**
	 * This method initializes jMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getPrefsMenuItem() {
		if (prefsMenuItem == null) {
			prefsMenuItem = new JMenuItem();
			prefsMenuItem.setText("User Info");
			prefsMenuItem.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) 
					{
					UserInfo dlg = new UserInfo();
					dlg.Name = Name;
					dlg.Call = Call;
					dlg.Grid = Grid;
					dlg.Qth = Qth;
					dlg.DoModal();
					if (dlg.bOk)
						{
						Name = new String (dlg.Name);
						Call = new String (dlg.Call);
						Grid = new String (dlg.Grid);
						Qth = new String (dlg.Qth);
						}
					}
			});
		}
		return prefsMenuItem;
	}
	private JMenuItem getFdMenuItem() {
		if (fdMenuItem == null) {
			fdMenuItem = new JCheckBoxMenuItem();
			fdMenuItem.setText("Field Day Mode");
			fdMenuItem.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) 
					{
					bFDMode = fdMenuItem.isSelected();
					Contact ct = Contact.getInstance();
					ct.FDMode = bFDMode;
					ct.ShowSet();
					}
			});
		}
		return fdMenuItem;
	}


	/**
	 * This method initializes jMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getNewMenuItem() 	
		{
		if (newMenuItem == null) 
			{
			newMenuItem = new JMenuItem();
			newMenuItem.setText("Change DB");
			newMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,
					Event.CTRL_MASK, true));
			newMenuItem.addActionListener(new ActionListener() 
				{
				public void actionPerformed(ActionEvent e) 
					{
					int returnVal = fc.showSaveDialog(null);
					if (returnVal == JFileChooser.APPROVE_OPTION)
						{
						File file = fc.getSelectedFile();
						logger.info("Changing to new DB "+file.getName());
						DB.CloseDbOnly();
						DB.Open(file.getName());
						if (DB.IsOpen())
							dbName = file.getName();
						else
							DB.Open(dbName);
						((TableView)((MainTabbed)jContentPane).GetPanel2()).PopulateTable();
						}
					}
				});
			}
		return newMenuItem;
		}

	private JMenuItem getInsertMenuItem() 
		{
		if (InsertMenuItem == null) 
			{
			InsertMenuItem = new JMenuItem();
			InsertMenuItem.setText("Import Access DB");
			InsertMenuItem.addActionListener(new ActionListener() 
				{
				public void actionPerformed(ActionEvent e) 
					{
					Import();
					}
				});
			}
		return InsertMenuItem;
		}
	
	void Import()
		{
		AccessImport imp;
		imp = new AccessImport();
		int returnVal = fc.showOpenDialog(null);
		if (returnVal == JFileChooser.APPROVE_OPTION)
			{
			File file = fc.getSelectedFile();
			imp.open(file.getName());
			Vector<dbContact> cnts = imp.GetAll();
			imp.cleanUp();
			for (int i = 0; i < cnts.size(); i++)
				DB.PutNewLogEntry(cnts.get(i));
			((TableView)((MainTabbed)jContentPane).GetPanel2()).PopulateTable();
			}
		}
	private JMenuItem getForConRept() 
		{
		if (ForConRept == null) 
			{
			ForConRept = new JMenuItem();
			ForConRept.setText("Foreign Contact Report");
			ForConRept.addActionListener(new ActionListener() 
				{
				public void actionPerformed(ActionEvent e) 
					{
					//TODO for cont rept
					}
				});
			}
		return ForConRept;
		}

	private JMenuItem getexpForConts() 
		{
		if (expForConts == null) 
			{
			expForConts = new JMenuItem();
			expForConts.setText("Export Foreign Contacts");
			expForConts.addActionListener(new ActionListener() 
				{
				public void actionPerformed(ActionEvent e) 
					{
					ContactReport rpt = new ContactReport("foreigncontact.txt");
					rpt.GenerateReport();
					}
				});
			}
		return expForConts;
		}
	private JMenuItem getexpADIF() 
		{
		if (expADIF == null) 
			{
			expADIF = new JMenuItem();
			expADIF.setText("Export ADIF");
			expADIF.addActionListener(new ActionListener() 
				{
				public void actionPerformed(ActionEvent e) 
					{
					//TODO export ADIF 
					}
				});
			}
		return expADIF;
		}

	private JMenuItem getexpFldDay() 
	{
	if (expFldDay == null) 
		{
		expFldDay = new JMenuItem();
		expFldDay.setText("Export Field Day");
		expFldDay.addActionListener(new ActionListener() 
			{
			public void actionPerformed(ActionEvent e) 
				{
				//TODO export for conts 
				}
			});
		}
	return expFldDay;
	}

	private JMenuItem getexpQSLs() 
	{
	if (expQSLs == null) 
		{
		expQSLs = new JMenuItem();
		expQSLs.setText("Export QSL Requests");
		expQSLs.addActionListener(new ActionListener() 
			{
			public void actionPerformed(ActionEvent e) 
				{
				//TODO export for conts 
				}
			});
		}
	return expQSLs;
	}
	
}
