package ad5mq;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class main 
{
	static Logger logger = Logger.getLogger(main.class.getName());
	/**
	 * Launches this application
	 */
	public static void main(String[] args) 
		{
	    PropertyConfigurator.configure("config/Logger.log.config");
		ContactLogger application = ContactLogger.getInstance();
		application.setVisible(true);
		}
}//main
