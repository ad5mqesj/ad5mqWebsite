package ad5mq;

import javax.swing.JPanel;
import java.awt.Frame;
import java.awt.BorderLayout;
import javax.swing.JDialog;
import javax.swing.JButton;
import java.awt.Rectangle;
import javax.swing.JTextField;
import java.awt.Dimension;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.TimeZone;

public class DTPicker extends JDialog {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private DateButton DatButton = null;
	private JTextField Time = null;
	private JButton Ok = null;
	private JButton Cancel = null;
	public boolean bOk = false;
	public Timestamp dtime;
	
	
	/**
	 * @param owner
	 */
	public DTPicker(Frame owner) 
		{
		super(owner);
		initialize();
		}
	public DTPicker() 
		{
		super();
		initialize();
		}
	public boolean doModal ()
		{
		setModal(true);
		DatButton.setDate(new Date(dtime.getTime()));
		String s = new String();
		Integer i = new Integer (dtime.getHours());
		NumberFormat formatter = new DecimalFormat("00");
		s = formatter.format(i);
		s +=":";
		i = new Integer (dtime.getMinutes());
		s += formatter.format(i);
		Time.setText (s);
		setVisible(true);
		return bOk;
		}
	
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() 
		{
		this.setSize(279, 181);
		this.setTitle("Set Date and Time");
		this.setContentPane(getJContentPane());
		}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(getDatButton(), null);
			jContentPane.add(getTime(), null);
			jContentPane.add(getOk(), null);
			jContentPane.add(getCancel(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes DatButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getDatButton() {
		if (DatButton == null) {
			DatButton = new DateButton();
			DatButton.setBounds(new Rectangle(14, 45, 120, 20));
		}
		return DatButton;
	}

	/**
	 * This method initializes Time	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTime() {
		if (Time == null) {
			Time = new JTextField();
			Time.setBounds(new Rectangle(152, 45, 90, 20));
			Time.setHorizontalAlignment(JTextField.CENTER);
			Time.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
					{
					String s = new String(Time.getText());
					int ix = s.indexOf(":");
					int min=0, hr;
					if (ix <= 0)
						hr = Integer.parseInt(s);
					else
						{
						hr = Integer.parseInt(s.substring(0,ix));
						min = Integer.parseInt(s.toString().substring(ix+1));
						}
					Timestamp nw = new Timestamp (dtime.getTime());
					nw.setHours(hr);
					nw.setMinutes(min);
					nw.setSeconds(0);
					dtime = new Timestamp (nw.getTime());
					}
			});
		}
		return Time;
	}

	/**
	 * This method initializes Ok	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getOk() {
		if (Ok == null) {
			Ok = new JButton();
			Ok.setBounds(new Rectangle(31, 105, 88, 20));
			Ok.setText("Ok");
			Ok.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					bOk = true;
					String s = new String(Time.getText());
					int ix = s.indexOf(":");
					int min=0, hr;
					if (ix <= 0)
						hr = Integer.parseInt(s);
					else
						{
						hr = Integer.parseInt(s.substring(0,ix));
						min = Integer.parseInt(s.toString().substring(ix+1));
						}
					Timestamp nw = new Timestamp (DatButton.getDate().getTime());
					nw.setHours(hr);
					nw.setMinutes(min);
					nw.setSeconds(0);
					dtime = new Timestamp (nw.getTime());
					setVisible (false);
					dispose();
				}
			});
		}
		return Ok;
	}

	/**
	 * This method initializes Cancel	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getCancel() {
		if (Cancel == null) {
			Cancel = new JButton();
			Cancel.setBounds(new Rectangle(154, 106, 88, 20));
			Cancel.setText("Cancel");
			Cancel.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					bOk = false;
					setVisible (false);
					dispose();
					}
			});
		}
		return Cancel;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
