package ad5mq;

import java.sql.Timestamp;

public class dbContact 
{
	String 		Key;
	String 		ForwardChain;
	String 		BackChain;
	Timestamp 	ContTime;
	String 		CallSign;
	int			numPrev;
	String		Name;
	String		City;
	String 		State;
	String 		Country;
	String		Mode;
	String		Band;
	double		Freq;
	String		SigRep;
	String		MySigRep;
	String		Comment;
	String		Class;
	int			numXmit;
	String		Section;
	int			QSL;
	int			QSLSENT;
	int			QSLType;
	int			XmitPwr;
	
	public dbContact()
		{
		Key = new String ();
		ForwardChain = new String ();
		BackChain = new String ();
		ContTime = new Timestamp(System.currentTimeMillis());
		CallSign = new String ();
		numPrev = 0;
		Name = new String ();
		City = new String ();
		State = new String ();
		Country = new String ();
		Mode = new String ();
		Band = new String ();
		Freq = 14.070;
		SigRep = new String ();
		MySigRep = new String ();
		Comment = new String ();
		Class = new String ();
		numXmit = 0;
		Section = new String ();
		QSL = 1;
		QSLSENT = 0;
		QSLType = 0;
		XmitPwr = 25;
		}
}
