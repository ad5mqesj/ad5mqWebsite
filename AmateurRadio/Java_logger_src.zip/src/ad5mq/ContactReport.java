package ad5mq;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Vector;

import org.apache.log4j.Logger;

public class ContactReport 
{
	static Logger logger = Logger.getLogger(ContactReport.class.getName());
	String fname;
	private db DB = db.getInstance();
	public ContactReport (String name) {fname = new String (name);}
	
	public void GenerateReport()
	{
	try {
		Timestamp dt;
		DTPicker dlg = new DTPicker();
		dlg.dtime = new Timestamp (System.currentTimeMillis());
		if (dlg.doModal() == true)
			{
			dt = dlg.dtime;
			logger.info("Time to generate contact report from : "+dlg.dtime.toString());
			}
		else
			return;
		Vector<dbContact> lrecs = DB.GetForeignRecs(dt);
		if (lrecs.size() <= 0)
			return;
		PrintWriter o = new PrintWriter(new FileOutputStream(fname));
		String s = new String ();
		ContactLogger main = ContactLogger.getInstance();
		s = "Foreign Contact Report for "+main.Name+" ("+main.Call+")\n";
		o.write(s);
		Timestamp now = new Timestamp (System.currentTimeMillis());
		SimpleDateFormat sdf = new SimpleDateFormat ("dd MMM yyyy ", Locale.US);
		s = "Report issued on : "+sdf.format(now)+".\n";
		o.write(s);
		s  = "No Unusual content or questions were present in these contacts.\n";
		o.write(s);
		s = "Full transcripts available on request.\n\n";
		o.write(s);
		s = "Date\t \t\t";
		s += "Time\t\t";
		s += "Station ";
		s +="Country\t \t";
		s += "Operator\t";
		s += "Location\t \t";
		s += "Frequency\t";
		s += "notes\n";
		o.write(s);
		sdf = new SimpleDateFormat ("MM/dd/yy\t HH:mm");
		for (int i = 0; i < lrecs.size(); i++)
			{
			dbContact dbc = lrecs.get(i);
			s = sdf.format(dbc.ContTime);
			s+= "\t" + dbc.CallSign + "\t" + dbc.Country;
			s += "\t" + dbc.Name + "\t" + dbc.City;
			if (dbc.City.length() < 8)
				s+="\t";
			s+= "\t" +  String.valueOf(dbc.Freq)+" MHz";
			s+= "\t"+dbc.Comment+"\n";
			o.write(s);
			}
		o.close();
		}
	catch (IOException ex)
		{
   		logger.debug("Exception - failed to generate contact report");
  	 	}
	}
}
