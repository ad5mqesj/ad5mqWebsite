package ad5mq;

import java.awt.Dimension;
import java.awt.Rectangle;

public class ScaledCtrlRect 
{
	private static final ScaledCtrlRect INSTANCE = new ScaledCtrlRect();
	private float wscale = 1.0f;
	private float hscale = 1.0f; 
	
	private ScaledCtrlRect()
		{
		}
	
	public static final ScaledCtrlRect getInstance() 
		{
	    return INSTANCE;
	    }
	
	public void setMainWndSize (int wid, int ht)
		{
		wscale = (float)wid/755.0f;
		hscale = (float)ht/488.0f;
		}
	
	public Rectangle getScaledRect (int w, int h, int l, int t)
		{
		int sw, sh, sl, st;
		Rectangle rect;
		sw = (int)((float)w * wscale);
		sl = (int)((float)l * wscale);
		sh = (int)((float)h * hscale);
		st = (int)((float)t * hscale);
		rect = new Rectangle (sw,sh,sl,st);
		return rect;
		}
	
	public Dimension getScaledDImension (int w, int h)
		{
		Dimension d;
		int sw,sh;
		sw = (int)((float)w * wscale);
		sh = (int)((float)h * hscale);
		
		d = new Dimension (sw,sh);
		return d;
		}
	public int getScaledHeight (int h)
		{
		int sh;
		sh = (int)((float)h * hscale);
		return sh;
		}
}
