package ad5mq;

import javax.swing.JPanel;
import java.awt.Frame;
import javax.swing.JDialog;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;
import javax.swing.SwingConstants;
import java.awt.Point;
import javax.swing.JTextField;
import javax.swing.JButton;

public class UserInfo extends JDialog {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JLabel NmLbl = null;
	private JLabel CsLbl = null;
	private JLabel GrLbl = null;
	private JLabel QtLbl = null;
	private JTextField NameFld = null;
	private JTextField CallFld = null;
	private JTextField GridFld = null;
	private JTextField QthFld = null;
	private JButton Ok = null;
	private JButton Cancel = null;

	public String Name = null;
	public String Call = null;
	public String Grid = null;
	public String Qth = null;
	public boolean bOk = false;
	
	/**
	 * @param owner
	 */
	public UserInfo(Frame owner) 
		{
		super(owner);
		Name = new String();
		Call = new String ();
		Grid = new String ();
		Qth = new String ();
		initialize();
		}

	public UserInfo() 
		{
		super();
		Name = new String();
		Call = new String ();
		Grid = new String ();
		Qth = new String ();
		initialize();
		}
	
	public void DoModal ()
		{
		NameFld.setText(Name);
		CallFld.setText(Call);
		GridFld.setText(Grid);
		QthFld.setText(Qth);
		this.setModal(true);
		this.setVisible(true);
		}
	
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() 
		{
		this.setSize(310, 187);
		this.setTitle("User Info");
		this.setContentPane(getJContentPane());
		}

	
	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			QtLbl = new JLabel();
			QtLbl.setText("QTH :");
			QtLbl.setSize(new Dimension(42, 16));
			QtLbl.setLocation(new Point(49, 88));
			QtLbl.setHorizontalAlignment(SwingConstants.RIGHT);
			GrLbl = new JLabel();
			GrLbl.setText("Grid locator :");
			GrLbl.setSize(new Dimension(76, 16));
			GrLbl.setLocation(new Point(15, 68));
			GrLbl.setHorizontalAlignment(SwingConstants.RIGHT);
			CsLbl = new JLabel();
			CsLbl.setText("Call Sign :");
			CsLbl.setSize(new Dimension(70, 16));
			CsLbl.setLocation(new Point(20, 48));
			CsLbl.setHorizontalAlignment(SwingConstants.RIGHT);
			NmLbl = new JLabel();
			NmLbl.setBounds(new Rectangle(27, 28, 64, 16));
			NmLbl.setHorizontalAlignment(SwingConstants.RIGHT);
			NmLbl.setText("Name : ");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(NmLbl, null);
			jContentPane.add(CsLbl, null);
			jContentPane.add(GrLbl, null);
			jContentPane.add(QtLbl, null);
			jContentPane.add(getNameFld(), null);
			jContentPane.add(getCallFld(), null);
			jContentPane.add(getGridFld(), null);
			jContentPane.add(getQthFld(), null);
			jContentPane.add(getOk(), null);
			jContentPane.add(getCancel(), null);
			NameFld.setText(Name);
			CallFld.setText(Call);
			GridFld.setText(Grid);
			QthFld.setText(Qth);
			}
		return jContentPane;
	}

	/**
	 * This method initializes NameFld	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getNameFld() {
		if (NameFld == null) {
			NameFld = new JTextField();
			NameFld.setBounds(new Rectangle(91, 28, 196, 16));
			NameFld.setPreferredSize(new Dimension(4, 16));
			NameFld.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
				{
					Name = NameFld.getText();
				}
			});
		}
		return NameFld;
	}

	/**
	 * This method initializes CallFld	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getCallFld() {
		if (CallFld == null) {
			CallFld = new JTextField();
			CallFld.setBounds(new Rectangle(91, 48, 196, 16));
			CallFld.setPreferredSize(new Dimension(4, 16));
			CallFld.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
				{
					Call = CallFld.getText();
				}
			});
		}
		return CallFld;
	}

	/**
	 * This method initializes GridFld	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getGridFld() {
		if (GridFld == null) {
			GridFld = new JTextField();
			GridFld.setBounds(new Rectangle(91, 68, 196, 16));
			GridFld.setPreferredSize(new Dimension(4, 16));
			GridFld.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
					{
					Grid = GridFld.getText();
					}
			});
		}
		return GridFld;
	}

	/**
	 * This method initializes QthFld	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getQthFld() {
		if (QthFld == null) {
			QthFld = new JTextField();
			QthFld.setBounds(new Rectangle(91, 88, 196, 16));
			QthFld.setPreferredSize(new Dimension(4, 16));
			QthFld.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
					{
					Qth = QthFld.getText();
					}
			});
		}
		return QthFld;
	}

	/**
	 * This method initializes Ok	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getOk() {
		if (Ok == null) {
			Ok = new JButton();
			Ok.setBounds(new Rectangle(20, 120, 88, 18));
			Ok.setText("Ok");
			Ok.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					bOk = true;
					setVisible (false);
					dispose();
					}
			});
		}
		return Ok;
	}

	/**
	 * This method initializes Cancel	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getCancel() {
		if (Cancel == null) {
			Cancel = new JButton();
			Cancel.setBounds(new Rectangle(200, 120, 88, 18));
			Cancel.setText("Cancel");
			Cancel.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					bOk = false;
					setVisible (false);
					dispose();
					}
			});
		}
		return Cancel;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
