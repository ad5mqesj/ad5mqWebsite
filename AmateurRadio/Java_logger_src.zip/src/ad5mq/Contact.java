package ad5mq;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.StreamTokenizer;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;
import java.util.Vector;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import javax.swing.JTextPane;

import org.apache.log4j.Logger;
public class Contact extends JPanel {

	private static final long serialVersionUID = 1L;
	private JLabel CSLbljLabel = null;
	private JTextField CallSign = null;
	private JLabel PClbl = null;
	private JTextField PrevCont = null;
	private JLabel NmLbl = null;
	private JTextField NameText = null;
	private JLabel BndLbl = null;
	private JComboBox Band = null;
	private JLabel FrqLbl = null;
	private JTextField Freq = null;
	private JLabel CtLbl = null;
	private JTextField City = null;
	private JLabel StatLbl = null;
	private JComboBox State = null;
	private JLabel TCLbl = null;
	private JLabel NumContacts = null;
	private JLabel StatWrkLbl = null;
	private JLabel StatesWorked = null;
	private JLabel CntWrkLbl = null;
	private JLabel CountriesWorked = null;
	private JLabel CntLbl = null;
	private JTextField Country = null;
	private JLabel ModLbl = null;
	private JComboBox Mode = null;
	private JCheckBox QSL = null;
	private JComboBox QSLTYPE = null;
	private JCheckBox QSLSENT = null;
	private JLabel XMPLbl = null;
	private JTextField XmitPower = null;
	private JLabel SigLbl = null;
	private JTextField Sig1 = null;
	private JTextField Sig2 = null;
	private JTextField Sig3 = null;
	private JLabel MySigLbl = null;
	private JTextField MySig1 = null;
	private JTextField MySig2 = null;
	private JTextField MySig3 = null;
	private JLabel TimLbl = null;
	private JLabel ContactTime = null;
	private JButton AdjustTime = null;
	private JLabel NumXmtLbl = null;
	private JTextField NumXmitrs = null;
	private JLabel ClsLbl = null;
	private JComboBox FDClass = null;
	private JLabel SecLbl = null;
	private JComboBox Section = null;
	private JLabel CmntLbl = null;
	private JTextPane Comments = null;
	private JButton AddCont = null;
	private JButton EditCont = null;

	static Logger logger = Logger.getLogger(Contact.class.getName());

	public dbContact contDat;
	public int numTotalCont;
	public int numStates;
	public int numCountries;
	public boolean FDMode = false;
	public db DB = db.getInstance();
	
	private StateFile sf;
	public enum QslType {eqsl,beauro,mail,Invalid;
	public static QslType convert (int i) 
		{
		for (QslType current : values()) 
			{
			if (current.ordinal() == i) 
				return current;
			}
		return null;
		}
	};//end of enum class
	public QslType QType = QslType.eqsl;
	public static String [] QslTypeStr={"Eqsl.cc", "Beauro", "Mail", ""};
	public void setQType (String s)
		{
		for (int i = 0; QslTypeStr[i].length()>0; i++)
			{
			if (QslTypeStr[i].contains(s))
				QType = QslType.convert(i);
			}
		}
	public static String getStrLevel (QslType l)
		{
		String rets = null;
		rets = new String (QslTypeStr[l.ordinal()]);
		return rets;
		}
	public static String [] BandStr = {"2190 m","160 m","80 m","40 m","30 m","20 m","17 m","15 m","12 m",
										"10 m","6 m","2 m","1.25 m","70 cm","33 cm","23 cm","13 cm",
										"9 cm", "6 cm","3 cm","1.25 cm","6 mm","4 mm","2.5 mm","2 mm","1 mm",""};
	
	public static String [] ModeStr = {"SSB","CW","FM","AM","Amtor","ASCII","ATV","BPSK","Clover",
									   "Fax","Feld-HELL","FM-HELL","FSK441","GTOR","HELL","HFSK",
									   "JT44","JT65","JT6M","MFSK8","MFSK16","MTTY","MT63","OLIVIA",
									   "Packet","Pactor","Pactor-II","Pactor-III","PCW","PSK-HELL",
									   "PSK31","PSK63","PSK125","QPSK","Q15X25","RTTY","SSTV","Throb",""};
	public Vector<String> Sections;
	public Countries cf;
	public static String [] Classes = {"A","B","C","D","E","F",""};
	private static Contact instance = new Contact();
	
	public static Contact getInstance(){return instance;};
	/**
	 * This is the default constructor
	 */
	private Contact() 
		{
		super();
		sf = new StateFile();
		sf.ReadStateFile();
		cf = new Countries ();
		contDat = new dbContact();
		Sections = new Vector<String>();
		try {
			FileReader fr = new FileReader("config/sections.txt");
	        BufferedReader br = new BufferedReader(fr);
	        StreamTokenizer st = new StreamTokenizer(br);
	        st.resetSyntax();
	        st.slashStarComments(true);
	        st.whitespaceChars(',', ',');
	        st.whitespaceChars('\t', '\t');
	        st.wordChars('A', 'Z');
	        st.wordChars('a', 'z');
	        st.wordChars(' ', ' ');
	        int tok;
	        while ((tok = st.nextToken()) != StreamTokenizer.TT_EOF) 
	        	{
	        	if (tok == StreamTokenizer.TT_WORD)
		        	{
	        		Sections.add(st.sval);
		        	}//if token is a word
		    	}//while there is more input
		    br.close();	        
			}//try
		//if there is no file - create back door user to start
		catch (IOException e)
			{
			}
		initialize();
		}
	/*
	 * this sets all fields with the data in conDat
	 */
	public void ShowSet()
		{
		numTotalCont = DB.GetTotalConts();
		numStates = DB.GetNumStates();
		numCountries = DB.GetNumCountries();
		NumberFormat formatter = new DecimalFormat("###.000");
		NumberFormat intformat = new DecimalFormat("###");
		String s;
		CallSign.setText(contDat.CallSign);
		s= intformat.format(contDat.numPrev);
		PrevCont.setText (s);
		NameText.setText(contDat.Name);
		Band.setSelectedItem(contDat.Band);
		s= formatter.format(contDat.Freq);
		Freq.setText (s);
		City.setText(contDat.City);
		if (contDat.State.length()>0)
			State.setSelectedItem(sf.FindStateByAbbr(contDat.State));
		else if (contDat.Section.length()>0)
			State.setSelectedItem(sf.FindStateByAbbr(contDat.Section));
		else
			State.setSelectedItem("");
		s = intformat.format (numTotalCont);
		NumContacts.setText(s);
		s = intformat.format (numStates);
		StatesWorked.setText (s);
		s = intformat.format (numCountries);
		CountriesWorked.setText (s);
		Country.setText(contDat.Country);
		Mode.setSelectedItem(contDat.Mode);
		boolean b = false;
		if (contDat.QSL != 0)
			b = true;
		QSL.setSelected(b);
		b = false;
		if (contDat.QSLSENT != 0)
			b = true;
		QSLSENT.setSelected(b);
		if (contDat.QSLType >= 0 && contDat.QSLType < 4)
			{
			QType = QslType.convert (contDat.QSLType);
			}
		else
			{
			QType = QslType.eqsl;
			}
		QSLTYPE.setSelectedItem(getStrLevel(QType));
		SimpleDateFormat sdf = new SimpleDateFormat ("hh:mm MMM dd yyyy ", Locale.US);
		ContactTime.setText(sdf.format(contDat.ContTime));
		s = intformat.format (contDat.XmitPwr);
		XmitPower.setText(s);
		NumXmitrs.setText(intformat.format (contDat.numXmit));
		FDClass.setSelectedItem(contDat.Class);
		Section.setSelectedItem(contDat.Section);
		Comments.setText(contDat.Comment);
		if (contDat.SigRep.length() > 0)
			{
			s = contDat.SigRep.substring(0, 1);
			Sig1.setText (s);
			s = contDat.SigRep.substring(2,3);
			Sig2.setText (s);
			s = contDat.SigRep.substring(4,5);
			Sig3.setText (s);
			}
		else
			{
			Sig1.setText ("5");
			Sig2.setText ("9");
			Sig3.setText ("9");
			}
		if (contDat.MySigRep.length()>0)
			{
			s = contDat.MySigRep.substring(0, 1);
			MySig1.setText (s);
			s = contDat.MySigRep.substring(2, 3);
			MySig2.setText (s);
			s = contDat.MySigRep.substring(4, 5);
			MySig3.setText (s);
			}
/*		else
			{
			MySig1.setText ("5");
			MySig2.setText ("9");
			MySig3.setText ("9");
			}
*/
		else //didnt previously exist so no entry
			{
			MySig1.setText ("");
			MySig2.setText ("");
			MySig3.setText ("");
			}
		//hide field day specific stuff if not fd mode
		if (!FDMode)
			{
			FDClass.setVisible(false);
			Section.setVisible(false);
			NumXmitrs.setVisible(false);
			NumXmtLbl.setVisible(false);
			ClsLbl.setVisible(false);
			SecLbl.setVisible(false);
			}
		else
			{
			FDClass.setVisible(true);
			Section.setVisible(true);
			NumXmitrs.setVisible(true);
			NumXmtLbl.setVisible(true);
			ClsLbl.setVisible(true);
			SecLbl.setVisible(true);
			}
		}//ShowSet

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() 
		{
		CmntLbl = new JLabel();
		CmntLbl.setBounds(new Rectangle(15, 283, 76, 16));
		CmntLbl.setText("Comments");
		SecLbl = new JLabel();
		SecLbl.setBounds(new Rectangle(246, 255, 69, 16));
		SecLbl.setHorizontalTextPosition(SwingConstants.RIGHT);
		SecLbl.setText("Section :");
		SecLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		ClsLbl = new JLabel();
		ClsLbl.setBounds(new Rectangle(132, 255, 51, 16));
		ClsLbl.setHorizontalTextPosition(SwingConstants.RIGHT);
		ClsLbl.setText("Class :");
		ClsLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		NumXmtLbl = new JLabel();
		NumXmtLbl.setBounds(new Rectangle(14, 255, 72, 16));
		NumXmtLbl.setHorizontalTextPosition(SwingConstants.RIGHT);
		NumXmtLbl.setText("# of Xmit :");
		NumXmtLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		ContactTime = new JLabel();
		ContactTime.setBounds(new Rectangle(110, 225, 179, 16));
		ContactTime.setHorizontalTextPosition(SwingConstants.CENTER);
		ContactTime.setText("20 September, 2008 21:34");
		ContactTime.setHorizontalAlignment(SwingConstants.CENTER);
		TimLbl = new JLabel();
		TimLbl.setBounds(new Rectangle(10, 225, 92, 16));
		TimLbl.setHorizontalTextPosition(SwingConstants.RIGHT);
		TimLbl.setText("Time (UTC) :");
		TimLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		MySigLbl = new JLabel();
		MySigLbl.setBounds(new Rectangle(276, 195, 78, 16));
		MySigLbl.setHorizontalTextPosition(SwingConstants.RIGHT);
		MySigLbl.setText("My Signal :");
		MySigLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		SigLbl = new JLabel();
		SigLbl.setBounds(new Rectangle(149, 195, 59, 16));
		SigLbl.setHorizontalTextPosition(SwingConstants.RIGHT);
		SigLbl.setText("Signal :");
		SigLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		XMPLbl = new JLabel();
		XMPLbl.setBounds(new Rectangle(9, 195, 91, 16));
		XMPLbl.setHorizontalTextPosition(SwingConstants.RIGHT);
		XMPLbl.setText("Xmit Power :");
		XMPLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		ModLbl = new JLabel();
		ModLbl.setBounds(new Rectangle(203, 135, 50, 16));
		ModLbl.setHorizontalTextPosition(SwingConstants.RIGHT);
		ModLbl.setText("Mode :");
		ModLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		CntLbl = new JLabel();
		CntLbl.setBounds(new Rectangle(4, 135, 65, 16));
		CntLbl.setHorizontalTextPosition(SwingConstants.RIGHT);
		CntLbl.setText("Country :");
		CntLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		CountriesWorked = new JLabel();
		CountriesWorked.setBounds(new Rectangle(413, 14, 32, 16));
		CountriesWorked.setHorizontalTextPosition(SwingConstants.CENTER);
		CountriesWorked.setText("299");
		CountriesWorked.setHorizontalAlignment(SwingConstants.CENTER);
		CntWrkLbl = new JLabel();
		CntWrkLbl.setBounds(new Rectangle(280, 15, 130, 16));
		CntWrkLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		CntWrkLbl.setHorizontalTextPosition(SwingConstants.RIGHT);
		CntWrkLbl.setText("Countries Worked :");
		CntWrkLbl.setToolTipText("Enter Call sign of contact here");
		StatesWorked = new JLabel();
		StatesWorked.setBounds(new Rectangle(246, 15, 31, 16));
		StatesWorked.setHorizontalTextPosition(SwingConstants.CENTER);
		StatesWorked.setText("165");
		StatesWorked.setHorizontalAlignment(SwingConstants.CENTER);
		StatWrkLbl = new JLabel();
		StatWrkLbl.setBounds(new Rectangle(144, 15, 101, 16));
		StatWrkLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		StatWrkLbl.setHorizontalTextPosition(SwingConstants.RIGHT);
		StatWrkLbl.setText("States Worked :");
		StatWrkLbl.setToolTipText("Enter Call sign of contact here");
		NumContacts = new JLabel();
		NumContacts.setBounds(new Rectangle(107, 15, 38, 16));
		NumContacts.setHorizontalAlignment(SwingConstants.CENTER);
		NumContacts.setHorizontalTextPosition(SwingConstants.CENTER);
		NumContacts.setText("3065");
		TCLbl = new JLabel();
		TCLbl.setBounds(new Rectangle(4, 15, 102, 16));
		TCLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		TCLbl.setHorizontalTextPosition(SwingConstants.RIGHT);
		TCLbl.setText("Total Contacts :");
		TCLbl.setToolTipText("Enter Call sign of contact here");
		StatLbl = new JLabel();
		StatLbl.setBounds(new Rectangle(203, 103, 53, 16));
		StatLbl.setHorizontalTextPosition(SwingConstants.RIGHT);
		StatLbl.setText("State :");
		StatLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		CtLbl = new JLabel();
		CtLbl.setBounds(new Rectangle(19, 102, 48, 16));
		CtLbl.setHorizontalTextPosition(SwingConstants.RIGHT);
		CtLbl.setText("City :");
		CtLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		FrqLbl = new JLabel();
		FrqLbl.setBounds(new Rectangle(325, 73, 52, 16));
		FrqLbl.setHorizontalTextPosition(SwingConstants.RIGHT);
		FrqLbl.setText("Freq :");
		FrqLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		BndLbl = new JLabel();
		BndLbl.setBounds(new Rectangle(208, 73, 47, 16));
		BndLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		BndLbl.setHorizontalTextPosition(SwingConstants.RIGHT);
		BndLbl.setText("Band :");
		NmLbl = new JLabel();
		NmLbl.setBounds(new Rectangle(9, 73, 59, 16));
		NmLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		NmLbl.setHorizontalTextPosition(SwingConstants.RIGHT);
		NmLbl.setText("Name :");
		PClbl = new JLabel();
		PClbl.setBounds(new Rectangle(207, 44, 136, 16));
		PClbl.setHorizontalAlignment(SwingConstants.RIGHT);
		PClbl.setHorizontalTextPosition(SwingConstants.RIGHT);
		PClbl.setText("Previous Contacts :");
		CSLbljLabel = new JLabel();
		CSLbljLabel.setBounds(new Rectangle(2, 44, 67, 16));
		CSLbljLabel.setHorizontalTextPosition(SwingConstants.RIGHT);
		CSLbljLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		CSLbljLabel.setToolTipText("Enter Call sign of contact here");
		CSLbljLabel.setText("Call Sign :");
		this.setSize(446, 520);
		this.setLayout(null);
		this.add(CSLbljLabel, null);
		this.add(getCallSign(), null);
		this.add(PClbl, null);
		this.add(getPrevCont(), null);
		this.add(NmLbl, null);
		this.add(getNameText(), null);
		this.add(BndLbl, null);
		this.add(getBand(), null);
		this.add(FrqLbl, null);
		this.add(getFreq(), null);
		this.add(CtLbl, null);
		this.add(getCity(), null);
		this.add(StatLbl, null);
		this.add(getState(), null);
		this.add(TCLbl, null);
		this.add(NumContacts, null);
		this.add(StatWrkLbl, null);
		this.add(StatesWorked, null);
		this.add(CntWrkLbl, null);
		this.add(CountriesWorked, null);
		this.add(CntLbl, null);
		this.add(getCountry(), null);
		this.add(ModLbl, null);
		this.add(getMode(), null);
		this.add(getQSL(), null);
		this.add(getQSLTYPE(), null);
		this.add(getQSLSENT(), null);
		this.add(XMPLbl, null);
		this.add(getXmitPower(), null);
		this.add(SigLbl, null);
		this.add(getSig1(), null);
		this.add(getSig2(), null);
		this.add(getSig3(), null);
		this.add(MySigLbl, null);
		this.add(getMySig1(), null);
		this.add(getMySig2(), null);
		this.add(getMySig3(), null);
		this.add(TimLbl, null);
		this.add(ContactTime, null);
		this.add(getAdjustTime(), null);
		this.add(NumXmtLbl, null);
		this.add(getNumXmitrs(), null);
		this.add(ClsLbl, null);
		this.add(getFDClass(), null);
		this.add(SecLbl, null);
		this.add(getSection(), null);
		this.add(CmntLbl, null);
		this.add(getComments(), null);
		this.add(getAddCont(), null);
		this.add(getEditCont(), null);
		}

	/**
	 * This method initializes CallSign	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getCallSign() {
		if (CallSign == null) {
			CallSign = new JTextField();
			CallSign.setBounds(new Rectangle(69, 42, 91, 20));
			CallSign.setText("AD5MQ/MM");
			CallSign.setHorizontalAlignment(JTextField.CENTER);
			CallSign.setToolTipText("Enter Call sign of contact here");
			CallSign.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
					{
					contDat = new dbContact();
					contDat.CallSign = CallSign.getText().toUpperCase();
					dbContact cd = DB.GetRecbyCallSign(contDat.CallSign);
					if (cd != null)
						{
						contDat = cd;
						ShowSet();
						return;
						}
					String cnt = cf.FindCountry(contDat.CallSign);
					if (cnt != null)
						contDat.Country = cnt;
					ShowSet();
					}
				});
		}
		return CallSign;
	}

	/**
	 * This method initializes PrevCont	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getPrevCont() {
		if (PrevCont == null) {
			PrevCont = new JTextField();
			PrevCont.setBounds(new Rectangle(348, 42, 34, 20));
			PrevCont.setToolTipText("Edit/enter # of previous contacts");
			PrevCont.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
					{
					contDat.numPrev = Integer.parseInt(PrevCont.getText());
					}
				});
		}
		return PrevCont;
	}

	/**
	 * This method initializes NameText	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getNameText() {
		if (NameText == null) {
			NameText = new JTextField();
			NameText.setBounds(new Rectangle(69, 71, 136, 20));
			NameText.setText("Jorge Xerxes Gonzales");
			NameText.setHorizontalAlignment(JTextField.CENTER);
			NameText.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
					{
					contDat.Name = NameText.getText();
					}
			});
		}
		return NameText;
	}

	/**
	 * This method initializes Band	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getBand() {
		if (Band == null) {
			Band = new JComboBox();
			Band.setBounds(new Rectangle(257, 71, 70, 20));
			Band.setEditable(true);
			Band.setName("Band");
			Band.setToolTipText("Select Band");
			for (int i = 0; BandStr[i].length() > 0; i++)
				Band.addItem (BandStr[i]);
			Band.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					contDat.Band = (String)Band.getSelectedItem();
					}
			});
		}
		return Band;
	}

	/**
	 * This method initializes Freq	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getFreq() {
		if (Freq == null) {
			Freq = new JTextField();
			Freq.setBounds(new Rectangle(377, 71, 61, 20));
			Freq.setText("14.07011");
			Freq.setToolTipText("Edit/enter # of previous contacts");
			Freq.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
					{
					contDat.Freq = Double.parseDouble(Freq.getText());
					}
			});
		}
		return Freq;
	}

	/**
	 * This method initializes City	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getCity() {
		if (City == null) {
			City = new JTextField();
			City.setBounds(new Rectangle(69, 100, 130, 20));
			City.setHorizontalAlignment(JTextField.CENTER);
			City.setText("Torrelevaga");
			City.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
					{
					contDat.City = City.getText();
					}
			});
		}
		return City;
	}

	/**
	 * This method initializes State	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getState() {
		if (State == null) {
			State = new JComboBox();
			State.setBounds(new Rectangle(257, 101, 150, 20));
			State.setToolTipText("Select State");
			State.setEditable(true);
			State.setName("State");
			for (int i = 0; i < sf.GetNumStates(); i++)
				State.addItem(sf.GetStateAt(i));
			State.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					contDat.State = sf.FindAbbrByState((String)State.getSelectedItem());
					}
			});
		}
		return State;
	}

	/**
	 * This method initializes Country	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getCountry() {
		if (Country == null) {
			Country = new JTextField();
			Country.setBounds(new Rectangle(69, 133, 142, 20));
			Country.setHorizontalAlignment(JTextField.CENTER);
			Country.setText("Russian Federation");
			Country.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
					{
					contDat.Country = Country.getText();
					}
			});
		}
		return Country;
	}

	/**
	 * This method initializes Mode	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getMode() {
		if (Mode == null) {
			Mode = new JComboBox();
			Mode.setBounds(new Rectangle(257, 133, 114, 20));
			Mode.setToolTipText("Select Mode");
			Mode.setEditable(true);
			Mode.setName("Mode");
			for (int i = 0; ModeStr[i].length() > 0; i++)
				Mode.addItem(ModeStr[i]);
			Mode.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					contDat.Mode = (String)Mode.getSelectedItem();
					}
			});
		}
		return Mode;
	}

	/**
	 * This method initializes QSL	
	 * 	
	 * @return javax.swing.JCheckBox	
	 */
	private JCheckBox getQSL() {
		if (QSL == null) {
			QSL = new JCheckBox();
			QSL.setBounds(new Rectangle(13, 165, 74, 21));
			QSL.setText("QSL?");
			QSL.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					if (QSL.isSelected())
						contDat.QSL = 1;
					else
						contDat.QSL = 0;
					}
			});
		}
		return QSL;
	}

	/**
	 * This method initializes QSLTYPE	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getQSLTYPE() {
		if (QSLTYPE == null) {
			QSLTYPE = new JComboBox();
			QSLTYPE.setBounds(new Rectangle(86, 166, 119, 20));
			QSLTYPE.setToolTipText("Select QSL Type");
			QSLTYPE.setEditable(true);
			QSLTYPE.setName("QSL Type");
			for (int i = 0; QslTypeStr[i].length() > 0; i++)
				QSLTYPE.addItem(QslTypeStr[i]);
			QSLTYPE.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					try{
					contDat.QSLType = QslType.valueOf((String)QSLTYPE.getSelectedItem()).ordinal();}
					catch (Exception ex3){	
						contDat.QSLType = QslType.eqsl.ordinal();
						}
					}
			});
		}
		return QSLTYPE;
	}

	/**
	 * This method initializes QSLSENT	
	 * 	
	 * @return javax.swing.JCheckBox	
	 */
	private JCheckBox getQSLSENT() {
		if (QSLSENT == null) {
			QSLSENT = new JCheckBox();
			QSLSENT.setBounds(new Rectangle(246, 162, 107, 24));
			QSLSENT.setText("QSL Sent?");
			QSLSENT.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					if (QSLSENT.isSelected())
						contDat.QSLSENT = 1;
					else
						contDat.QSLSENT = 0;
					}
			});
		}
		return QSLSENT;
	}

	/**
	 * This method initializes XmitPower	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getXmitPower() {
		if (XmitPower == null) {
			XmitPower = new JTextField();
			XmitPower.setBounds(new Rectangle(106, 193, 36, 20));
			XmitPower.setText("865");
			XmitPower.setHorizontalAlignment(JTextField.CENTER);
			XmitPower.setToolTipText("Edit/enter # of previous contacts");
			XmitPower.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
					{
					contDat.XmitPwr = Integer.parseInt(XmitPower.getText());
					}
			});
		}
		return XmitPower;
	}

	/**
	 * This method initializes Sig1	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getSig1() {
		if (Sig1 == null) {
			Sig1 = new JTextField();
			Sig1.setBounds(new Rectangle(213, 193, 16, 20));
			Sig1.setText("5");
			Sig1.setHorizontalAlignment(JTextField.CENTER);
			Sig1.setToolTipText("Edit/enter # of previous contacts");
			Sig1.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
					{
					String s = new String();
					s = Sig1.getText();
					s += ":";
					s += Sig2.getText();
					s += ":";
					s += Sig3.getText();
					contDat.SigRep = s;
					}
			});
		}
		return Sig1;
	}

	/**
	 * This method initializes Sig2	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getSig2() {
		if (Sig2 == null) {
			Sig2 = new JTextField();
			Sig2.setBounds(new Rectangle(230, 193, 16, 20));
			Sig2.setText("9");
			Sig2.setHorizontalAlignment(JTextField.CENTER);
			Sig2.setToolTipText("Edit/enter # of previous contacts");
			Sig2.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) {
					String s = new String();
					s = Sig1.getText();
					s += ":";
					s += Sig2.getText();
					s += ":";
					s += Sig3.getText();
					contDat.SigRep = s;
					}
			});
		}
		return Sig2;
	}

	/**
	 * This method initializes Sig3	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getSig3() {
		if (Sig3 == null) {
			Sig3 = new JTextField();
			Sig3.setBounds(new Rectangle(247, 193, 16, 20));
			Sig3.setText("9");
			Sig3.setHorizontalAlignment(JTextField.CENTER);
			Sig3.setToolTipText("Edit/enter # of previous contacts");
			Sig3.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
					{
					String s = new String();
					s = Sig1.getText();
					s += ":";
					s += Sig2.getText();
					s += ":";
					s += Sig3.getText();
					contDat.SigRep = s;
					}
			});
		}
		return Sig3;
	}

	/**
	 * This method initializes MySig1	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getMySig1() {
		if (MySig1 == null) {
			MySig1 = new JTextField();
			MySig1.setBounds(new Rectangle(360, 193, 16, 20));
			MySig1.setText("5");
			MySig1.setHorizontalAlignment(JTextField.CENTER);
			MySig1.setToolTipText("Edit/enter # of previous contacts");
			MySig1.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
					{
					String s = new String();
					s = MySig1.getText();
					s += ":";
					s += MySig2.getText();
					s += ":";
					s += MySig3.getText();
					contDat.MySigRep = s;
					}
			});
		}
		return MySig1;
	}

	/**
	 * This method initializes MySig2	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getMySig2() {
		if (MySig2 == null) {
			MySig2 = new JTextField();
			MySig2.setBounds(new Rectangle(377, 193, 16, 20));
			MySig2.setText("9");
			MySig2.setHorizontalAlignment(JTextField.CENTER);
			MySig2.setToolTipText("Edit/enter # of previous contacts");
			MySig2.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) {
					String s = new String();
					s = MySig1.getText();
					s += ":";
					s += MySig2.getText();
					s += ":";
					s += MySig3.getText();
					contDat.MySigRep = s;
				}
			});
		}
		return MySig2;
	}

	/**
	 * This method initializes MySig3	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getMySig3() {
		if (MySig3 == null) {
			MySig3 = new JTextField();
			MySig3.setBounds(new Rectangle(394, 193, 16, 20));
			MySig3.setText("9");
			MySig3.setHorizontalAlignment(JTextField.CENTER);
			MySig3.setToolTipText("Edit/enter # of previous contacts");
			MySig3.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) {
					String s = new String();
					s = MySig1.getText();
					s += ":";
					s += MySig2.getText();
					s += ":";
					s += MySig3.getText();
					contDat.MySigRep = s;
				}
			});
		}
		return MySig3;
	}

	/**
	 * This method initializes AdjustTime	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getAdjustTime() {
		if (AdjustTime == null) {
			AdjustTime = new JButton();
			AdjustTime.setBounds(new Rectangle(302, 224, 93, 17));
			AdjustTime.setToolTipText("Click to modify contact time");
			AdjustTime.setText("Adjust");
			AdjustTime.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					DTPicker dlg = new DTPicker();
					dlg.dtime = contDat.ContTime;
					if (dlg.doModal() == true)
						{
						contDat.ContTime = dlg.dtime;
						SimpleDateFormat sdf = new SimpleDateFormat ("hh:mm MMM dd yyyy ", Locale.US);
						ContactTime.setText(sdf.format(contDat.ContTime));
						logger.info("Changed contact time to : "+dlg.dtime.toString());
						}
					}
			});
		}
		return AdjustTime;
	}

	/**
	 * This method initializes NumXmitrs	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getNumXmitrs() {
		if (NumXmitrs == null) {
			NumXmitrs = new JTextField();
			NumXmitrs.setBounds(new Rectangle(92, 253, 32, 20));
			NumXmitrs.setText("865");
			NumXmitrs.setHorizontalAlignment(JTextField.CENTER);
			NumXmitrs.setToolTipText("Edit/enter # of previous contacts");
			NumXmitrs.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
					{
					contDat.numXmit = Integer.parseInt(NumXmitrs.getText());
					}
			});
		}
		return NumXmitrs;
	}

	/**
	 * This method initializes FDClass	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getFDClass() {
		if (FDClass == null) {
			FDClass = new JComboBox();
			FDClass.setBounds(new Rectangle(185, 253, 50, 20));
			FDClass.setToolTipText("Select Band");
			FDClass.setEditable(true);
			FDClass.setName("Class");
			FDClass.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					contDat.Class = (String)FDClass.getSelectedItem();
					}
			});
		for (int i = 0; i < Classes.length; i++)
			FDClass.addItem(Classes[i]);
		}
		return FDClass;
	}

	/**
	 * This method initializes Section	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getSection() {
		if (Section == null) {
			Section = new JComboBox();
			Section.setBounds(new Rectangle(318, 253, 60, 20));
			Section.setToolTipText("Select Band");
			Section.setEditable(true);
			Section.setName("Section");
			Section.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					contDat.Section = (String)Section.getSelectedItem();
					}
			});
		for (int i = 0; i < Sections.size(); i++)
			Section.addItem(Sections.get(i));
		}
		return Section;
	}

	/**
	 * This method initializes Comments	
	 * 	
	 * @return javax.swing.JTextPane	
	 */
	private JTextPane getComments() 
		{
		if (Comments == null) 
			{
			Comments = new JTextPane();
			Comments.setBounds(new Rectangle(16, 306, 419, 160));
			Comments.addFocusListener(new java.awt.event.FocusAdapter() 
				{
				public void focusLost(java.awt.event.FocusEvent e) 
					{
					contDat.Comment = Comments.getText();
					}
				});
			}
		return Comments;
		}

	/**
	 * This method initializes AddCont	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getAddCont() {
		if (AddCont == null) {
			AddCont = new JButton();
			AddCont.setBounds(new Rectangle(20, 486, 132, 20));
			AddCont.setText("Add Contact");
			AddCont.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					contDat.ContTime = new Timestamp(System.currentTimeMillis());
					//make time GMT
					TimeZone stz = TimeZone.getDefault();
					long l = contDat.ContTime.getTime() - stz.getRawOffset();
					contDat.ContTime = new Timestamp (l);
					contDat.numPrev++;
					DB.PutNewLogEntry(contDat);
					TableView tb = TableView.getInstance();
					tb.PopulateTable();
					logger.info("Adding record for "+ contDat.CallSign);
				}
			});
		}
		return AddCont;
	}

	/**
	 * This method initializes EditCont	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getEditCont() {
		if (EditCont == null) {
			EditCont = new JButton();
			EditCont.setBounds(new Rectangle(285, 486, 145, 20));
			EditCont.setText("Edit Contact");
			EditCont.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					DB.EditLogEntry(contDat);
					TableView tb = TableView.getInstance();
					tb.PopulateTable();
					logger.info("Editing record for "+contDat.CallSign);
					}
			});
		}
		return EditCont;
	}

}  //  @jve:decl-index=0:visual-constraint="9,10"
