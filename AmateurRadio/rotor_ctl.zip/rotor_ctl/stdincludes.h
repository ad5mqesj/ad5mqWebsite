/*
 * stdincludes.h
 * Ed Johnson
 * 14 Sep 2009
 * standard include files for all c files
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <delays.h>

#include <p18f2320.h>			// Register definitions
#include <timers.h>				// Timer library functions
#include <usart.h>				// serial comm
#include <EEP.h>				// EE Prom

#include "globals.h"
#include "prototypes.h"
