/*
*	file	: comm.c
*	date	: 14 Sep 2009
*	auth	: Ed Johnson
*	contains routines to communicate serial
*
*/
#include "stdincludes.h"


void wrStr (char *data)
	{
	int i, len;
	char c;

	len = strlen (data);
	for (i=0;i<len;i++)
		{
		while(BusyUSART());
		c = data[i];
		c = (char)(c & 0x7f);
		TXREG = c;
		delay(10);
		}
	}/*wrStr*/


