/*
globals.h
Ed Johnson
14 Sep 2009
contains all global variables in ram
*/

#ifdef MAIN_INC
#define _STRG_QUAL
#else
#define _STRG_QUAL extern
#endif

#define	AZ_ON	0x02
#define AZ_DIR  0x01
#define EL_ON	0x08
#define EL_DIR	0x04
#define MON		0x10

#define CBUFSZ	32
_STRG_QUAL ram int lineticks;

_STRG_QUAL char inpbuf[CBUFSZ];
_STRG_QUAL char obuf[CBUFSZ];
_STRG_QUAL int ibufcnt;
_STRG_QUAL char cmdflg;
_STRG_QUAL char mvdoneflg;
_STRG_QUAL char moving;

_STRG_QUAL int azpos;
_STRG_QUAL int elpos;
