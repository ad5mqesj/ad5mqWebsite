/* prototypes.h
*  Author Ed Johnson
*  Date 14 Sep 2009
*  contains prototypes for all functions called across modules
*/

void delay (int);
void sendByte (char a);
void setup(void);
void wrStr (char *);
void dumpHex (char c);
void processCommand();
void putint (int x);
