/*
*	file	: main.c
*	date	: 14 Sep 2009
*	auth	: Ed Johnson
*	contains main entry point for rotor control firmware
*
*/

#pragma config OSC = INTIO1
#pragma config BOR = OFF
#pragma config PWRT = OFF
#pragma config WDT = OFF
#pragma config LVP = OFF
#pragma config MCLRE = ON
#pragma config CPD = OFF
#pragma config WRTD = OFF



//this define makes the globals in globals.h declarations
//instead of references to externals
#define MAIN_INC	1
#include "stdincludes.h"


void delay (int del)
	{
	int i,j;
	for (i = 0; i < del; i++)
		j = i + del/2;
	}

void main ()
{
unsigned char c,d;
char buf[8];
int newp, mo_amt;
OSCTUNE = 0x00;
OSCCON = 0x72;
ibufcnt = 0;
cmdflg = 0;
moving = 0;
mvdoneflg = 0;
memset (inpbuf,0,CBUFSZ);
memset (obuf,0,CBUFSZ);

//fetch last known positions
c = Read_b_eep (0);
d = Read_b_eep (2);
azpos = (((unsigned int)c << 8)&0x0100) | ((unsigned int)d&0x00ff);
c = Read_b_eep (4);
elpos = ((unsigned int)c);
setup();
delay(50);
strcpypgm2ram (obuf,(const rom char *)"Az-El Rotor Controller\r\n");
wrStr (obuf);
obuf[0]='A';
obuf[1] = '\0';
itoa (azpos,buf);
strcat (obuf,buf);
strcatpgm2ram (obuf,(const rom char *)":E");
itoa (elpos,buf);
strcat (obuf,buf);
strcatpgm2ram (obuf,(const rom char *)"\r\n");
wrStr (obuf);

while (1)
	{
	if (cmdflg)
		{
		if (inpbuf[0] == 'P') //show pos
			mvdoneflg = 1;
		else if (inpbuf[0] == 'Z') //zero pos now
			{
			azpos = 0;
			elpos = 0;
			}
		else if (inpbuf[0] == 'A' || inpbuf[0] == 'E')  //goto Az or El
			{
			if (moving)
				{	
				strcpypgm2ram (obuf,(const rom char *)"Moving\r\n");
				wrStr (obuf);
				}
			newp = atoi (&inpbuf[1]);
			if (inpbuf[0] == 'A')
				{
				mo_amt = newp - azpos;
				c = LATA;
				//set direction
				if (mo_amt < 0)
					{
					c |= AZ_DIR;
					LATA = c;
					mo_amt = azpos-newp;
					}
				else
					{
					c &= ~AZ_DIR;
					LATA = c;
					}
				//now distance = timer ticks / 10
				mo_amt = 65535 - (mo_amt * 15);
				PIR1bits.TMR1IF = 0;
				T1CONbits.TMR1ON = 0;   //STOP TIMER1 
				TMR1H = (unsigned char)((mo_amt >> 8)&0x00ff);
				TMR1L = (unsigned char)((mo_amt)&0x00ff);
				//turn on AZ motion
				c |= (AZ_ON|MON);
				LATA = c;
				//start timer - interrupt will fire when timer overflows
				moving = 1;
				T1CONbits.TMR1ON = 1;
				//go ahead and write new position
				azpos = newp;
				}
			else
				{
				mo_amt = newp - elpos;
				c = LATA;
				//set direction
				if (mo_amt < 0)
					{
					c |= EL_DIR;
					LATA = c;
					mo_amt = elpos-newp;
					}
				else
					{
					c &= ~EL_DIR;
					LATA = c;
					}
				//now distance = timer ticks / 10
				mo_amt = 65535 - (mo_amt * 10);
				PIR1bits.TMR1IF = 0;
				T1CONbits.TMR1ON = 0;   //STOP TIMER1 
				TMR1H = (unsigned char)((mo_amt >> 8)&0x00ff);
				TMR1L = (unsigned char)((mo_amt)&0x00ff);
				//turn on EL motion
				c |= (EL_ON|MON);
				LATA = c;
				//start timer - interrupt will fire when timer overflows
				moving = 1;
				T1CONbits.TMR1ON = 1;
				//go ahead and write new position
				elpos = newp;
				}
			}
		else
			{
			strcpypgm2ram (obuf,(const rom char *)"Unrecognized command : ");
			wrStr (obuf);
			wrStr (inpbuf);
			strcpypgm2ram (obuf,(const rom char *)"\r\n");
			wrStr (obuf);
			memset (obuf,0,CBUFSZ);
			memset (inpbuf,0,CBUFSZ);
			}
		ibufcnt = 0;
		cmdflg = 0;
		}	
	if (mvdoneflg)
		{
		obuf[0]='A';
		obuf[1] = '\0';
		itoa (azpos,buf);
		strcat (obuf,buf);
		strcatpgm2ram (obuf,(const rom char *)":E");
		itoa (elpos,buf);
		strcat (obuf,buf);
		strcatpgm2ram (obuf,(const rom char *)"\r\n");
		wrStr (obuf);
		mvdoneflg = 0;
		c = ((unsigned char)((azpos >> 8)&0x00ff)&0x01);
		Write_b_eep(0, c);
		Busy_eep();
		c= (unsigned char)((azpos)&0x00ff);
		Write_b_eep(2, c);
		Busy_eep();
		c= (unsigned char)((elpos)&0x00ff);
		Write_b_eep(4, c);
		Busy_eep();
		}		
	}//forever
}/*main*/

void setup()
{
unsigned char c;
TRISA = 0xE0;					//set 7-5 input, 0-4 output.
LATA = 0x00;					//all relays off initially 
TRISC = 0x97;					//enable SPI, USART, timer 1

			
INTCON = 0;						
INTCON2 = 0;
INTCON3 = 0;
PIR1bits.RCIF = 0;			//clear COMM receive flag
PIE1bits.RCIE = 1;			//enable COMM receive intrrupt
IPR1bits.RCIP = 1;			// comm is hi priority
PIR1bits.TMR1IF = 0;		//clear timer 1 flag
PIE1bits.TMR1IE = 1;		//enable timer 1 intrrupt
IPR1bits.TMR1IP = 1;		// timer 1 is also hi priority
RCONbits.IPEN = 1;			// enable intr. priority
INTCONbits.GIE = 1;			//enable interrupts globally


// Setup the USART for 9600 baud @ 8 MHz
  OpenUSART (USART_TX_INT_OFF &
             USART_RX_INT_ON &
             USART_ASYNCH_MODE &
             USART_EIGHT_BIT &
             USART_CONT_RX &
             USART_BRGH_LOW, 12);

T1CONbits.TMR1ON = 0;   //STOP TIMER1 
T1CONbits.RD16 = 1;
T1CONbits.T1RUN = 0;
T1CONbits.T1CKPS0 = 0;
T1CONbits.T1CKPS1 = 0;
T1CONbits.T1OSCEN = 0;
T1CONbits.T1SYNC = 1;
T1CONbits.TMR1CS = 1;
}