/*
interrupts.c
14 Nov 2008
Ed Johnson
interrupt handlers for port B change
*/
#include "stdincludes.h"


//----------------------------------------------------------------------------
// High priority interrupt routine

#pragma code
#pragma interrupt InterruptHandlerHigh

void
InterruptHandlerHigh ()
	{
	int i,j;
	unsigned char b, d, e;
	if (PIR1bits.RCIF)
		{
		PIE1bits.RCIE = 0;
		inpbuf[ibufcnt] =  ReadUSART();
		inpbuf[ibufcnt] = inpbuf[ibufcnt] & 0x7f;	//force capitals
		if (inpbuf[ibufcnt] == 0x0A || inpbuf[ibufcnt] == 0x0d)
			cmdflg = 1;
		//echo cahr back out
		while(BusyUSART());
		TXREG = inpbuf[ibufcnt];
		ibufcnt++;
		if (ibufcnt == CBUFSZ)
			ibufcnt = 0;
	   	PIR1bits.RCIF = 0;        //clear interrupt flag
		PIE1bits.RCIE = 1;       	//re-enable interrupt
		}//comm interrupt

	 if (PIR1bits.TMR1IF) //check timer 1 overflow
		{      
		PIE1bits.TMR1IE = 0;  
		//stop timer and stop moving
		T1CONbits.TMR1ON = 0;   //STOP TIMER1 
		moving = 0;
		mvdoneflg = 1;
		b = LATA;
		b &= ~(EL_ON|AZ_ON);
		LATA = b;			//dir moto main relay off
		delay(50);
		b &= ~MON;			//Aux relay off
		LATA = b;
		delay (50);
		LATA = 0x00;		//dir relays off
	   	PIR1bits.TMR1IF = 0;        //clear interrupt flag
		PIE1bits.TMR1IE = 1;       	//re-enable interrupt
	   	}
	}/*InterruptHandlerHigh*/

// High priority interrupt vector
#pragma code InterruptVectorHigh = 0x08
void
InterruptVectorHigh (void)
{
  _asm
    goto InterruptHandlerHigh //jump to interrupt routine
  _endasm
}
