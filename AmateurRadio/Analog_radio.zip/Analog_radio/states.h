/*
 * states.h
 * Ed Johnson
 * 16 Nov 2008
 * contains definitions and auxilliary info for main state machine
 */
 
 #define CWMODE			0
 #define SSBMODE		1

 #define MODEA			0
 #define MODEB			1
 
//delay time for 1ms
 #define DTIME			132
 
 #define IDLE			0
 #define RECEIVING		1
 #define TRANSMITTING	2
 
#define FREQENTRY		1
#define MENU			2
#define SETMODE			'1'
#define SETCWSPD		'2'
#define SETCWMODE		'3'
#define SETSPEED		'4'
