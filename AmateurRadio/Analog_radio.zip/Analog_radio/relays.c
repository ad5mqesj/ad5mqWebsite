/*
relays.c
14 Nov 2008
Ed Johnson
functions that manipulate the various relays
*/
#include "stdincludes.h"

void strobeRelays()
	{
	char b;

	Delay10TCYx (3);
	b = LATB;
	b |= RLY_STRB;
	LATB = b;
	delay (1);
	b = LATB;
	b &= ~RLY_STRB;
	LATB = b;
	}/*strobeRelays*/

void cycleRelays()
	{
	sendByte (0x01);
	strobeRelays();
	delay (500);
	sendByte (0x02);
	strobeRelays();
	delay (500);
	sendByte (0x04);
	strobeRelays();
	delay (500);
	sendByte (0x08);
	strobeRelays();
	delay (500);
	sendByte (0x10);
	strobeRelays();
	delay (500);
	sendByte (0x20);
	strobeRelays();
	delay (500);
	sendByte (0x40);
	strobeRelays();
	delay (500);
	}/*cycleRelays*/

void setRelay(int ry, int tx)
	{
	char rel = 1;
	if (!ry)
		{
		sendByte (0x00);
		strobeRelays();
		return;
		}
	if (ry < 1 || ry > 6)
		return;
	rel = rel << (ry - 1);
	if (tx)
		rel |= 0x40;
	else
		rel &= ~0x40;
	sendByte ((char)rel);
	strobeRelays();
	}/*setRelay*/

int setFreqBand (unsigned long freq)
	{
	int band;
	if (freq < 2000000)
		band = 1;
	else if (freq < 4200000)
		band = 2;
	else if (freq < 8000000)
		band = 3;
	else if (freq < 11000000)
		band = 4;
	else if (freq < 20000000)
		band = 5;
	else
		band = 6;
	return band;
	}/*setFreqBand*/

void setFilter (char u)
{
	if (u)	//hi band (2.85 KHz)
		{
		T2CONbits.TMR2ON = 0;  // STOP TIMER2 registers to POR state
		PR2 = 0x0D;
		CCPR2L = 0x07;
		T2CONbits.TMR2ON = 1;  // Restart TIMER2 
		}
	else //low band (800 Hz)
		{
		T2CONbits.TMR2ON = 0;  // STOP TIMER2 registers to POR state
		PR2 = 0x31;
		CCPR2L = 0x19;
		T2CONbits.TMR2ON = 1;  // Restart TIMER2 
		}
}/*setFilter*/