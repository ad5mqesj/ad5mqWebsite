/*
*	file	: dds.c
*	date	: 21 Oct 2008
*	auth	: Ed Johnson
*	contains routines to communicate with display, keypad, knob, paddle
*
*/
#include "stdincludes.h"


void wrStr (char *data)
	{
	int i, len;
	char c;

	len = strlen (data);
	for (i=0;i<len;i++)
		{
		while(Busy1USART());
		c = data[i];
		c = (char)(c & 0x7f);
		TXREG1 = c;
		delay(10);
		}
	waitForDispFIFO();
	}/*wrStr*/

void dumpHex (char c)
	{
	char bf[8];
	sprintf (bf,"%02X",c);
	wrStr (bf);	
	}/*dumpHex*/

void waitForDispFIFO(void)
	{
	char c='\0';
	while (c<64)
		{
		delay (100);
		while(Busy1USART());
		Write1USART (14);
		delay (250);
		c = Read1USART();
		}
	}/*waitForDispFIFO*/

int readKeyPad(void)
	{
	int returncode=0;
	int i=0;
	char c='\0',d='\0',t='\0';

	//read and discard any junk
	c = Read1USART();
	delay (50);
	Write1USART (16);
	delay (50);
	//read 2 bytes
	c = Read1USART();
	delay (20);
	d = Read1USART();
	t=0;

	if (d>16)
		return 0;

	for (i=0;i<8;i++)
		{
		t = (c >> i) & 0x01;
		if (t)
			returncode = i+1;
		}
	for (i=0;i<4;i++)
		{
		t = (d >> i) & 0x01;
		if (t)
			returncode = i+9;
		}
	return returncode;
	}/*readKeyPad*/

void clearLine (int line)
	{
	int i;
	char r;
	//goto row,col 1 based numbering
	r = (char)(line);
	Write1USART (3);
	//row
	delay(145);
	Write1USART (r);
	//col
	delay(145);
	Write1USART (1);

	for (i = 0; i < 20; i++)
		{
		Write1USART (' ');
		delay(25);
		}		
	delay(145);
	Write1USART (3);
	delay(145);
	Write1USART (r);
	delay(145);
	Write1USART (1);
	delay(145);
	}/*clearLine*/

unsigned char getKnob(void)
	{
	unsigned char pb;
	pb = PORTB;
	return (pb & 0xC0);
	}/*getKnob*/

unsigned char getKeyPaddle(void)
	{
	unsigned char pe;
	pe = PORTE;
	return (pe & 0xC0);
	}/*getKeyPaddle()*/

void displayState (void)
	{
	Write1USART (12);	//clear display
	delay (1200);
	//show current freq
	clearLine (1);
	delay(250);
	sprintf (obuf,"Freq: %lu Hz\r",freq);
	wrStr (obuf);
	delay(950);
	if (mode==CWMODE)
		{
		sprintf (obuf,"Mode: CW;");
		wrStr (obuf);
		delay(950);
		if (keyer_mode==MODEA)
			sprintf (obuf," Speed: %d\rKeyer Mode: A\r",code_speed);
		else
			sprintf (obuf," Speed: %d\rKeyer Mode: B\r",code_speed);
		wrStr (obuf);
		delay(950);
		}
	else
		{
		sprintf (obuf,"Mode: SSB\r");
		wrStr (obuf);
		delay(950);
		}
	clearLine (4);	//input is on line 4
	}/*displayState*/
