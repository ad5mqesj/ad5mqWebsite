/*
*	file	: main.c
*	date	: 21 Oct 2008
*	auth	: Ed Johnson
*	contains main entry point for radio firmware
*
*/
#pragma config OSC = HS
#pragma config PWRT = OFF
#pragma config WDT = OFF
#pragma config LVP = OFF

//this define makes the globals in globals.h declarations
//instead of references to externals
#define MAIN_INC	1
#include "stdincludes.h"



void delay (int del)
	{
	int i,j;
	for (i = 0; i < del; i++)
		j = i + del/2;
	}


void main ()
{
int key, oldkey, oldenc, band;
char e;

memset (inpbuf,0,CBUFSZ);
memset (obuf,0,CBUFSZ);
ibufcnt = 0;
oldkey = 0;
encticks = 0;
oldenc = 0;
dit_paddle = 0;
dah_paddle = 0;
both_on = 0;
dit_last = 0;

transmitting = 0;
currentBand = 3;
freq = 3579545;
mode = CWMODE;
ctlDAC = 0x7ff;
code_speed = 15;
keyer_mode = MODEB;
tune_speed = 100;

setup();

//restore settings from NV memory
readSettings();

setFilter (mode);
dit_time = 1200/code_speed;
setFreqHz (freq);
currentBand = setFreqBand (freq);
setRelay (currentBand,0);
delay(250);
setCtlDAC (ctlDAC);

//delay for a few sec. to give display time to init
delay (4000);

//setup display
delay (200);
Write1USART (12);	//clear display
delay (200);
Write1USART (5);	//underline cursor
delay (200);

displayState();

key = readKeyPad();	//dump initial status
oldkey = key;

while (1)
	{
	e = getKeyPaddle();
	dit_paddle = ((e & DIT) != DIT)?1:0;
	dah_paddle = ((e & DAH) != DAH)?1:0;

	if (dit_paddle || dah_paddle)
		{
		if (!transmitting)
			transmit();
		transmitting = 1;
		if (mode==CWMODE)
			keyer ();
		}
	else
		{
		if (transmitting)
			receive();
		transmitting = 0;
		}
	if (transmitting)
		continue;

	key = readKeyPad();
	//if a key was pressed and its not = oldkey process it
	if (key && (key != oldkey))
		keyProcessor (key);
	oldkey = key;

	//handle knob turn, dont update until encoder stops moving
	if (encticks!=0 && oldenc==encticks)
		{
		INTCONbits.RBIE = 0;       	//disable interrupt
		freq -= encticks*tune_speed;
		displayState();
		setFreqHz (freq);
		band = setFreqBand (freq);
		if (band != currentBand)
			setRelay (band,0);
		currentBand = band;
		encticks=0;
		INTCONbits.RBIE = 1;       	//re-enable interrupt
		}
	oldenc = encticks;
	//wait 10 ms
	delay (130);
	}//while forever
}/*main*/
