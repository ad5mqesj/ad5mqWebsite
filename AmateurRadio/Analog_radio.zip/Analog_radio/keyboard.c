/*
*	file	: keyboard.c
*	date	: 19 Nov 2008
*	auth	: Ed Johnson
*	contains handler for keyboard, 
*      state machine for processing keyboard input
*
*/
#include "stdincludes.h"

void SetMode  (void);
void SetSpeed (void);
void SetCWMode(void);
void SetTunSpeed (void);

void keyProcessor (int key)
	{
	int len, band;
	char c;
	static char mode = IDLE;
	unsigned long fr;
	//translate the key
	if (key <= 9) 
		c = (key & 0x0f) + 48;
	else if (key == 11)	
		c = '0';
	else if (key == 10)	{
		c = '*';
		//kill any buffer content in menu mode
		memset (inpbuf,0,CBUFSZ);
		ibufcnt=0;
		mode = MENU;
		}
	else if (key == 12)	{
		c = '#';
		mode = FREQENTRY;
		}
	switch (mode)
		{
		case IDLE:
			//put it in the buffer if its not a control key
			inpbuf[ibufcnt++] = (char)(c&0x7f);
			if (ibufcnt >= 1 && ibufcnt < CBUFSZ)
				Write1USART (inpbuf[ibufcnt-1]);
			if (ibufcnt >= CBUFSZ)
				ibufcnt = 0;
			break;
		case FREQENTRY:	
			len = strlen (inpbuf);
			inpbuf[len] = 0;
			if (len && len < 8)
				{
				if (len < 3)
					fr = atol (inpbuf)*1000000;
				else if ((len ==4) || (len == 5))
					fr = atol (inpbuf)*1000;
				else
					{
					fr = atol (inpbuf);
					if (fr > 0)
						{
						while (fr < 1600000)
							fr *= 10;
						if (len == 5)	//5 digits is 10's of MHz
							fr *= 10;
						}
					}
				}//short entry
			//if freq invalid exit.
			else if (len > 8)
				{
				clearLine (4);
				sprintf (obuf,"Invalid freq");
				wrStr (obuf);
				delay(250);
				Write1USART ((char)11);
				delay (2250);
				ibufcnt = 0;
				c = 0;
				memset (inpbuf,0,CBUFSZ);
				mode = IDLE;
				displayState ();
				return;
				}//too many digits
			else
				fr = atol (inpbuf);
			//if freq invalid exit.
			if (fr < 1600000 || fr > 30000000)
				{
				clearLine (4);
				sprintf (obuf,"Invalid freq");
				wrStr (obuf);
				delay(250);
				Write1USART ((char)11);
				delay (2250);
				ibufcnt = 0;
				c = 0;
				memset (inpbuf,0,CBUFSZ);
				mode = IDLE;
				displayState ();
				return;
				}
			//display and set new freq
			freq = fr;
			Write1USART ((char)11); //put cursor back on freq line
			setFreqHz (freq);
			band = setFreqBand (freq);
			if (band != currentBand)
				setRelay (band,0);
			currentBand = band;
			delay (750);
			displayState ();
			ibufcnt = 0;
			c = 0;
			writeSettings();
			memset (inpbuf,0,CBUFSZ);
			mode = IDLE;
			break;
		case MENU:
			switch (c)	
				{
				case '*':	//print menu
					//clear display
					Write1USART (12);
					delay (1500);
					//show menu
					sprintf (obuf,"1: Operating Mode\r2: CW Speed\r");
					wrStr (obuf);
					delay (1550);
					sprintf (obuf,"3: CW Mode\r4: speed\r");
					wrStr (obuf);
					delay (1550);
					break;
				case SETMODE:
					SetMode();
					ibufcnt = 0;
					memset (inpbuf,0,CBUFSZ);
					displayState();  //restore display before exit
					mode = IDLE;
					break;
				case SETCWSPD:
					SetSpeed();
					dit_time = 1200/code_speed;
					ibufcnt = 0;
					memset (inpbuf,0,CBUFSZ);
					displayState();  //restore display before exit
					mode = IDLE;
					break;
				case SETCWMODE:
					SetCWMode();
					ibufcnt = 0;
					memset (inpbuf,0,CBUFSZ);
					displayState();  //restore display before exit
					mode = IDLE;
					break;
				case SETSPEED:
					SetTunSpeed();
					ibufcnt = 0;
					memset (inpbuf,0,CBUFSZ);
					displayState();  //restore display before exit
					mode = IDLE;
					break;
				default:
					mode = IDLE;
					break;
				}
			//when exiting write settings
			writeSettings();
			break;
		}//mode switch 
	}/*keyProcessor*/

void SetMode  (void)
	{
	int key=0,oldkey=0;
	char oldmode;
	int wfi = 1;
	
	oldmode = 23;
	while (wfi)
		{
		//if mode changed
		if (mode != oldmode)
			{
			//clear display
			Write1USART (12);
			delay (1200);
			if (mode==CWMODE) 
				sprintf (obuf, "Operating Mode: CW\r");
			else
				sprintf (obuf, "Operating Mode: SSB\r");
			wrStr (obuf);
			delay (950);
			sprintf (obuf, "1: CW 2: SSB\r");
			wrStr (obuf);
			delay (950);
			sprintf (obuf, "Press # to exit\r");
			wrStr (obuf);
			delay (950);
			clearLine (4);	//input is on line 4
			}
		oldmode = mode;
		key = readKeyPad();
		if (key && (key != oldkey))
			{
			switch (key)
				{
				case 1:
					mode = CWMODE;
					break;
				case 2:
					mode = SSBMODE;
					break;
				case 12:
					wfi = 0;
					break;
				}
			setFilter (mode);
			}//if a key
		oldkey = key;
		//check for knob motion
		if (encticks&0x08)	//take 4 positions in a rotation instead of 32
			{
			INTCONbits.RBIE = 0;       	//disable interrupt
			mode = (mode==CWMODE)?SSBMODE:CWMODE;
			encticks=0;
			INTCONbits.RBIE = 1;       	//re-enable interrupt
			}
		delay (560);	//wait 300 ms
		}//while waiting for input	
	}//SetMode

void SetSpeed (void)
	{
	int key=0,oldkey=0;
	char oldspeed;
	int wfi = 1;
	
	oldspeed = 0;
	while (wfi)
		{
		//if mode changed
		if (code_speed != oldspeed)
			{
			//clear display
			Write1USART (12);
			delay (1200);
			sprintf (obuf, "Keyer speed: %d\r",code_speed);
			wrStr (obuf);
			delay (950);
			sprintf (obuf, "1: DOWN  2: UP\r");
			wrStr (obuf);
			delay (950);
			sprintf (obuf, "Press # to exit\r");
			wrStr (obuf);
			delay (950);
			clearLine (4);	//input is on line 4
			}
		oldspeed = code_speed;
		key = readKeyPad();
		if (key && (key != oldkey))
			{
			switch (key)
				{
				case 1:
					code_speed -= 5;
					break;
				case 2:
					code_speed += 5;
					break;
				case 12:
					wfi = 0;
					break;
				}
			if (code_speed < 5) code_speed = 5;
			else if (code_speed > 45) code_speed = 45;
			}//if a key
		oldkey = key;
		//check for knob motion
		if (encticks&0x08)	//take 4 positions in a rotation instead of 32
			{
			INTCONbits.RBIE = 0;       	//disable interrupt
			if (encticks > 0)
				code_speed += 5;
			else code_speed -= 5;
			if (code_speed < 5) code_speed = 5;
			else if (code_speed > 45) code_speed = 45;
			encticks=0;
			INTCONbits.RBIE = 1;       	//re-enable interrupt
			}
		delay (560);	//wait 300 ms
		}//while waiting for input	
	}//SetSpeed

void SetCWMode(void)
	{
	int key=0,oldkey=0;
	char oldmode;
	int wfi = 1;
	
	oldmode = 23;
	while (wfi)
		{
		//if mode changed
		if (keyer_mode != oldmode)
			{
			//clear display
			Write1USART (12);
			delay (1200);
			if (keyer_mode==MODEA)
				sprintf (obuf, "Keyer Mode : A\r");
			else
				sprintf (obuf, "Keyer Mode : B\r");
			wrStr (obuf);
			delay (950);
			sprintf (obuf, "1: A  2: B\r");
			wrStr (obuf);
			delay (950);
			sprintf (obuf, "Press # to exit\r");
			wrStr (obuf);
			delay (950);
			clearLine (4);	//input is on line 4
			}
		oldmode = keyer_mode;
		key = readKeyPad();
		if (key && (key != oldkey))
			{
			switch (key)
				{
				case 1:
					keyer_mode = MODEA;
					break;
				case 2:
					keyer_mode = MODEB;
					break;
				case 12:
					wfi = 0;
					break;
				}
			}//if a key
		oldkey = key;
		//check for knob motion
		if (encticks&0x08)	//take 4 positions in a rotation instead of 32
			{
			INTCONbits.RBIE = 0;       	//disable interrupt
			keyer_mode = (keyer_mode==MODEA)?MODEB:MODEA;
			encticks=0;
			INTCONbits.RBIE = 1;       	//re-enable interrupt
			}
		delay (560);	//wait 300 ms
		}//while waiting for input	
	}//SetCWMode

void SetTunSpeed (void)
	{
	int key=0,oldkey=0;
	int oldspeed;
	int wfi = 1;
	
	oldspeed = 0;
	while (wfi)
		{
		//if mode changed
		if (tune_speed != oldspeed)
			{
			//clear display
			Write1USART (12);
			delay (1200);
			sprintf (obuf, "Tuning speed:%d\r",tune_speed);
			wrStr (obuf);
			delay (950);
			sprintf (obuf, "1: DOWN  2: UP\r");
			wrStr (obuf);
			delay (950);
			sprintf (obuf, "Press # to exit\r");
			wrStr (obuf);
			delay (950);
			clearLine (4);	//input is on line 4
			}
		oldspeed = tune_speed;
		key = readKeyPad();
		if (key && (key != oldkey))
			{
			switch (key)
				{
				case 1:
					tune_speed /= 10;
					break;
				case 2:
					tune_speed *= 10;
					break;
				case 12:
					wfi = 0;
					break;
				}
			if (tune_speed < 1) code_speed = 1;
			else if (tune_speed > 10000) tune_speed = 10000;
			}//if a key
		oldkey = key;
		//check for knob motion
		if (encticks&0x08)	//take 4 positions in a rotation instead of 32
			{
			INTCONbits.RBIE = 0;       	//disable interrupt
			if (encticks > 0)
				tune_speed *= 10;
			else code_speed /= 10;
			if (tune_speed < 1) code_speed = 1;
			else if (tune_speed > 10000) tune_speed = 10000;
			encticks=0;
			INTCONbits.RBIE = 1;       	//re-enable interrupt
			}
		delay (560);	//wait 300 ms
		}//while waiting for input	
	}//SetTunSpeed


