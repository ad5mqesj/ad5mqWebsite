/*
 * keyer.c
 * 16 Nov 2008
 * Ed Johnson
 * contains Iambic keyer algorithm
 */

#include "stdincludes.h"

void keyer ()
{
	if ((dit_paddle && dah_paddle) && keyer_mode == MODEB)
		{
		both_on = 1;
		if (dit_last)
			{
			sendDAH();
			dit_last = 0;
			}
		else
			{
			sendDIT();
			dit_last = 1;
			}
		}//both and B mode
	else if (both_on)
		{
		both_on = 0;
		if (dit_last)
			{
			sendDAH();
			dit_last = 0;
			}
		else
			{
			sendDIT();
			dit_last = 1;
			}
		}
	else
		{
		if (!(dit_paddle || dah_paddle))
			{
			if (dit_last)
				{
				sendDAH();
				dit_last = 0;
				}
			else
				{
				sendDIT();
				dit_last = 1;
				}
			}
		if (dit_paddle)
			{
			sendDIT();
			dit_last = 1;
			}
		if (dah_paddle)
			{
			sendDAH();
			dit_last = 0;
			}
		}
}/*keyer*/
