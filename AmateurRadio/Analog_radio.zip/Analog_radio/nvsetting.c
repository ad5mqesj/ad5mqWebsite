/*
 * nvsetting.c
 * Ed Johnson
 * 16 Nov 2008
 * functions to read and write all non-volatile settings
 */
#include "stdincludes.h"

void readSettings()
{
unsigned char c[4];
int i, offs = 0;

//mode
mode = Read_b_eep (offs);
offs++;
if (mode > 1 || mode < 0)
	mode = 1;

//code_speed
code_speed = Read_b_eep (offs);
offs++;
if (code_speed > 45 || code_speed < 0)
	mode = 15;
//keyer mode
keyer_mode = Read_b_eep (offs);
offs++;
if (keyer_mode > 1 || keyer_mode < 0)
	keyer_mode = 1;

//freq
for (i = 0; i < 4; i++, offs++)
	c[i] = Read_b_eep (offs);
freq = ((unsigned long)c[0] << 24) | ((unsigned long)c[1] << 16);
freq |= ((unsigned long)c[2] << 8) | ((unsigned long)c[3]);

if (freq > 30000000)
	freq = 7000000;

//control DAC
c[0] = Read_b_eep (offs);
offs++;
c[1] = Read_b_eep (offs);
offs++;
ctlDAC = ((unsigned int)c[0] << 8) | ((unsigned int)c[1]);

}/*readSettings*/

void writeSettings()
{
unsigned char c[4];
int i, offs = 0;

//mode
Write_b_eep(offs, mode);
Busy_eep ();
offs++;

//code_speed
Write_b_eep(offs, code_speed);
Busy_eep ();
offs++;

//keyer mode
Write_b_eep(offs, keyer_mode);
Busy_eep ();
offs++;

c[0] = (unsigned char)((freq >> 24)&0x000000ff);
c[1] = (unsigned char)((freq >> 16)&0x000000ff);
c[2] = (unsigned char)((freq >> 8)&0x000000ff);
c[3] = (unsigned char)((freq)&0x000000ff);
for (i = 0; i < 4; i++)
	{
	Write_b_eep(offs, c[i]);
	Busy_eep ();
	offs++;
	}	

//control DAC
c[0] = (unsigned char)((ctlDAC >> 8)&0x00ff);
c[1]= (unsigned char)((ctlDAC)&0x00ff);
for (i = 0; i < 2; i++)
	{
	Write_b_eep(offs, c[i]);
	Busy_eep ();
	offs++;
	}	
}/*writeSettings()*/