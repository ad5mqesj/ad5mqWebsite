/*
globals.h
Ed Johnson
14 Nov 2008
contains all global variables in ram
*/
#ifdef MAIN_INC
#define _STRG_QUAL
#else
#define _STRG_QUAL extern
#endif

#define CBUFSZ	64
_STRG_QUAL ram int encticks;

_STRG_QUAL char inpbuf[CBUFSZ];
_STRG_QUAL int ibufcnt;
_STRG_QUAL char obuf [CBUFSZ];

_STRG_QUAL int currentBand;
_STRG_QUAL char transmitting;
_STRG_QUAL unsigned long freq;
_STRG_QUAL char mode;
_STRG_QUAL int ctlDAC;
_STRG_QUAL char code_speed;
_STRG_QUAL int dit_time;
_STRG_QUAL char keyer_mode;
_STRG_QUAL int tune_speed;


_STRG_QUAL char dit_last;
_STRG_QUAL char both_on;
_STRG_QUAL char dit_paddle;
_STRG_QUAL char dah_paddle;
