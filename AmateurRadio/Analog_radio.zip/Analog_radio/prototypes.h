/* prototypes.h
*  Author Ed Johnson
*  Date 24 Oct 2008
*  contains prototypes for all functions called across modules
*/

void delay (int);
void sendByte (char a);
void setup(void);
void wrStr (char *);
void dumpHex (char c);
int readKeyPad (void);
void clearLine (int);
unsigned char getKeyPaddle(void);
void transmit(void);
void receive (void);
void cycleRelays(void);
void strobeRelays(void);
void setRelay(int ry, int tx);
void pulseLatch(void);
void initDDS(void);
void SetupDDS(void);
void setFreq (unsigned long f1, unsigned long f2);
void setFreqHz (unsigned long freq);
void setCtlDAC (int);
void waitForDispFIFO(void);
int setFreqBand (unsigned long freq);
unsigned char getKnob(void);
void keyXmitr(char on);
void readSettings(void);
void writeSettings(void);
void keyer (void);
void sendDIT(void);
void sendDAH(void);
void keyProcessor (int key);
void displayState (void);
void setFilter (char u);


