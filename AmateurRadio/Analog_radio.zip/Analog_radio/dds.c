/*
*	file	: dds.c
*	date	: 25 Oct 2008
*	auth	: Ed Johnson
*	contains routines to program DDS
*
*/
#include "stdincludes.h"

#define DELAYIW	4
#define USESPI	1

void sendByte (char a)
{
int i;
char b,c;

if (USESPI)
	{
	SSP1BUF = a;		
	Delay10TCYx (DELAYIW);
	}
else
	{
	b = a;
	for (i = 7; i >= 0; i--)
		{
		/*set bit state*/
		if ((b >> i) & 0x01)
			{
			c = LATC;
			c |= 0x20;
			LATC = c;
			}
		else
			{
			c = LATC;
			c &= ~0x20;
			LATC = c;
			}
		/*pulse clock*/
		Delay10TCYx (1);
		c = LATC;
		c |= 0x08;
		LATC = c;
		Delay10TCYx (1);
		c = LATC;
		c &= ~0x08;
		LATC = c;
		}/*for each bit*/
	Delay10TCYx (1);
	c = LATC;
	c &= ~0x20;
	LATC = c;
	}/*if not using SPI*/	
}/*sendByte*/

void pulseLatch()
	{
	char c;

	c = LATC;
	c |= DDS_LAT;
	LATC = c;
	Delay10TCYx (1);
	c = LATC;
	c &= ~DDS_LAT;
	LATC = c;
	Delay10TCYx (1);
	}/*pulseLatch*/

void initDDS()
	{
	char b,c;
	//set MR in case its a reset
	b = LATB;
	b |= DDS_MR;
	LATB = b;
	delay(500);
	//drop MR
	b = LATB;
	b &= ~DDS_MR;
	LATB = b;
	delay(100);

	//pulse DDS IOR to insure no cycle are in progress
	Delay10TCYx (3);
	b = LATB;
	b |= DDS_IOR;
	LATB = b;
	Delay10TCYx (3);
	b = LATB;
	b &= ~DDS_IOR;
	LATB = b;

	//now enable DDS_LATCH bit and set it hi
	TRISC = 0x93;					//enable SPI, USART, enable DDS_LAT intially
	c = LATC;
	c |= DDS_LAT;
	LATC = c;

	//set chip select active
	b = LATB;
	b &= ~DDS_CS;
	LATB = b;

	//send address of control register
	sendByte (0x07);
	sendByte (0x14);	//comparator off, main and ctl DAC off 
	sendByte (0x64);	//clock multiplier off
	sendByte (0x00);	//single tone
	sendByte (0x40);	//sinc off

	pulseLatch();
	//finally drop the chip select
	b = LATB;
	b |= DDS_CS;
	LATB = b;
	}/*initDDS()*/

void SetupDDS()
	{
	char b;

	//set chip select active
	b = LATB;
	b &= ~DDS_CS;
	LATB = b;

	//send address of control register
	sendByte (0x07);
	sendByte (0x00);	//comparator on, Ctl DAC on 
	sendByte (0x64);	//clock multiplier disabled
	sendByte (0x00);	//single tone
	sendByte (0x40);	//sinc off, MSB first, UD output

	pulseLatch();

	sendByte (0x08);
	sendByte (0x0f);	//multiplier on output slightly less than full scale
	sendByte (0xd0);
	pulseLatch();

	sendByte (0x0A);
	sendByte (0xff);	//ramp rate max
	pulseLatch();

	Delay10TCYx (1);
	//finally drop the chip select
	b = LATB;
	b |= DDS_CS;
	LATB = b;
	}/*SetupDDS*/

void setFreq (unsigned long f1, unsigned long f2)
	{
	int i;
	char b, c;

	//set chip select active
	b = LATB;
	b &= ~DDS_CS;
	LATB = b;


	//send address of Freq 1 register
	sendByte (0x02);
	//send Least sig 48 bits
	for (i = 8; i >= 0; i-=8)
		{
		b = (char)(f1 >> i)&0xff;
		sendByte (b);		
		}
	for (i = 24; i >= 0; i-=8)
		{
		b = (char)(f2 >> i)&0xff;
		sendByte (b);		
		}

	pulseLatch();

	//finally drop the chip select
	b = LATB;
	b |= DDS_CS;
	LATB = b;
	}/*setFreq*/
void setFreqHz (unsigned long freq)
{
	unsigned long hi, lo;
	float f,g,d,q;

	f = 45000000.0 - (float)freq;
	d = f;
	q = floor(f * .65535);
	hi = (unsigned long)(q/1000.0);
	q = q/1000.0;
//	g = (float)hi * 1525.878906;
	g = (float)hi * 1525.88;
	//compensate for fraction this can cause freq error of 1700 Hz
	g -= (q-hi)*1525.88f;
	d = (d - g);
	d = d * 2814749.767;
	//check for overflow
	if (d > 2.0e9)
		{
		d=f;
		hi = hi+1;
		q += 1.0;
		g = (float)hi * 1525.88f;//8906;
		g -= (q-hi)*1525.88f;
		d = (d - g);
		d = d * 2814749.0f;
		}

	lo = (unsigned long)(d+0.5);
/*
	sprintf (obuf,"%08lX:%08lX\r",hi,lo);
	wrStr (obuf);
	sprintf (obuf,"%08lX:%08lX\r",f,q);
	wrStr (obuf);
*/
	setFreq (hi,lo);
}/*setFreqHz*/

void setCtlDAC (int dc)
{
	char b;
	//set chip select active
	b = LATB;
	b &= ~DDS_CS;
	LATB = b;

	//send address of Freq 1 register
	sendByte (0x0B);
	b = (char)(dc >> 8)&0xff;
	sendByte (b);		
	b = (char)(dc&0xff);
	sendByte (b);		

	pulseLatch();

	//finally drop the chip select
	b = LATB;
	b |= DDS_CS;
	LATB = b;
}/*setCtlDAC*/
