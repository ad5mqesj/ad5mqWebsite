/*
*	file: regDefines.h
*	date: 25 Oct 2008
*	auth: Ed Johnson
*	contains register bit defines for control functions
*/

#define	DDS_MR	0x08
#define DDS_IOR 0x10
#define DDS_CS	0x04
#define DDS_LAT	0x04

#define TX		 0x01
#define	RLY_STRB 0x02

#define CW_KEY	0x20
#define VCO_SW	0x10

#define ENC_A	0x40
#define ENC_B	0x80

#define DAH	0x40
#define DIT 0x80

