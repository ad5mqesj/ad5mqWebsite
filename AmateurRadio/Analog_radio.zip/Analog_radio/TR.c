/*
TR.c
14 Nov 2008
Ed Johnson
contains functions to switch between receive and transmit modes, key CW mode
*/
#include "stdincludes.h"

float ms_time = 13.25;

void transmit()
{
unsigned char e,b;
extern int currentBand;

//switch TR relay
setRelay(currentBand, 1);
//delay (50);

//switch vco line
e = LATE;
e &= ~VCO_SW;
LATE = e;

//set tx line
b = LATB;
b |= TX;
LATB = b;
}/*transmit*/

void keyXmitr(char on)
{
unsigned char e;

e = LATE;
if (on)
	{
	transmit();
	e |= CW_KEY;
	LATBbits.LATB5 = 1;
	}
else
	{	
	receive ();
	e &= ~CW_KEY;
	LATBbits.LATB5 = 0;
	}
LATE = e;
}/*keyXmitr*/

void sendDIT()
{
	unsigned int del;
	del = (unsigned int)((float)dit_time*ms_time);
	keyXmitr(1);
	delay (del);
	keyXmitr(0);
	delay (del);
}/*sendDIT()*/

void sendDAH()
{
	unsigned int del;
	del = (unsigned int)((float)dit_time*ms_time*3.0);

	keyXmitr(1);
	delay (del);
	keyXmitr(0);
	del = (unsigned int)((float)dit_time*ms_time);
	delay (del);
}/*sendDAH*/

void receive ()
{
unsigned char e,b;
extern int currentBand;

//set tx line
b = LATB;
b &= ~TX;
LATB = b;

//switch vco line and key line
e = LATE;
e &= ~CW_KEY;
e |= VCO_SW;
LATE = e;

//switch TR relay
setRelay(currentBand, 0);
delay (50);
}/*receive*/

