/*
interrupts.c
14 Nov 2008
Ed Johnson
interrupt handlers for port B change
*/
#include "stdincludes.h"


//----------------------------------------------------------------------------
// High priority interrupt routine

#pragma code
#pragma interrupt InterruptHandlerHigh

void
InterruptHandlerHigh ()
	{
	int i,j;
	unsigned char b, d, e;
	 if (INTCONbits.RBIF) //check portb change
		{      
		b = PORTB&0xC0;
		if (!(b&ENC_B))
			e = 1;
		else
			e = 0;

		INTCONbits.RBIE = 0;  
		//only falling edge
		if (!(b&ENC_A))
			{
			//wait about 1ms - this is the delay code inline here
			for (i = 0; i < 13; i++)
				j = i + 13/2;

			b = PORTB&0xC0;
//			LATBbits.LATB5 = ~LATBbits.LATB5; //diagnostic toggles B5 on inter
			if (!(b&ENC_B))
				d = 1;
			else
				d = 0;
			if (d!= e)	//dont move if dir changed.
				{
			   	INTCONbits.RBIF = 0;        //clear interrupt flag
				INTCONbits.RBIE = 1;       	//re-enable interrupt
				return;
				}
			if (d) encticks++;
			else   encticks--;
			}

	   	INTCONbits.RBIF = 0;        //clear interrupt flag
		INTCONbits.RBIE = 1;       	//re-enable interrupt
	   	}
	}/*InterruptHandlerHigh*/

// High priority interrupt vector
#pragma code InterruptVectorHigh = 0x08
void
InterruptVectorHigh (void)
{
  _asm
    goto InterruptHandlerHigh //jump to interrupt routine
  _endasm
}
