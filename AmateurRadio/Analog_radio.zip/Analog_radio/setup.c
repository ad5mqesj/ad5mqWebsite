/*
*	file	: setup.c
*	date	: 21 Oct 2008
*	auth	: Ed Johnson
*	contains routines to setup processor, initialize everything
*
*/
#include "stdincludes.h"

void setup()
{
unsigned char c;
TRISB = 0xC0;					//set 7-6 input, 0-5 output.
LATB = 0x0c;					//all hold dds in reset initially 
TRISC = 0x97;					//enable SPI, USART, disable DDS_LAT intially
TRISE = 0xC0;					//bits 6,7 in, 5,4 out 0-3 out
LATE = 0;						//set outputs to 0, no CW key, vco switch pos 1

			
INTCON2bits.NOT_RBPU = 0;		//turn on weak pullups for PORT B
c = LATB;						//read B
INTCON = 0;						
INTCON2 = 0;
INTCON3 = 0;
//clear any mis-match
c = PORTB;
INTCONbits.RBIF = 0;			//clear B change flag
INTCONbits.RBIE = 1;			//enable port B change intrrupt
INTCONbits.GIE = 1;				//enable interrupts globally


// Setup the USART for 9600 baud @ 16MHz
  Open1USART (USART_TX_INT_OFF &
             USART_RX_INT_OFF &
             USART_ASYNCH_MODE &
             USART_EIGHT_BIT &
             USART_CONT_RX &
             USART_BRGH_LOW, 25);

//set up SPI for controlling DDS and relays
SSP1CON1 = 0x21;	//SPI mode, 1 MHz clock
SSP1STAT = 0x40;	//inv clock	for relays

//setup PWM channel2 as clock for audio filter
//setup initially for 2.9KHz filter
ECCP2AS = 0;
ECCP2DEL=0x80;
CCP2CON = 0x8c;
T2CONbits.TMR2ON = 0;  // STOP TIMER2 registers to POR state
PR2 = 0x0D;
CCPR2L = 0x07;
T2CONbits.TMR2ON = 1;  // Restart TIMER2 


delay(250);
setRelay (0,0);
delay(250);
initDDS();
delay(250);
cycleRelays();
delay(250);
SetupDDS();
delay(250);
receive ();

}