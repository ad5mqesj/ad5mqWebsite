package ad5mq;
import gnu.io.CommPort;
import gnu.io.CommPortIdentifier;
import gnu.io.SerialPort;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.PrintStream;

import org.apache.log4j.Logger;


public class Radio {
	private SerialPort serialPort=null;
//	private InputStream in=null;
	private BufferedInputStream in=null;
	private PrintStream out=null;
	private boolean isOpen;
	private boolean inControl;
	private boolean StatusOk;
	static Logger logger = Logger.getLogger(Radio.class.getName());
	public static final int VFOA = 0;
	public static final int VFOB = 1;
	
	public Radio_Status cstat = new Radio_Status();
	
	Radio()
		{
		isOpen = false;
		inControl = false;
		StatusOk = false;
		}
	Boolean isOpen() {return isOpen;}
	void connect ( String portName )
		{
		try {
	        CommPortIdentifier portIdentifier = CommPortIdentifier.getPortIdentifier(portName);
	        if (portIdentifier.isCurrentlyOwned())
	        	{
	            System.out.println("Error: Port is currently in use");
	            isOpen = false;
				logger.info("Failed to open port " + portName + ". Port in use by another application.");
	       	}
	        else
	        	{
	            CommPort commPort = portIdentifier.open("TrackController",2000);
	            
	            if (commPort instanceof SerialPort)
	            	{
	                serialPort = (SerialPort) commPort;
	                //port to 9600,N,8,1 for rotor controller
	                serialPort.setSerialPortParams(4800,SerialPort.DATABITS_8,SerialPort.STOPBITS_2,SerialPort.PARITY_NONE);
	                
	                in = new BufferedInputStream(serialPort.getInputStream());
	                out = new PrintStream(serialPort.getOutputStream(), true, "ISO-8859-1");
	                isOpen = true;
	            	}
	            else
	            	{
	                System.out.println("Error: Only serial ports are handled by this example.");
	                isOpen = false;
	    			logger.info("Failed to open port " + portName + ". Its not a serial port.");
	            	}
	        	}//else port is available     
			}//try
		catch (Exception e)
			{
			logger.info("Failed to open port " + portName + ". Exception : "+e.getMessage());
			}
		}//connect

	void close ()
		{
		if (!isOpen)
			return;
		try {
			if (in!=null)  in.close();
			if (out!=null) out.close();
			if (serialPort!=null) serialPort.close();
			}//try
		catch (IOException i)
			{
			logger.debug("IO Exception - failed to close in or out stream. " + i.getStackTrace());
			}
		}//close

	boolean getStatus()
		{
		if (!isOpen)
			return false;
		byte cmd[] = {(byte)0x01,(byte)0x01,(byte)0x01,(byte)0x01,(byte)0x01};
		//status retrieved automagically every time a command is sent
		return (sendCommand (cmd));
		}//getStatus

	boolean TakeControl ()
		{
		if (!isOpen)
			return false;
		byte cmd[] = {(byte)0x01,(byte)0x01,(byte)0x01,(byte)0x00,(byte)0x00};
		//status retrieved automagically every time a command is sent
		boolean sc = sendCommand (cmd);
		if (!sc)
			return false;
		inControl = cstat.UnderControl();
		return (inControl);
		}//TakeControl
	
	boolean ReleaseControl ()
		{
		if (!isOpen)
			return false;
		byte cmd[] = {(byte)0x01,(byte)0x01,(byte)0x01,(byte)0x01,(byte)0x00};
		//status retrieved automagically every time a command is sent
		boolean sc = sendCommand (cmd);
		if (!sc)
			return false;
		inControl = cstat.UnderControl();
		return (!inControl);
		}//ReleaseControl
	
	boolean setVFO_A (float freq)
		{
		if (!isOpen)
			return false;
		if (!StatusOk || !inControl)
			return false;
		try{
			while (cstat.isTransmitting())
				Thread.sleep(250);
			}
		catch (Exception e){return false;}
		//set VFO A
		byte cmd[] = {(byte)0x01,(byte)0x01,(byte)0x01,(byte)0x00,(byte)0x09};
		//status retrieved automagically every time a command is sent
		boolean sc = sendCommand (cmd);
		if (!sc)
			return false;
		//now build up freq
		//make an int
		int intf = (int)(freq * 1000000.0f+0.5f);
		//get each digit
		int digits[] = new int [8];	//there are always 8 digits some of the leading ones may be 0
		int residue = 0;
		for (int i = 8; i > 0; i--)
			{
			digits[i-1] = (int) ((intf-residue) / Math.pow (10,i));
			residue += digits[i-1] * (int)Math.pow (10,i);
			}
		for (int i=0; i<4; i++)
			{
			cmd[i] = (byte)((((digits[i*2+1]&0x0f) << 4)&0xf0) | ((digits[i*2]&0x0f)));
			}
		cmd[4] = (byte)0x08;
		sc = sendCommand (cmd);
		return sc;
		}//setVFO_A
	
	boolean setVFO_B (float freq)
		{
		if (!isOpen)
			return false;
		if (!StatusOk || !inControl)
			return false;
		try{
			while (cstat.isTransmitting())
				Thread.sleep(250);
			}
		catch (Exception e){return false;}
		//set VFO B
		byte cmd[] = {(byte)0x01,(byte)0x01,(byte)0x01,(byte)0x01,(byte)0x09};
		//status retrieved automagically every time a command is sent
		boolean sc = sendCommand (cmd);
		if (!sc)
			return false;
		//now build up freq
		//make an int
		int intf = (int)(freq * 1000000.0f+0.5f);
		//get each digit
		int digits[] = new int [8];	//there are always 8 digits some of the leading ones may be 0
		int residue = 0;
		for (int i = 8; i > 0; i--)
			{
			digits[i-1] = (int) ((intf-residue) / Math.pow (10,i));
			residue += digits[i-1] * (int)Math.pow (10,i);
			}
		for (int i=0; i<4; i++)
			{
			cmd[i] = (byte)((((digits[i*2+1]&0x0f) << 4)&0xf0) | ((digits[i*2]&0x0f)));
			}
		cmd[4] = (byte)0x08;
		sc = sendCommand (cmd);
		return sc;
		}//setVFO_B
	
	boolean setVFOrcv (int vi)	//0 = A, 1 = B
		{
		if (!isOpen)
			return false;
		if (!StatusOk || !inControl)
			return false;
		byte cmd[] = {(byte)0x01,(byte)0x01,(byte)0x01,(byte)0x01,(byte)0x09};
		cmd[4] = (byte)vi;
		//status retrieved automagically every time a command is sent
		boolean sc = sendCommand (cmd);
		return sc;
		}

	private boolean sendCommand (byte [] b)
		{
		byte[] buffer = new byte[100];
        int len = -1;
        boolean bad = false;
        
		if (!isOpen)
			return false;
		try {
			//send 5 command bytes
			for (int i = 0; i < 5; i++){
				out.write(b[i]);		
				Thread.sleep(5);
				}
			//get the echo back
			int i = 0, j=0;
			len = 0;
			while ((j = this.in.read(buffer, len, 5-len)) < 0 || len < 5 && i++ < 50){ if (j>0)len+=j; Thread.sleep(10);}
			if (i >= 50)
				{
				logger.info("Sending command to radio failed: no data returned!");
				return false;
				}
			if (len != 5)	//something went wrong!
				{
				logger.info("Sending command to radio failed: "+Integer.toString(len)+" bytes echoed back!");
				return false;
				}
			logger.debug(String.format("wrote command : %02X %02X %02X %02X %02X",b[0],b[1],b[2],b[3],b[4]));
			logger.debug(String.format("got echo : %02X %02X %02X %02X %02X",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4]));
			for (i = 0; i < 5; i++)
				{
				if (buffer[i] != b[i])
					bad = true;
				}//check echo loop
			if (bad)
				{
				logger.info("Sending command to radio failed: echo mismatch!");
				return false;
				}//if echo fails then get out
			//send ack block
			for (i = 0; i < 4; i++){
				out.write((byte)0x0b);
				Thread.sleep(1);
				}
			out.write((byte)0x0b);
			//wait long enough for 86 bytes of status to be returned
			Thread.sleep(100);
			//status bad till proved otherwise
			StatusOk = false;
			int exp=5;
			j = 0;
			i = 0;
			len = 0;
			if (b[4] == 0 || b[4] == 1)
				exp = 86;
			len = this.in.read(buffer);
			if (len == -1)
				{
				logger.info("Sending command to radio failed: bad status after ack!");
				return false;
				}
			//now get status resulting from command
			while ((j = this.in.read(buffer, len, exp-len)) < 0 || len < exp && i++ < 50){ if (j>0)len+=j; Thread.sleep(0);}
			if (len < 5)
				{	
				logger.info("Sending command to radio failed: bad status after ack!");
				return false;
				}
			cstat.DecodeStatBlock (buffer, exp);
			StatusOk = true;
			logger.debug("Status:"+cstat.toString());
			}//try
		catch (IOException i)
			{
			logger.debug("IO Exception - failed to send command. " + i.getStackTrace());
			return false;
			}
		catch (InterruptedException e)
			{
			logger.debug("Interrupted Exception - failed to send command. " + e.getStackTrace());
			return false;
			}
		return true;
		}//sendCommand
}//Radio
