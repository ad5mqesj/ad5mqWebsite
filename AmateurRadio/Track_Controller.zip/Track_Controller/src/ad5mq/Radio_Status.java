package ad5mq;

public class Radio_Status {
	//status bits
	static final public int PTT 		= 1 << 0;	//if set unit is transmitting
	static final public int Gen 		= 1 << 1;	//if set we are in general coverage on receive
	static final public int Tx_Inh 		= 1 << 2;	//if set transmitter is inhibited (usually with above)
	static final public int Split		= 1 << 3;	//if set operating split
	static final public int nA_B		= 1 << 4;	//if set using B VFO
	static final public int MCA			= 1 << 5;	//if set memory channel active
	static final public int Clarifier 	= 1 << 6;	//if set clarifier active
	static final public int CAT			= 1 << 7;	//if set radio is under computer control
	//modes
	static final public int LSB = 0;
	static final public int USB = 1;
	static final public int CW = 2;
	static final public int AM = 3;
	static final public int FM = 4;
	static final public int FSK = 5;
	
	static final float CTCSSFREQS[] = 
								{91.5f,88.5f,85.4f,82.5f,79.7f,77.0f,74.7f,71.9f,67.0f,250.3f,
								241.8f,233.6f,225.7f,218.1f,210.7f,203.5f,192.8f,186.2f,179.9f,
								173.8f,167.9f,162.2f,156.7f,151.4f,146.2f,141.3f,136.5f,131.8f,
								127.3f,123.0f,118.8f,114.8f,110.9f,107.2f,103.5f,100.0f,94.8f,
								88.5f,82.5f,77.0f,71.9f,67.0f};
	public int Flags;
	public float operating_freq;
	public float CTCSS_Freq;
	public int mode;
	public int Mem_chan;
	public float clar_freq;
	public float clar_CTCSS_freq;
	public int Clar_mode;
	public float VFO_A_Freq;
	public float VFO_A_CTCSS;
	public int VFO_A_Mode;
	public float VFO_B_Freq;
	public float VFO_B_CTCSS;
	public int VFO_B_Mode;
	//we dont bother messing wiht mem channel freq, mode, ctcss
	
	Radio_Status()
		{
		Flags = 0;
		operating_freq = 0.0f;
		CTCSS_Freq = 0.0f;
		mode = 0;
		Mem_chan = 0;
		clar_freq = 0.0f;
		clar_CTCSS_freq = 0.0f;
		Clar_mode = 0;
		VFO_A_Freq = 0.0f;
		VFO_A_CTCSS = 0.0f;
		VFO_A_Mode = 0;
		VFO_B_Freq = 0.0f;
		VFO_B_CTCSS = 0.0f;
		VFO_B_Mode = 0;
		}
	
	void DecodeStatBlock (byte [] ib,int e)
		{
		byte b[] = new byte [100];
		int cix, bix = 0;
		//reverse input data
		for (int i = e-1; i >= 0; i--)
			b[e-i-1] = ib[i];
		Flags = b[bix++];
		operating_freq = DecodeFreq(b,bix);
		bix += 4;
		if (e== 5)
			return;
		cix = b[bix++];
		//abort if bad index
		if (cix != 0)
			{
			cix -= 0x15;
			if (cix < 0 || cix > CTCSSFREQS.length)
				return;
			CTCSS_Freq = CTCSSFREQS[cix];
			}
		else
			CTCSS_Freq = 0.0f;
		mode =  b[bix++]&0x07;
		Mem_chan = b[bix++]&0x0f;
		if (e== 8)
			return;
		clar_freq = DecodeFreq(b,bix);
		bix += 4;
		cix = b[bix++];
		//abort if bad index
		if (cix != 0)
			{
			cix -= 0x15;
			if (cix < 0 || cix > CTCSSFREQS.length)
				return;
			clar_CTCSS_freq = CTCSSFREQS[cix];
			}
		else
			clar_CTCSS_freq = 0.0f;
		Clar_mode = b[bix++];
		VFO_A_Freq = DecodeFreq(b,bix);
		bix += 4;
		cix = b[bix++];
		if (cix != 0)
			{
			cix -= 0x15;
			if (cix < 0 || cix > CTCSSFREQS.length)
				return;
			VFO_A_CTCSS = CTCSSFREQS[cix];
			}
		else
			VFO_A_CTCSS = 0.0f;
		VFO_A_Mode =  b[bix++]&0x07;
		VFO_B_Freq = DecodeFreq(b,bix);
		bix += 4;
		cix = b[bix++];
		if (cix != 0)
			{
			cix -= 0x15;
			if (cix < 0 || cix > CTCSSFREQS.length)
				return;
			VFO_B_CTCSS = CTCSSFREQS[cix];
			}
		else
			VFO_B_CTCSS = 0.0f;
		VFO_B_Mode =  b[bix++]&0x07;
		//repeat below 9 more times if you want the memory chan 0-9 freq's
		//if (e == 26)
		//	return;
		//MEM_0_Freq = DecodeFreq(b,bix);
		//bix += 4;
		//cix = b[bix++];
		//if (cix != 0)
		//	{
		//	cix -= 0x15;
		//	if (cix < 0 || cix > CTCSSFREQS.length)
		//		return;
		//	MEM_0_CTCSS = CTCSSFREQS[cix];
		//	}
		//else
		//	MEM_0_CTCSS = 0.0f;
		//MEM_0_Mode =  b[bix++]&0x07;
		}//DecodeStatBlock
	
	Boolean isTransmitting() { Boolean retv = ((Flags&(PTT|Tx_Inh))==PTT)?true:false; return retv;} 
	Boolean CanTransmit(){ Boolean retv = ((Flags&(Tx_Inh))==Tx_Inh)?false:true; return retv;} 
	Boolean UnderControl() { Boolean retv = ((Flags&(CAT))==CAT)?true:false; return retv;}
	Boolean isSplit() { Boolean retv = ((Flags&(Split))==Split)?true:false; return retv;}
	Boolean isVFO_B() { Boolean retv = ((Flags&(nA_B))==nA_B)?true:false; return retv;}

	float DecodeFreq (byte [] b, int offs)
		{
		int i,t,j,o;
		String s = new String ();
		for (i = offs,j=0; i < 4+offs; i++,j++)
			{
			t = b[i];
			o = (t >> 4)&0x0f;
			s += Integer.toString(o);
			o = (t)&0x0f;
			s += Integer.toString(o);
			}//for the 4 bytes in input to decode
		float out = Float.parseFloat(s);
		out = out / 100000.0f;
		return out;
		}//DecodeFreq
	
	public String toString()
		{
		String s = new String();
		s = isTransmitting()?"Transmitting":"Receiving";
		s += "\r\n";
		s += CanTransmit()?"Can Transmit":"Tx Inhibited";
		s += "\r\n";
		s += isVFO_B()?"VFO B":"VFO A";
		s += "\r\n";
		switch (mode)
			{
			case LSB:
				s+= "LSB\r\n";
				break;
			case USB:
				s+= "USB\r\n";
				break;
			case FM:
				s+= "FM\r\n";
				break;
			case CW:
				s+= "CW\r\n";
				break;
			case AM:
				s+= "AM\r\n";
				break;
			}
		s+= "Operating Frq:"+Float.toString(operating_freq)+"\r\n";
		s += isSplit()?"Split":"";
		s += "\r\n";
		s += UnderControl()?"Computer control":"Manual control";
		s += "\r\n";
		s+= "VFO A:"+Float.toString(VFO_A_Freq)+"\r\n";
		switch (VFO_A_Mode)
			{
			case LSB:
				s+= "LSB\r\n";
				break;
			case USB:
				s+= "USB\r\n";
				break;
			case FM:
				s+= "FM\r\n";
				break;
			case CW:
				s+= "CW\r\n";
				break;
			case AM:
				s+= "AM\r\n";
				break;
			}
		s+= "VFO B:"+Float.toString(VFO_B_Freq)+"\r\n";
		switch (VFO_B_Mode)
			{
			case LSB:
				s+= "LSB\r\n";
				break;
			case USB:
				s+= "USB\r\n";
				break;
			case FM:
				s+= "FM\r\n";
				break;
			case CW:
				s+= "CW\r\n";
				break;
			case AM:
				s+= "AM\r\n";
				break;
			}
		return s;
		}
}//Radio_Status
