package ad5mq;

import javax.swing.JPanel;
import java.awt.Frame;
import javax.swing.JDialog;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;
import javax.swing.JTextField;
import java.awt.Point;
import javax.swing.SwingConstants;
import javax.swing.JButton;

public class Config extends JDialog {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JLabel jLabel = null;
	private JLabel jLabel1 = null;
	private JLabel jLabel11 = null;
	private JLabel jLabel111 = null;
	private JTextField RotorPort = null;
	private JTextField RadioPort = null;
	private JTextField AzStep = null;
	private JTextField ElStep = null;
	private JButton Ok = null;
	private JButton Cancel = null;

	public String RotPort = null;
	public String RadPort = null;
	public int minAzStep = 1;
	public int minElStep = 1;
	public boolean bOk = false;
	
	/**
	 * @param owner
	 */
	public Config(Frame owner) 
		{
		super(owner);
		RotPort = new String();
		RadPort = new String ();
		initialize();
		}

	public Config()
		{
		super();
		RotPort = new String();
		RadPort = new String ();
		initialize();
		}

	public void DoModal ()
		{
		RotorPort.setText(RotPort);
		RadioPort.setText(RadPort);
		AzStep.setText(Integer.toString(minAzStep));
		ElStep.setText(Integer.toString(minElStep));
		this.setModal(true);
		this.setVisible(true);
		}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(213, 235);
		this.setTitle("Track Controller Configuration");
		this.setName("TC_Config");
		this.setContentPane(getJContentPane());
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jLabel111 = new JLabel();
			jLabel111.setBounds(new Rectangle(26, 110, 72, 20));
			jLabel111.setHorizontalAlignment(SwingConstants.RIGHT);
			jLabel111.setHorizontalTextPosition(SwingConstants.RIGHT);
			jLabel111.setText("El. Step :");
			jLabel111.setPreferredSize(new Dimension(72, 20));
			jLabel11 = new JLabel();
			jLabel11.setBounds(new Rectangle(25, 80, 72, 20));
			jLabel11.setHorizontalTextPosition(SwingConstants.RIGHT);
			jLabel11.setText("Az. Step :");
			jLabel11.setHorizontalAlignment(SwingConstants.RIGHT);
			jLabel11.setPreferredSize(new Dimension(72, 20));
			jLabel1 = new JLabel();
			jLabel1.setHorizontalTextPosition(SwingConstants.RIGHT);
			jLabel1.setLocation(new Point(24, 49));
			jLabel1.setSize(new Dimension(72, 20));
			jLabel1.setPreferredSize(new Dimension(72, 20));
			jLabel1.setHorizontalAlignment(SwingConstants.RIGHT);
			jLabel1.setText("Radio Port :");
			jLabel = new JLabel();
			jLabel.setText("Rotor Port :");
			jLabel.setSize(new Dimension(68, 20));
			jLabel.setHorizontalTextPosition(SwingConstants.RIGHT);
			jLabel.setHorizontalAlignment(SwingConstants.RIGHT);
			jLabel.setLocation(new Point(28, 20));
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(jLabel, null);
			jContentPane.add(getRotorPort(), null);
			jContentPane.add(jLabel1, null);
			jContentPane.add(getRadioPort(), null);
			jContentPane.add(jLabel11, null);
			jContentPane.add(getAzStep(), null);
			jContentPane.add(jLabel111, null);
			jContentPane.add(getElStep(), null);
			jContentPane.add(getOk(), null);
			jContentPane.add(getCancel(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes RotorPort	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getRotorPort() {
		if (RotorPort == null) {
			RotorPort = new JTextField();
			RotorPort.setBounds(new Rectangle(101, 20, 77, 20));
			RotorPort.setText("COM3");
			RotorPort.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
					{
					RotPort = RotorPort.getText();
					}
			});
		}
		return RotorPort;
	}

	/**
	 * This method initializes RadioPort	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getRadioPort() {
		if (RadioPort == null) {
			RadioPort = new JTextField();
			RadioPort.setText("COM4");
			RadioPort.setBounds(new Rectangle(101, 50, 77, 20));
			RadioPort.setPreferredSize(new Dimension(77, 20));
			RadioPort.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
					{
					RadPort = RadioPort.getText();
					}
			});
		}
		return RadioPort;
	}

	/**
	 * This method initializes AzStep	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getAzStep() {
		if (AzStep == null) {
			AzStep = new JTextField();
			AzStep.setBounds(new Rectangle(101, 80, 77, 20));
			AzStep.setText("2");
			AzStep.setPreferredSize(new Dimension(77, 20));
			AzStep.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
					{
					String s = new String (AzStep.getText());
					minAzStep = Integer.parseInt(s.trim());
					}
			});
		}
		return AzStep;
	}

	/**
	 * This method initializes ElStep	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getElStep() {
		if (ElStep == null) {
			ElStep = new JTextField();
			ElStep.setBounds(new Rectangle(101, 110, 77, 20));
			ElStep.setText("2");
			ElStep.setPreferredSize(new Dimension(77, 20));
			ElStep.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
					{
					String s = new String (ElStep.getText());
					minElStep = Integer.parseInt(s.trim());
					}
			});
		}
		return ElStep;
	}

	/**
	 * This method initializes Ok	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getOk() {
		if (Ok == null) {
			Ok = new JButton();
			Ok.setBounds(new Rectangle(26, 164, 59, 19));
			Ok.setText("Ok");
			Ok.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					bOk = true;
					setVisible (false);
					dispose();
					}
			});
		}
		return Ok;
	}

	/**
	 * This method initializes Cancel	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getCancel() {
		if (Cancel == null) {
			Cancel = new JButton();
			Cancel.setBounds(new Rectangle(103, 164, 81, 18));
			Cancel.setText("Cancel");
			Cancel.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					bOk = false;
					setVisible (false);
					dispose();
					}
			});
		}
		return Cancel;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
