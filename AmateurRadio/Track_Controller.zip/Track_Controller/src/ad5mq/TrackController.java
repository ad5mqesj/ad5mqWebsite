package ad5mq;


import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.Dimension;
import java.awt.Image;

import javax.swing.JTextField;
import java.awt.Rectangle;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JButton;

import org.apache.log4j.Logger;

import com.google.code.jdde.client.Advise;
import com.google.code.jdde.client.ClientConversation;
import com.google.code.jdde.client.DdeClient;
//import com.google.code.jdde.client.event.AdviseDataListener;
//import com.google.code.jdde.event.AdviseDataEvent;

import java.awt.Point;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.Externalizable;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.*;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JToggleButton;
import java.awt.Toolkit;
import java.awt.ComponentOrientation;
import javax.swing.JCheckBox;

public class TrackController extends JFrame implements Externalizable{

	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(TrackController.class.getName());
	private static final TrackController INSTANCE = new TrackController();  //  @jve:decl-index=0:visual-constraint="383,24"

	private JPanel jContentPane = null;  //  @jve:decl-index=0:visual-constraint="21,89"
	private JTextField TrackEl = null;
	private JTextArea Coordlist = null;
	private JScrollPane Coordlistsp = null;
	private JLabel Lab1 = null;
	private JLabel CurPos = null;
	private JLabel jLabel21 = null;
	private JLabel XmtFrq = null;
	private JLabel RcvFrq = null;
	private JLabel jLabel211 = null;
	private JLabel jLabel2 = null;
	private JLabel DDE_String = null;
	private JButton Home = null;
	private JButton start = null;
	private JButton Up = null;
	private JButton Down = null;
	private JButton Right = null;
	private JButton Left = null;
	private JButton Configure = null;
	private JButton CTrk = null;
	private JButton ClrLst = null;
	private JToggleButton jDdeTrk = null;
	private JToggleButton Track = null;
	private JCheckBox NoRadio = null;

	public String Rotport;  //  @jve:decl-index=0:
	public String Radport;
	public int minAzStep;
	public int minElStep;
	
	private Rotor rotor;
	private Radio ft767;
	private List<TrackPoint> tpList = new ArrayList<TrackPoint>();  //  @jve:decl-index=0:
	private Timer trk_timer;
	private int minT;
	private JLabel curTime = null;
	private boolean track_started=false;
	private boolean dde_track_started=false;
	private JLabel jLabel22 = null;
	DdeClient client = null;
	ClientConversation conv = null;
	Advise advise = null;
	String service = new String ("Orbitron");
	String topic = new String ("Tracking");
	String ddeitem = new String ("TrackingDataEx");
	boolean radioOff = false;
	
	public static final TrackController getInstance() 
		{
	    return INSTANCE;
	    }
	
	/**
	 * This is the default constructor
	 */
	private TrackController() {
		super();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setDefaultLookAndFeelDecorated(true);
    	try
		{
		ObjectInputStream i = new ObjectInputStream(
				new FileInputStream("config/TrackController.out"));
		this.readExternal(i);
		i.close();
		}//try
	catch (IOException ex)
		{
		logger.debug("IO Exception - failed to read stored state.");
		Rotport = new String ("COM3");
		Radport = new String ("COM4");
		minAzStep = 2;
		minElStep = 3;
		}
	catch (ClassNotFoundException ex)
		{
		logger.debug("Exception ClassNotFoundException - failed to read stored state.");
		Rotport = new String ("COM3");
		Radport = new String ("COM4");
		minAzStep = 2;
		minElStep = 3;
		}

		setContentPane(getJContentPane());
		initialize();
		setLocationRelativeTo(null);
		rotor = new Rotor();
		ft767 = new Radio();
		try {
			client = new DdeClient();
			conv = client.connect(service, topic);
			}
		catch (Exception e)
			{
			logger.debug("DDE Exception - failed to send command. " + e.getStackTrace());
			conv = null;
			}
		this.addWindowListener(new WindowAdapter() 
			{
		    // save state
		    public void windowClosing( WindowEvent event )
		      	{
		    	CleanUp();
		      	}
		  	} // end anonymous inner class
		); // end call to addWindowListener	
	trk_timer = new Timer();
	trk_timer.schedule(new TrackTask(), 1000, 500);
	}//TrackController

	public void writeExternal(ObjectOutput out)	throws IOException 
		{
		out.writeObject(Rotport);
		out.writeObject(Radport);
		out.writeInt(minAzStep);
		out.writeInt(minElStep);
		}//serializer write
	
	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException
		{
		Rotport = new String ((String)in.readObject ());
		Radport = new String ((String)in.readObject ());
		minAzStep = in.readInt();
		minElStep = in.readInt();
		}//serializer read

	private void CleanUp()
		{
		logger.info("Saving state at exit.");
		trk_timer.cancel();
		try
			{
			if (ft767.isOpen())
				ft767.ReleaseControl();
			ObjectOutputStream o = new ObjectOutputStream(
					new FileOutputStream("config/TrackController.out"));
			//write direct so we dont get extra crap thats unneeded
			o.writeObject(Rotport);
			o.writeObject(Radport);
			o.writeInt(minAzStep);
			o.writeInt(minElStep);
			o.close();
			}//try
		catch (IOException ex)
			{
			logger.debug("Exception - failed to save state.");
			}
		}
	
    protected ImageIcon createImageIcon(String path) 
		{
	    Image img = Toolkit.getDefaultToolkit().getImage(getClass().getResource((path)));
	    if (img != null) 
	    	{
	        return new ImageIcon(img);
	    	} 
	    else 
	    	{
	        System.err.println("Couldn't find file: " + path);
	        return null;
	    	}
		}//createImageIcon
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(new Dimension(330, 463));
		this.setPreferredSize(new Dimension(330, 449));
		Image img = createImageIcon("ftrk.png").getImage();
		setIconImage(img);
		this.setContentPane(getJContentPane());
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("Track Controller");
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			DDE_String = new JLabel();
			DDE_String.setBounds(new Rectangle(15, 359, 288, 16));
			DDE_String.setText("");
			jLabel22 = new JLabel();
			jLabel22.setBounds(new Rectangle(11, 257, 85, 16));
			jLabel22.setText("Local Time");
			curTime = new JLabel();
			curTime.setBounds(new Rectangle(98, 257, 70, 16));
			curTime.setHorizontalAlignment(SwingConstants.CENTER);
			curTime.setToolTipText("Local Time (24 hour format)");
			curTime.setText(" 12:34:45");
			jLabel2 = new JLabel();
			jLabel2.setBounds(new Rectangle(12, 255, 77, 16));
			jLabel2.setText("Current Pos");
			jLabel2 = new JLabel();
			jLabel2.setBounds(new Rectangle(11, 241, 85, 16));
			jLabel2.setText("Current Pos.");
			jLabel211 = new JLabel();
			jLabel211.setText("Rcv. Freq");
			jLabel211.setLocation(new Point(13, 404));
			jLabel211.setSize(new Dimension(69, 16));
			RcvFrq = new JLabel();
			RcvFrq.setText("435.309");
			RcvFrq.setSize(new Dimension(62, 16));
			RcvFrq.setLocation(new Point(89, 404));
			RcvFrq.setHorizontalAlignment(SwingConstants.CENTER);
			XmtFrq = new JLabel();
			XmtFrq.setBounds(new Rectangle(89, 384, 61, 16));
			XmtFrq.setText("144.928");
			XmtFrq.setHorizontalAlignment(SwingConstants.CENTER);
			jLabel21 = new JLabel();
			jLabel21.setBounds(new Rectangle(13, 384, 68, 16));
			jLabel21.setText("Xmit. Freq");
			CurPos = new JLabel();
			CurPos.setBounds(new Rectangle(98, 241, 70, 16));
			CurPos.setHorizontalAlignment(SwingConstants.CENTER);
			CurPos.setToolTipText("Last Known mount position");
			CurPos.setText("0:0");
			Lab1 = new JLabel();
			Lab1.setBounds(new Rectangle(4, 3, 308, 16));
			Lab1.setToolTipText("Angles as integer degrees, time as hh:mm:ss, freq in MHz");
			Lab1.setText("Enter look angles as : Az,El,Time,xmit frq,rcv frq");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.setSize(new Dimension(330, 449));
			jContentPane.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
			jContentPane.add(getTrackEl(), null);
			jContentPane.add(Lab1, null);
			jContentPane.add(getCoordlist(), null);
			jContentPane.add(getHome(), null);
			jContentPane.add(getStart(), null);
			jContentPane.add(jLabel2, null);
			jContentPane.add(CurPos, null);
			jContentPane.add(getUp(), null);
			jContentPane.add(getDown(), null);
			jContentPane.add(getRight(), null);
			jContentPane.add(getLeft(), null);
			jContentPane.add(jLabel21, null);
			jContentPane.add(XmtFrq, null);
			jContentPane.add(RcvFrq, null);
			jContentPane.add(jLabel211, null);
			jContentPane.add(getJDdeTrk(), null);
			jContentPane.add(getTrack(), null);
			jContentPane.add(getConfigure(), null);
			jContentPane.add(getCTrk(), null);
			jContentPane.add(curTime, null);
			jContentPane.add(getClrLst(), null);
			jContentPane.add(jLabel22, null);
			jContentPane.add(DDE_String, null);
			jContentPane.add(getNoRadio(), null);
			jContentPane.add(jLabel2, null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes TrackEl	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTrackEl() {
		if (TrackEl == null) {
			TrackEl = new JTextField();
			TrackEl.setBounds(new Rectangle(4, 19, 310, 20));
			TrackEl.setToolTipText("Angles as integer degrees, time as hh:mm:ss, freq in MHz");
			TrackEl.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusLost(java.awt.event.FocusEvent e) 
					{
					String s = new String (TrackEl.getText());
					TrackPoint tp = new TrackPoint();
					if (tp.ParseInp(s)){
						tpList.add(tp);
						fillCoordList();
						}
					}
			});
		}
		return TrackEl;
	}

	void fillCoordList ()
		{
		Coordlist. setText("");
		Object pts[] = tpList.toArray();
		for (int i = 0, j = pts.length; i < j; i++) {
			String element = pts[i].toString();
			Coordlist.append(element);
			Coordlist.append("\r\n");
			}	 
		TrackEl.setText("");
		TrackEl.requestFocus();
		}//fillCoordList

	/**
	 * This method initializes ClrLst	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getClrLst() {
		if (ClrLst == null) {
			ClrLst = new JButton();
			ClrLst.setBounds(new Rectangle(210, 298, 104, 24));
			ClrLst.setText("Clear");
			ClrLst.setToolTipText("Clear Track List");
			ClrLst.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					tpList.clear();
					Coordlist. setText("");
					}
			});
		}
		return ClrLst;
	}

	/**
	 * This method initializes Coordlist	
	 * 	
	 * @return javax.swing.JTextArea	
	 */
	private JScrollPane getCoordlist() {
		if (Coordlist == null) {
			Coordlist = new JTextArea();
			Coordlist.setBounds(new Rectangle(4, 41, 304, 144));
			Coordlist.setToolTipText("List of tracking points in current track");
			Coordlistsp = new JScrollPane(Coordlist);
			Coordlistsp.setBounds(new Rectangle(4, 41, 310, 154));
			Coordlistsp.setViewportView(Coordlist);
		}
		return Coordlistsp;
	}

	/**
	 * This method initializes CTrk	
	 * 	
	 * @return javax.swing.JToggleButton	
	 */
	private JButton getCTrk() {
		if (CTrk == null) {
			CTrk = new JButton();
			CTrk.setBounds(new Rectangle(210, 238, 104, 24));
			CTrk.setText("Compute");
			CTrk.setToolTipText("Compute full track from 3 points");
			CTrk.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					if (tpList.size() != 3)
						return;
					//assume list is standard order from Orbitron
					Object pts[] = tpList.toArray();
					int MaxAz=0, MinAz=400, AzIn=0;
					int MaxEl=0, MinEl=400, ElIn=0;
					int tMin=86400,tMax=0,It=0, tMix=0;
					float minRf=2400.0f, maxRf = 1.0f, Irf=0.0f;
					float minTf=2400.0f, maxTf = 1.0f, Itf=0.0f;
					
					for (int i = 0, j = pts.length; i < j; i++) 
						{
						TrackPoint t = (TrackPoint)pts[i];
						if (t.Az > MaxAz)
							MaxAz =t.Az;
						if (t.El > MaxEl)
							MaxEl =t.El;
						if (MinAz > t.Az)
							MinAz = t.Az;
						if (MinEl > t.El)
							MinEl = t.El;
						if (t.rcv_frq > maxRf)
							maxRf = t.rcv_frq;
						if (t.xmit_frq > maxTf)
							maxTf = t.xmit_frq;
						if (minRf > t.rcv_frq)
							minRf = t.rcv_frq;
						if (minTf > t.xmit_frq)
							minTf = t.xmit_frq;
						}//for each point
					for (int i = 0, j = pts.length; i < j; i++) 
						{
						TrackPoint t = (TrackPoint)pts[i];
						if (t.tm > tMax)
							{
							tMax = t.tm;
							tMix = i;
							}
						if (tMin > t.tm)
							tMin = t.tm;
						}
					int tdir = 1;
					if ( ((TrackPoint)pts[tMix]).Az == MinAz)
						tdir = -1;
					int rdir = 1;
					if ( ((TrackPoint)pts[tMix]).rcv_frq == minRf)
						rdir = -1;
					AzIn = MaxAz - MinAz;
					ElIn = MaxEl - MinEl;
					It = tMax - tMin;
					Irf = maxRf-minRf;
					Itf = maxTf - minTf;
					int minTe = (int)((double)It*Math.asin((double)(minElStep)/(double)ElIn)/3.1415926);
					int minTa = (int)((double)minAzStep/(double)AzIn*(double)It);
					minT = Math.max(minTe, minTa);
					List<TrackPoint> NewtpList = new ArrayList<TrackPoint>();
					for (int t = 0; t < It; t += minT)
						{
						TrackPoint n = new TrackPoint();
						n.tm =  ((TrackPoint)pts[0]).tm + t;
						if (tdir > 0)
							n.Az = MinAz + (int)(((double)t/(double)It)*AzIn);
						else
							n.Az = MaxAz - (int)(((double)t/(double)It)*AzIn);
						n.El = MinEl + (int)(ElIn*Math.sin((double)t/(double)It*3.1415926));
						if (rdir > 0) {
							n.rcv_frq = minRf + (float)(((double)t/(double)It)*Irf);
							n.xmit_frq = maxTf - (float)(((double)t/(double)It)*Itf);
						}
						else {
							n.rcv_frq = maxRf - (float)(((double)t/(double)It)*Irf);
							n.xmit_frq = minTf + (float)(((double)t/(double)It)*Itf);
						}
						NewtpList.add(n);
						}
					tpList = NewtpList;
					fillCoordList();
					}
			});
		}
		return CTrk;
	}
	/**
	 * This method initializes Home	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getHome() {
		if (Home == null) {
			Home = new JButton();
			Home.setBounds(new Rectangle(6, 208, 95, 24));
			Home.setText("Home");
			Home.setToolTipText("Send mount to 0,0");
			Home.setName("Home");
			Home.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					//try to reconnect if not connected - but only once
					System.out.println ("home clicked");
					if (!rotor.isOpen())
						rotor.connect(Rotport);
					if (!rotor.isOpen())
						return;
					System.out.println ("home clicked - port open");
					rotor.Goto(new Position (0,0));
					Position p = rotor.getLastPos();
					CurPos.setText(Integer.toString(p.Az())+" : "+Integer.toString(p.El()));
					}
				});
		}
		return Home;
	}

	/**
	 * This method initializes start	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getStart() {
		if (start == null) {
			start = new JButton();
			start.setBounds(new Rectangle(104, 208, 104, 24));
			start.setToolTipText("Go to first (in time) set of angles");
			start.setPreferredSize(new Dimension(96, 24));
			start.setText("Goto Start");
			start.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					GotoTrackPoint (tpList.get(0));
					//fix pos display
					Position p = rotor.getLastPos();
					CurPos.setText(Integer.toString(p.Az())+" : "+Integer.toString(p.El()));
					//fix freq. display
					RcvFrq.setText(String.format("%6.3f", ft767.cstat.operating_freq));
					if (ft767.cstat.isVFO_B() && ft767.cstat.isSplit())
						XmtFrq.setText(String.format("%6.3f", ft767.cstat.VFO_A_Freq));
					else if (ft767.cstat.isSplit())
						XmtFrq.setText(String.format("%6.3f", ft767.cstat.VFO_B_Freq));
					else
						XmtFrq.setText(String.format("%6.3f", ft767.cstat.operating_freq));
					}
				});
		}
		return start;
	}

	/**
	 * This method initializes Up	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getUp() {
		if (Up == null) {
			Up = new JButton();
			Up.setPreferredSize(new Dimension(20, 20));
			Up.setSize(new Dimension(20, 20));
			Up.setText("");
			Up.setToolTipText("Jog Elevation Up");
			Up.setHorizontalTextPosition(SwingConstants.CENTER);
			Up.setFont(new Font("Dialog", Font.BOLD, 12));
			Up.setHorizontalAlignment(SwingConstants.CENTER);
			Up.setIcon(new ImageIcon(getClass().getResource("/ad5mq/up_arw.gif")));
			Up.setLocation(new Point(84, 285));
			Up.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					//try to reconnect if not connected - but only once
					if (!rotor.isOpen())
						rotor.connect(Rotport);
					if (!rotor.isOpen())
						return;
					Position cp = new Position();
					if (!rotor.getPosition(cp))
						return;
					//jog el up by min. step
					cp.El(cp.El()+minElStep);
					rotor.Goto(cp);
					Position p = rotor.getLastPos();
					CurPos.setText(Integer.toString(p.Az())+" : "+Integer.toString(p.El()));
					}
				});
		}
		return Up;
	}
	/**
	 * This method initializes Down	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getDown() {
		if (Down == null) {
			Down = new JButton();
			Down.setPreferredSize(new Dimension(20, 20));
			Down.setToolTipText("Jog Elevation Down");
			Down.setHorizontalAlignment(SwingConstants.CENTER);
			Down.setHorizontalTextPosition(SwingConstants.CENTER);
			Down.setIcon(new ImageIcon(getClass().getResource("/ad5mq/dn_arw.gif")));
			Down.setText("");
			Down.setSize(new Dimension(20, 20));
			Down.setLocation(new Point(84, 335));
			Down.setFont(new Font("Dialog", Font.BOLD, 12));
			Down.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					//try to reconnect if not connected - but only once
					if (!rotor.isOpen())
						rotor.connect(Rotport);
					if (!rotor.isOpen())
						return;
					Position cp = new Position();
					if (!rotor.getPosition(cp))
						return;
					//jog el down by min. step
					cp.El(cp.El()-minElStep);
					rotor.Goto(cp);
					Position p = rotor.getLastPos();
					CurPos.setText(Integer.toString(p.Az())+" : "+Integer.toString(p.El()));
					}
				});
		}
		return Down;
	}
	/**
	 * This method initializes Right	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getRight() {
		if (Right == null) {
			Right = new JButton();
			Right.setPreferredSize(new Dimension(20, 20));
			Right.setToolTipText("Jog Azimuth East");
			Right.setHorizontalAlignment(SwingConstants.CENTER);
			Right.setHorizontalTextPosition(SwingConstants.CENTER);
			Right.setIcon(new ImageIcon(getClass().getResource("/ad5mq/rt_arw.gif")));
			Right.setText("");
			Right.setSize(new Dimension(20, 20));
			Right.setLocation(new Point(109, 310));
			Right.setFont(new Font("Dialog", Font.BOLD, 12));
			Right.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					//try to reconnect if not connected - but only once
					if (!rotor.isOpen())
						rotor.connect(Rotport);
					if (!rotor.isOpen())
						return;
					Position cp = new Position();
					if (!rotor.getPosition(cp))
						return;
					//jog az right (ccw) by min. step
					cp.Az(cp.Az()-minAzStep);
					rotor.Goto(cp);
					Position p = rotor.getLastPos();
					CurPos.setText(Integer.toString(p.Az())+" : "+Integer.toString(p.El()));
					}
				});
		}
		return Right;
	}
	/**
	 * This method initializes Left	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getLeft() {
		if (Left == null) {
			Left = new JButton();
			Left.setPreferredSize(new Dimension(20, 20));
			Left.setToolTipText("Jog Azimuth West");
			Left.setHorizontalAlignment(SwingConstants.CENTER);
			Left.setHorizontalTextPosition(SwingConstants.CENTER);
			Left.setIcon(new ImageIcon(getClass().getResource("/ad5mq/lt_arw.gif")));
			Left.setText("");
			Left.setSize(new Dimension(20, 20));
			Left.setLocation(new Point(59, 310));
			Left.setFont(new Font("Dialog", Font.BOLD, 12));
			Left.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					//try to reconnect if not connected - but only once
					if (!rotor.isOpen())
						rotor.connect(Rotport);
					if (!rotor.isOpen())
						return;
					Position cp = new Position();
					if (!rotor.getPosition(cp))
						return;
					//jog az left (cw) by min. step
					cp.Az(cp.Az()+minAzStep);
					rotor.Goto(cp);
					Position p = rotor.getLastPos();
					CurPos.setText(Integer.toString(p.Az())+" : "+Integer.toString(p.El()));
					}
				});
		}
		return Left;
	}
	/**
	 * This method initializes jDdeTrk	
	 * 	
	 * @return javax.swing.JToggleButton	
	 */
	private JToggleButton getJDdeTrk() {
		if (jDdeTrk == null) {
			jDdeTrk = new JToggleButton();
			jDdeTrk.setText("DDE Trk");
			ImageIcon ico = createImageIcon("Play-Normal.png");
			jDdeTrk.setIcon (ico);
			ico = createImageIcon("Stop-Normal-Blue.png");
			jDdeTrk.setPressedIcon (ico);
			jDdeTrk.setBounds(new Rectangle(210, 268, 104, 24));
			jDdeTrk.setToolTipText("Track from Orbitron DDE");
			jDdeTrk.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					if (jDdeTrk.isSelected())
						{
						if (client == null || conv == null){
						try {
							if (client == null)
								client = new DdeClient();
							conv = client.connect(service, topic);
							}
						catch (Exception ex)
							{
							logger.debug("DDE Exception - failed to send command. " + ex.getStackTrace());
							return;
							}
						}
						jDdeTrk.setText("Stop");
						ImageIcon ico = createImageIcon("Stop-Normal-Blue.png");
						jDdeTrk.setIcon (ico);
						dde_track_started = true;
/*						advise = conv.startAdvise(ddeitem, new AdviseDataListener() {
					        @Override
					        public void valueChanged(AdviseDataEvent event) {
					                byte[] data = event.getData();
									String s = new String (data);
									TrackPoint t = ParseDDE(s);
									CurPos.setText(Integer.toString(t.Az)+" : "+Integer.toString(t.El));
									RcvFrq.setText(String.format("%6.3f", t.rcv_frq));
									XmtFrq.setText(String.format("%6.3f", t.xmit_frq));
									if (t.El > 3)
										GotoTrackPoint(t);
					        		}
								});
*/						}//if button selected
					else
						{
						jDdeTrk.setText("DDE Trk");
						ImageIcon ico = createImageIcon("Play-Normal.png");
						jDdeTrk.setIcon (ico);
						dde_track_started = false;
						if (advise != null)
							advise.stop();
						}
					}
			});
		}
		return jDdeTrk;
	}
	/**
	 * This method initializes Track	
	 * 	
	 * @return javax.swing.JToggleButton	
	 */
	private JToggleButton getTrack() {
		if (Track == null) {
			Track = new JToggleButton();
			Track.setBounds(new Rectangle(210, 208, 104, 24));
			Track.setToolTipText("Track list");
			Track.setHorizontalTextPosition(SwingConstants.RIGHT);
			Track.setText("Track");
			ImageIcon ico = createImageIcon("Play-Normal.png");
			Track.setIcon (ico);
			ico = createImageIcon("Stop-Normal-Blue.png");
			Track.setPressedIcon (ico);
			Track.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					if (Track.isSelected())
						{
						Track.setText("Stop");
						ImageIcon ico = createImageIcon("Stop-Normal-Blue.png");
						Track.setIcon (ico);
						track_started = true;
						}//if button selected
					else
						{
						Track.setText("Track");
						ImageIcon ico = createImageIcon("Play-Normal.png");
						Track.setIcon (ico);
						track_started = false;
						}
					}
			});
		}
		return Track;
	}
	/**
	 * This method initializes Configure	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getConfigure() {
		if (Configure == null) {
			Configure = new JButton();
			Configure.setToolTipText("Configure serial ports, jog steps");
			Configure.setText("Config");
			Configure.setBounds(new Rectangle(211, 396, 104, 24));
			Configure.setName("Home");
			Configure.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					Config dlg = new Config();
					dlg.RotPort = Rotport;
					dlg.RadPort= Radport;
					dlg.minAzStep= minAzStep;
					dlg.minElStep= minElStep;
					dlg.DoModal();
					if (dlg.bOk)
						{
						//re-connect if port changed.
						if (!Rotport.contains(dlg.RotPort))
							rotor.connect(Rotport);
						if (!Radport.contains(dlg.RadPort))
							ft767.connect(Radport);
						Rotport = new String (dlg.RotPort);
						Radport = new String (dlg.RadPort);
						minAzStep = dlg.minAzStep;
						minElStep = dlg.minElStep;
						}
					}
			});
		}
		return Configure;
	}
	/**
	 * This method initializes NoRadio	
	 * 	
	 * @return javax.swing.JCheckBox	
	 */
	private JCheckBox getNoRadio() {
		if (NoRadio == null) {
			NoRadio = new JCheckBox();
			NoRadio.setBounds(new Rectangle(208, 329, 102, 21));
			NoRadio.setToolTipText("Dont send Freq. updates to radio");
			NoRadio.setText("No Radio");
			NoRadio.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
					{
					if (NoRadio.isSelected()) radioOff = true;
					else radioOff = false;
					}
			});
		}
		return NoRadio;
	}

	class TrackTask extends TimerTask {
		private int ixPt = 0;
		public void run (){
				Calendar cal = new GregorianCalendar();
				int hour = cal.get(Calendar.HOUR_OF_DAY);     
				int min = cal.get(Calendar.MINUTE);            
				int sec = cal.get(Calendar.SECOND);             
				String ctime = new String();
				ctime = String.format("%02d",hour)+":"+String.format("%02d",min)+":"+String.format("%02d",sec);
				curTime.setText (ctime);
				int secondsSinceMidnight = hour * 3600 + min * 60 + sec;
				if (track_started && tpList.size() > 2)
					{
					long st = tpList.get(ixPt).tm;
					int dif = (int)(st - secondsSinceMidnight);
					if (dif <= 0)
						{
						GotoTrackPoint (tpList.get(ixPt));
						ixPt++;
						Position p2 = rotor.getLastPos();
						CurPos.setText(Integer.toString(p2.Az())+" : "+Integer.toString(p2.El()));
						RcvFrq.setText(String.format("%6.3f", ft767.cstat.operating_freq));
						if (ft767.cstat.isVFO_B() && ft767.cstat.isSplit())
							XmtFrq.setText(String.format("%6.3f", ft767.cstat.VFO_A_Freq));
						else if (ft767.cstat.isSplit())
							XmtFrq.setText(String.format("%6.3f", ft767.cstat.VFO_B_Freq));
						else
							XmtFrq.setText(String.format("%6.3f", ft767.cstat.operating_freq));

						if (ixPt >= tpList.size())
							this.cancel();
						}//if its time to start
					}//if there is a track list
				if (dde_track_started)
					{
					byte[] data = conv.request(ddeitem);
					String s = new String (data);
					TrackPoint t = ParseDDE(s);
					CurPos.setText(Integer.toString(t.Az)+" : "+Integer.toString(t.El));
					RcvFrq.setText(String.format("%6.3f", t.rcv_frq));
					XmtFrq.setText(String.format("%6.3f", t.xmit_frq));
					if (t.El > 3)
						GotoTrackPoint(t);
					}//if dde track
			}//track task run
		public boolean cancel(){
			ixPt = 0;
			track_started=false;
			return (true);
		}
	}//TrackTask
	
	TrackPoint ParseDDE (String s)
		{
		TrackPoint t = new TrackPoint();
		String name;
		int ix1,ix2;
		float xfrq,rfrq,f;
		try {
		if (s.length() > 3){
			ix1 = s.indexOf ("SN");
			ix2 = s.indexOf("AZ");
			name = s.substring(ix1+3,ix2-2);
			ix1 = s.indexOf("EL");
			f = Float.parseFloat(s.substring(ix2+2, ix1));
			t.Az = (int)f;
			ix2 = s.indexOf("DN");
			f = Float.parseFloat(s.substring(ix1+2, ix2));
			t.El = (int)f;
			ix1 = s.indexOf("UP");
			rfrq = Float.parseFloat(s.substring(ix2+2, ix1));
			t.rcv_frq = rfrq / 1000000.0f;
			ix2 = s.indexOf("RA");
			xfrq = Float.parseFloat(s.substring(ix1+2, ix1+12));
			t.xmit_frq = xfrq / 1000000.0f;
			if (t.El < 3)
				DDE_String.setText("Below Horizon : "+name);
			else
				DDE_String.setText("Tracking : "+name);
			}
		return t;
		}//try
		catch (Exception e) //mostly floating pt exceptions
			{
			t.El = 0;
			return t;
			}
		}//ParseDDE
	
	void GotoTrackPoint (TrackPoint t){
		Position p = new Position();
		p.Az(t.Az);
		p.El(t.El);
		//open rotor port if nesc.
		if (!rotor.isOpen())
			rotor.connect(Rotport);
		rotor.Goto(p);
		//set up radio if ffreq's are defined
		if (t.xmit_frq < 1.0 && t.rcv_frq < 1.0)
			return;
		//open radio port if nesc.
		if (radioOff)
			return;
		if (!ft767.isOpen())
			ft767.connect(Radport);
		//Take control or we can't get status
		ft767.TakeControl();
		try {
			while (ft767.cstat.isTransmitting()) Thread.sleep(250);
		}
		catch (Exception e){return;}
		if (ft767.cstat.isSplit())
			{
			if(ft767.cstat.isVFO_B())	//VFO B for receive
				{
				if (Math.abs(t.rcv_frq - ft767.cstat.VFO_B_Freq) > 0.0015)
					ft767.setVFO_B(t.rcv_frq);
				if (Math.abs(t.xmit_frq - ft767.cstat.VFO_A_Freq) > 0.0015){
					ft767.setVFO_A(t.xmit_frq);
					ft767.setVFOrcv(Radio.VFOB);
					}
				}
			else
				{
				if (Math.abs(t.rcv_frq - ft767.cstat.VFO_A_Freq) > 0.0025)
					ft767.setVFO_A(t.rcv_frq);
				if (Math.abs(t.xmit_frq - ft767.cstat.VFO_B_Freq) > 0.0025){
					ft767.setVFO_B(t.xmit_frq);
					ft767.setVFOrcv(Radio.VFOA);
					}
				}
			}
		else
			{
			if(ft767.cstat.isVFO_B()){	//VFO B for receive
				if (Math.abs(t.xmit_frq - ft767.cstat.VFO_B_Freq) > 0.0025)
					ft767.setVFO_B(t.xmit_frq);
				}
			else{
				if (Math.abs(t.xmit_frq - ft767.cstat.VFO_A_Freq) > 0.0025)
					ft767.setVFO_A(t.xmit_frq);
				}
			}
	}//GotoTrackPoint

}  //  @jve:decl-index=0:visual-constraint="19,62"
