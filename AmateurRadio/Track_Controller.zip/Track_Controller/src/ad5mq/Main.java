package ad5mq;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Main {
	static Logger logger = Logger.getLogger(Main.class.getName());
	/**
	 * Launches this application
	 */
	public static void main(String[] args) 
		{
	    PropertyConfigurator.configure("config/TrackController.log.config");
	    TrackController application = TrackController.getInstance();
		application.setVisible(true);
		}

}
