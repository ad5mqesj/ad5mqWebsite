package ad5mq;

public class TrackPoint {

	public int Az;
	public int El;
	public int tm;
	public float xmit_frq;
	public float rcv_frq;
	TrackPoint()
		{
		Az = -1000;
		El = -200;
		xmit_frq = 0.0f;
		rcv_frq = 0.0f;
		}
	boolean ParseInp (String s)
		{
		int i;
		String parts[] = s.split("[,]");
		if (parts.length < 2)
			return false;
		i = Integer.parseInt(parts[0]);
		if (i > 360 || i < -360)
			return false;
		Az = i;
		i = Integer.parseInt(parts[1]);
		if (i > 90 || i < -90)
			return false;
		El = i;
		if (parts.length >= 3)
			{
			String tp[] = parts[2].split("[:]");
			int hr = Integer.parseInt(tp[0]);
			int min = Integer.parseInt(tp[1]);
			int sec = Integer.parseInt(tp[2]);
			tm = hr*3600+min*60+sec;
			}
		if (parts.length > 3 && parts.length < 5)
			return false;
		else if (parts.length==3)
			return true;
		xmit_frq = Float.parseFloat(parts[3]);
		rcv_frq = Float.parseFloat(parts[4]);
		return true;
		}//ParseInp
	
	public String toString()
		{
		String s = new String();
		s += Integer.toString(Az);
		s += "; ";
		s += Integer.toString(El);
		s += "; ";
		int hr = tm / 3600;
		int min = (tm-hr*3600)/60;
		int sec = tm-hr*3600-min*60;
		s += String.format("%02d",hr)+":"+String.format("%02d",min)+":"+String.format("%02d",sec);
		if (xmit_frq < 1.6f)
			return s;
		s += "; ";
		s += String.format("%6.3f",xmit_frq);
		s += "; ";
		s += String.format("%6.3f",rcv_frq);
		return s;
		}
	
}