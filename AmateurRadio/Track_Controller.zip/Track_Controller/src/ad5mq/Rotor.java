package ad5mq;
import gnu.io.CommPort;
import gnu.io.CommPortIdentifier;
import gnu.io.SerialPort;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.lang.Math;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class Rotor 
{
	private SerialPort serialPort=null;
	private BufferedReader in=null;
	private PrintStream out=null;
	private Boolean isOpen;
	static Logger logger= Logger.getLogger(Rotor.class.getName());
	
	private Position lastPos;
	
	Rotor()
		{
	    PropertyConfigurator.configure("config/TrackController.log.config");
		logger.debug("Rotor class created.");
		isOpen = false;
		lastPos = new Position(0,0);
		}
	Boolean isOpen() {return isOpen;}
	
	void connect ( String portName )
    	{
		if (isOpen)
			return;
		try {
			logger.debug("Trying to open "+portName);
	        CommPortIdentifier portIdentifier = CommPortIdentifier.getPortIdentifier(portName);
	        if (portIdentifier.isCurrentlyOwned())
	        	{
	            System.out.println("Error: Port is currently in use");
	            isOpen = false;
				logger.info("Failed to open port " + portName + ". Port in use by another application.");
	        	}
	        else
	        	{
	            CommPort commPort = portIdentifier.open("TrackController",2000);
	            
	            if (commPort instanceof SerialPort)
	            	{
	    			logger.debug("Opened "+portName);
	                serialPort = (SerialPort) commPort;
	                //port to 9600,N,8,1 for rotor controller
	                serialPort.setSerialPortParams(9600,SerialPort.DATABITS_8,SerialPort.STOPBITS_1,SerialPort.PARITY_NONE);
	                
	                in = new BufferedReader(new InputStreamReader(serialPort.getInputStream()));
	                out = new PrintStream(serialPort.getOutputStream(), true, "ISO-8859-1");
	                isOpen = true;
	            	}
	            else
	            	{
	                System.out.println("Error: Only serial ports are handled by this example.");
	                isOpen = false;
	    			logger.info("Failed to open port " + portName + ". Its not a serial port.");
	            	}
	        	}//else port is available     
			}//try
		catch (Exception e)
			{
			logger.info("Failed to open port " + portName + ". Exception : "+e.getMessage());
			}
		}//connect
	
	void close ()
		{
		if (!isOpen)
			return;
		try {
			if (in!=null)  in.close();
			if (out!=null) out.close();
			if (serialPort!=null) serialPort.close();
			}//try
		catch (IOException i)
			{
			logger.debug("IO Exception - failed to close in or out stream. " + i.getStackTrace());
			}
		}//close
	
	Boolean getPosition (Position p)
		{
		String buffer;
        int len = -1;
        
		if (!isOpen)
			return false;
		try {
			out.print("P");
			out.print("\r");
			System.out.println ("sent P");

			//get the P\r echoed back
			buffer = in.readLine();
			len = buffer.length();
			while (len > 8)	//maybe someone power cycled since open - read next block
				{
				buffer = in.readLine();
				len = buffer.length();
				}
			//get the actual position
			buffer = in.readLine();
			len = buffer.length();
			while (len < 3)
				{
				buffer = in.readLine();
				len = buffer.length();
				}
			logger.debug("Got "+buffer+" from port");
			String delims="[:]";
			String[] tokens = buffer.split(delims);
			if (tokens.length < 2)
				return false;
			p.Az(Integer.parseInt(tokens[0].trim().substring(1)));
			p.El(Integer.parseInt(tokens[1].trim().substring(1)));
			logger.debug("position = Az:"+Integer.toString(p.Az())+" El:"+Integer.toString(p.El()));
			}//try
		catch (IOException i)
			{
			logger.debug("IO Exception - failed to get position. " + i.getStackTrace());
			return false;
			}
		catch (Exception e)
			{
			logger.debug("Other Exception - failed to get position. " + e.getStackTrace());
			return false;
			}
		lastPos = new Position (p.Az(),p.El());
		return true;
		}//getPosition
	
	Position getLastPos() {return lastPos;}
	
	Boolean Goto (Position targ)
		{
		String buffer;
		int len = -1;
		if (!isOpen)
			return false;
		Position cp = new Position();
		try {
			if (!getPosition (cp))
				{
				logger.info("failed to get old position. Target:" + Integer.toString(targ.Az()) + ":" + Integer.toString(targ.El()));
				return false;
				}
			if ((cp.El()-targ.El())!=0)	//need to move in el
				{
				String s = new String ("E"+Integer.toString(targ.El())+"\r");
				out.print (s);
				logger.debug("Sent "+s+" to port.");
				//wait for move to complete
				int stime = Math.abs(cp.El()-targ.El());
				stime = stime * 10000/60; //(10 ticks of 60Hz clock are 1 degree in El)
				Thread.sleep (stime);
				//get newly reported position
				buffer = in.readLine();
				len = buffer.length();
				while (len > 8)	//maybe someone power cycled since open - read next block
					{
					buffer = in.readLine();
					len = buffer.length();
					}
				}//if moving in El
			if ((cp.Az()-targ.Az())!=0)	//need to move in el
				{
				Thread.sleep(250);
				String s = new String ("A"+Integer.toString(targ.Az())+"\r");
				out.print (s);
				logger.debug("Sent "+s+" to port.");
				//wait for move to complete
				int stime =  Math.abs(cp.Az()-targ.Az());
				stime = stime * 15000/60; //(15 ticks of 60Hz clock are 1 degree in Az)
				Thread.sleep (stime);
				//get newly reported position
				buffer = in.readLine();
				len = buffer.length();
				while (len > 8)	//maybe someone power cycled since open - read next block
					{
					buffer = in.readLine();
					len = buffer.length();
					}
				}//if moving in El
			if (!getPosition (cp))
				{
				logger.info("failed to goto position. " + Integer.toString(targ.Az()) + ":" + Integer.toString(targ.El()));
				return false;
				}
			}//try
		catch (IOException i)
			{
			logger.debug("IO Exception - failed to goto position. " + i.getStackTrace());
			return false;
			}
		catch (InterruptedException e)
			{
			logger.debug("Interrupted Exception - failed to goto position. " + e.getStackTrace());
			return false;
			}
		return true;
		}//Goto
	
}//Rotor class
