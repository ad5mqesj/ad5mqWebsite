package ad5mq;

public class Position 
{
	private int Az;
	private int El;
	
	Position() {Az = 0; El = 0;}
	Position(int a, int e) {Az = a; El = e;}
	
	int Az() {return Az;}
	int El() {return El;}
	void Az(int a){Az=a;}
	void El(int e){El = e;}
}
