//File		: DBDef.h
//date		: 5-25-03
//author		: esj
//contents	: SQL statements to create each table in DB and then link them

namespace CTables
{

extern int numTables = 2;
extern char *Tables[2] = 

{"CREATE TABLE LoggerDBVersion ("
"   Version              INTEGER        NOT NULL" // Version number of data-base
");",

"CREATE TABLE Log ("
"  LogKey	            VARCHAR        NOT NULL,"  // Primary key for sysinfo
"  Call_ChainF				VARCHAR        NULL,"      // used to chain to next record for this call sign
"  Call_ChainB          VARCHAR        NULL,"		// used to chain to previous record for this call sign
"  RecTime              DATETIME       NULL,"      // date/time Local from system at start of contact
"  ContTime					DOUBLE         NOT NULL,"  // UTC Julian date time of contact
"  CallSign		         VARCHAR        NOT NULL,"  // Call Sign
"  NumContacts          INTEGER        NOT NULL,"  // number of contacts with this call Sign
"  Name			         VARCHAR        NULL,"		// Name
"  City			         VARCHAR        NULL,"		// City of contact
"  State			         VARCHAR        NULL,"		// state of contact
"  Country              VARCHAR        NOT NULL,"  // country of operation of contact
"  Mode                 VARCHAR        NULL,"	   // operating mode for contact
"  Band                 VARCHAR        NULL,"	   // Band (e.g. 80m) for contact
"  Frequency				DOUBLE         NULL,"		// Frequency of contact
"  Signal_Report        VARCHAR        NULL,"      // signal report
"  Comment              VARCHAR        NULL,"      // comments 
"  Class                VARCHAR        NULL,"	   // Field day operating class
"  NumXmitter           INTEGER        NULL,"		// number of transmitters for field day
"  Section              VARCHAR        NULL,"	   // Field day ARRL/RAC section of contact
 
"   CONSTRAINT LKPriKey  PRIMARY KEY (LogKey),"	   // make the key the primary key
"   CONSTRAINT LKPKU     UNIQUE      (LogKey)"     // make key unique
");"

};//Tables[][] initializer

}//name space CTables