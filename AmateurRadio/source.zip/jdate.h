//File		: jdate.h
//Date		: 2-6-96
//Contents	: DAAAC 4.0 (Dave) Julian Date time class
//Author		: Ed Johnson - Borrowed heavily from Cass' jdate.c

#ifndef _INC_JDATE

#if _MSC_VER >= 1000
#pragma once									//	Only Include Once!
#endif // _MSC_VER >= 1000

#ifdef _DEBUG
#pragma comment ( lib, "VossLibD.lib" )
#else
#pragma comment ( lib, "VossLib.lib" )
#endif

#ifndef __AFXDISP_H__
#include <afxdisp.h>		//	MFC OLE automation classes
#endif

#ifndef __SQLTYPES
#include <SqlTypes.h>	//	SQL Components
#endif

#ifdef TRACE_HEADERS
#pragma message ( "NOTE:  Included header file:  \"" __FILE__ "\"" )
#endif

typedef double	JDate;
typedef double *Pjdate;

class JDATE {
		public:
			long	 gd (int, int, int);
			void	 cd (long , int *, int *, int *);
			double jd (int, int, int, int, int, int, int);
			void	 Year2DST (int, double *, double *);
			double Now (void );
			void	 JD2GMT (double,int *, int *, int *, int *, int *, int *, int *);
			JDate  CvtCOleDateTime ( COleDateTime );
}; 

COleDateTime CurrentGmtTime ( void );
COleDateTime ConvertGmtTime ( COleDateTime OleGmtTime );

JDate GetCurrentJdTime ( void );

TIMESTAMP_STRUCT GetCurrentTimeStamp ( void );
TIMESTAMP_STRUCT JDateToTimeStamp ( JDate jdDateTime );

CTime				TimeStampToCTime			( TIMESTAMP_STRUCT &stGmtTimeStamp );
COleDateTime	TimeStampToCOleDateTime	( TIMESTAMP_STRUCT &stGmtTimeStamp );
double			TimeStampToJulianDay		( TIMESTAMP_STRUCT &stGmtTimeStamp );

#endif	//	_INC_JDATE