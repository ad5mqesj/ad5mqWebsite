#if !defined(AFX_USERDAT_H__195CC64B_E7DE_4DAC_BDFA_99297E27143F__INCLUDED_)
#define AFX_USERDAT_H__195CC64B_E7DE_4DAC_BDFA_99297E27143F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UserDat.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CUserDat dialog

class CUserDat : public CDialog
{
// Construction
public:
	CUserDat(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CUserDat)
	enum { IDD = IDD_USSERDAT };
	CString	m_Call;
	CString	m_City;
	CString	m_Country;
	CString	m_Name;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUserDat)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CUserDat)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_USERDAT_H__195CC64B_E7DE_4DAC_BDFA_99297E27143F__INCLUDED_)
