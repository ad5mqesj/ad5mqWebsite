// onfigRep1.cpp : implementation file
//

#include "stdafx.h"
#include "Logger.h"
#include "onfigRep1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ConfigRep1 dialog


ConfigRep1::ConfigRep1(CWnd* pParent /*=NULL*/)
	: CDialog(ConfigRep1::IDD, pParent)
{
	//{{AFX_DATA_INIT(ConfigRep1)
	//}}AFX_DATA_INIT
}


void ConfigRep1::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ConfigRep1)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(ConfigRep1, CDialog)
	//{{AFX_MSG_MAP(ConfigRep1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ConfigRep1 message handlers


void ConfigRep1::OnOK() 
{
	SYSTEMTIME sysTime;
	GetDlgItem (IDC_DATETIMEPICKER)->SendMessage(MCM_GETCURSEL, 0, (LPARAM) &sysTime);

	m_Date = COleDateTime(sysTime);
	CDialog::OnOK();
}

BOOL ConfigRep1::OnInitDialog() 
{
	CDialog::OnInitDialog();
	SYSTEMTIME sysTime;
	m_Date.GetAsSystemTime (sysTime);
	GetDlgItem (IDC_DATETIMEPICKER)->SendMessage(MCM_SETCURSEL, 0, (LPARAM) &sysTime);
	
	return TRUE;
}
