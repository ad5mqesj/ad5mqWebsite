// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__11F2AAFB_6280_48CF_AB5B_31BF65119AEA__INCLUDED_)
#define AFX_MAINFRM_H__11F2AAFB_6280_48CF_AB5B_31BF65119AEA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMainFrame : public CMDIFrameWnd
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;

	CDC m_dc;
	int m_xext, m_yext;
	int m_lineheight;
	int TotalPages,line;
	BOOL bOnPrint;
	// print functions
	void PrintLine(CDC* pDC, LogRec &Rec);
	void PrintPageHeader(CDC* pDC, int &line);

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnClose();
	afx_msg void OnUserdat();
	afx_msg void OnUpdateUserdat(CCmdUI* pCmdUI);
	afx_msg void OnReport();
	afx_msg void OnUpdateReport(CCmdUI* pCmdUI);
	afx_msg void OnExpBoby();
	afx_msg void OnUpdateExpBoby(CCmdUI* pCmdUI);
	afx_msg void OnExpadif();
	afx_msg void OnUpdateExpadif(CCmdUI* pCmdUI);
	afx_msg void OnQslreq();
	afx_msg void OnUpdateQslreq(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__11F2AAFB_6280_48CF_AB5B_31BF65119AEA__INCLUDED_)
