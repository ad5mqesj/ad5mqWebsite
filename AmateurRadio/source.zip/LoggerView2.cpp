// LoggerView_OLD.cpp : implementation of the CLoggerView_OLD class
//

#include "stdafx.h"
#include "Logger.h"

#include "LoggerDoc.h"
#include "LoggerView_OLD.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CLoggerApp theApp;
/////////////////////////////////////////////////////////////////////////////
// CLoggerView_OLD

IMPLEMENT_DYNCREATE(CLoggerView_OLD, CFormView)

BEGIN_MESSAGE_MAP(CLoggerView_OLD, CFormView)
	//{{AFX_MSG_MAP(CLoggerView_OLD)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_CANCEL, OnCancel)
	ON_BN_CLICKED(IDC_COMMIT, OnCommit)
	//}}AFX_MSG_MAP
	// Standard printing commands
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLoggerView_OLD construction/destruction

CLoggerView_OLD::CLoggerView_OLD()
	: CFormView(CLoggerView_OLD::IDD)
{
	//{{AFX_DATA_INIT(CTestCtrlView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CLoggerView_OLD::~CLoggerView_OLD()
{
}

void CLoggerView_OLD::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLoggerView_OLD)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

void CLoggerView_OLD::OnInitialUpdate()
{  
	CFormView::OnInitialUpdate();
	
//	ResizeParentToFit();
//	GetParent( )->ShowWindow(SW_SHOWMAXIMIZED);	

	// Start the timer for the current time display
//	SetTimer(IDS_TIME, 500, NULL);
	// Set the main run button control to enabled, all else disabled.
//	EnableControls( );
//	UpdateLaunchButtonDisplay( );
//	RefreshAll( );
	theApp.pView = this;
}
BOOL CLoggerView_OLD::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	BOOL bRet = CFormView::PreCreateWindow(cs);
	return bRet;
}

/////////////////////////////////////////////////////////////////////////////
// CLoggerView_OLD diagnostics

#ifdef _DEBUG
void CLoggerView_OLD::AssertValid() const
{
	CFormView::AssertValid();
}

void CLoggerView_OLD::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CLoggerDoc* CLoggerView_OLD::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CLoggerDoc)));
	return (CLoggerDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CLoggerView_OLD message handlers

void CLoggerView_OLD::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	
	// Do not call CFormView::OnPaint() for painting messages
}

void CLoggerView_OLD::OnCancel() 
{
	// TODO: Add your control notification handler code here
	
}

void CLoggerView_OLD::OnCommit() 
{
	// TODO: Add your control notification handler code here
	
}
