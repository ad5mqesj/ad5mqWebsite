//Country.h
//contains definition of class which associates call signs with countries via
//an external file called (by default) country.txt

typedef struct {
	CString	Start;
	CString End;
	CString Country;
	}CNT_STRUCT;

class Country
{
private:
	CNT_STRUCT	*Countries;
	int			numCountries;
	bool		Inited;
public:
	Country(char *File = NULL);
	~Country();

	operator !();
	CString FindCountry (CString &CallSign);
};
