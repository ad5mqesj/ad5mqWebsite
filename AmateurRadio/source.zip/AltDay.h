#if !defined(AFX_ALTDAY_H__80DBF9E6_4067_4765_8E96_83BA11825E6B__INCLUDED_)
#define AFX_ALTDAY_H__80DBF9E6_4067_4765_8E96_83BA11825E6B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AltDay.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// AltDay dialog

class AltDay : public CDialog
{
// Construction
public:
	AltDay(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(AltDay)
	enum { IDD = IDD_NEWDAY };
	COleDateTime	m_Date;
	COleDateTime	m_time;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(AltDay)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(AltDay)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ALTDAY_H__80DBF9E6_4067_4765_8E96_83BA11825E6B__INCLUDED_)
