// Logger.h : main header file for the LOGGER application
//

#if !defined(AFX_LOGGER_H__7218F0AA_F7D3_4B0B_A863_E054787DAAB6__INCLUDED_)
#define AFX_LOGGER_H__7218F0AA_F7D3_4B0B_A863_E054787DAAB6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "CDbase.h"
#include "Country.h"

/////////////////////////////////////////////////////////////////////////////
// CLoggerApp:
// See Logger.cpp for the implementation of this class
//
class CLoggerView; 

class CLoggerApp : public CWinApp
{
public:
	CLoggerApp();
	~CLoggerApp();

	CLoggerView* GetView( ); // returns a pointer to the only possible view
	CLoggerView* pView; // this is initialized from the view by theApp.pView = this

	Dbase		*pDbase;
	CString	DBName;
	Country	*Countries;

	LRecArray *pRecs;
	int		 numRecs;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLoggerApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CLoggerApp)
	afx_msg void OnAppAbout();
	afx_msg void OnFileMruFile1();
	afx_msg void OnFileNew();
	afx_msg void OnUpdateFileNew(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileMruFile1(CCmdUI* pCmdUI);
	afx_msg void OnFileOpen();
	afx_msg void OnUpdateFileOpen(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOGGER_H__7218F0AA_F7D3_4B0B_A863_E054787DAAB6__INCLUDED_)
