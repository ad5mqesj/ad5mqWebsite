//country.cpp
//25 May 2003
//implements calss from country.h
#include "stdafx.h"
#include "Country.h"

Country::Country(char *file)
	{
	CStdioFile	cFile;
	char FName[256];
	CString s;
	int pos, ixCnt, len;

	numCountries = 0;
	Countries = NULL;

	if (file != NULL)
		strcpy (FName,file);
	else
		sprintf (FName, ".\\Countries.txt");

	cFile.Open (FName, CFile::modeRead|CFile::shareExclusive);
	if (cFile.m_hFile == CFile::hFileNull)
		return;

	while (cFile.ReadString (s))
		numCountries++;
	if (!numCountries)
		return;

	cFile.SeekToBegin();
	Countries = new CNT_STRUCT[numCountries];

	for (ixCnt = 0; cFile.ReadString (s) && ixCnt < numCountries; ixCnt++)
		{
		len = s.GetLength();
		pos = s.Find (",");
		Countries[ixCnt].Start = s.Left(pos);
		Countries[ixCnt].Start.TrimLeft();
		Countries[ixCnt].Start.MakeUpper();

		s = s.Right (len - pos-1);
		s.TrimLeft();

		pos = s.Find (",");
		Countries[ixCnt].End = s.Left(pos);
		Countries[ixCnt].End.MakeUpper();

		len = s.GetLength();
		s = s.Right (len - pos-1);
		s.TrimLeft();

		Countries[ixCnt].Country = s;
		}	
	cFile.Close();
	}//Country CTOR

Country::~Country()
	{
	if (Countries)
		delete [] Countries;
	Countries = NULL;
	numCountries = 0;
	}


CString Country::FindCountry (CString &CallSign)
	{
	int pos, len;
	CString leftPart;
	CString returnCnt;


	returnCnt.Empty();
	if (!numCountries || !Countries)
		return returnCnt;
		

//	pos = CallSign.FindOneOf ("0123456789");
//	if (pos>0)	
//		leftPart = CallSign.Left (pos-1);
	if (CallSign.GetLength() > 3)
		leftPart = CallSign.Left(3);
	else if (CallSign.GetLength())
		leftPart = CallSign;
	else
		return returnCnt;

	len = leftPart.GetLength();

	for (int ixCnt = 0; ixCnt < numCountries; ixCnt++)
		{
		if (Countries[ixCnt].Start.Left(len) <= leftPart)
			{
			if (Countries[ixCnt].End.Left(len) >= leftPart)
				{
				returnCnt = Countries[ixCnt].Country;
				break;
				} 
			}//if left part > start
		else if (ixCnt && Countries[ixCnt-1].End.Left(len) <= leftPart)
			{
			if (Countries[ixCnt].End.Left(len) >= leftPart)
				{
				returnCnt = Countries[ixCnt].Country;
				break;
				} 
			}
		}//for each country in list
	return returnCnt;
	}//FindCountry