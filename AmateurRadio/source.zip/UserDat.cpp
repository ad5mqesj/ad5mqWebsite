// UserDat.cpp : implementation file
//

#include "stdafx.h"
#include "Logger.h"
#include "UserDat.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUserDat dialog


CUserDat::CUserDat(CWnd* pParent /*=NULL*/)
	: CDialog(CUserDat::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUserDat)
	m_Call = _T("");
	m_City = _T("");
	m_Country = _T("");
	m_Name = _T("");
	//}}AFX_DATA_INIT
}


void CUserDat::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUserDat)
	DDX_Text(pDX, IDC_CALL, m_Call);
	DDX_Text(pDX, IDC_CITY, m_City);
	DDX_Text(pDX, IDC_COUNTRY, m_Country);
	DDX_Text(pDX, IDC_NAME, m_Name);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUserDat, CDialog)
	//{{AFX_MSG_MAP(CUserDat)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUserDat message handlers
