// LoggerView.h : interface of the CLoggerView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LoggerView_H__CBDD8DEF_3005_11D4_BDF4_0008C7D85476__INCLUDED_)
#define AFX_LoggerView_H__CBDD8DEF_3005_11D4_BDF4_0008C7D85476__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ctrlext.h"


#define NUMCOLS 10
class CLoggerView : public CFormView
{
protected: // create from serialization only
	CLoggerView();
	DECLARE_DYNCREATE(CLoggerView)

public:
	//{{AFX_DATA(CLoggerView)
	enum { IDD = IDD_LOG_VIEW };
	CListCtrlEx	m_DbList;
	//}}AFX_DATA

private:
	static BOOL				fReverseSortOrder;
	static HWND				hListWnd;

	void EnableControls( );
	void ShowSet( );
	void FillGrid();

	void GetColWidths( );
	void PutColWidths( );
	void SetHeaders( );
	int ColWidths[NUMCOLS];
	int	DefModeIx;

	static int CALLBACK	ListViewCompareProc	( LPARAM lParam1,	LPARAM lParam2,	LPARAM lParamSort	);
// Attributes
public:
	void FillGridFromDB();

	CLoggerDoc* GetDocument();
	int numCols, numRows;
	LogRec	CurRec;
	int	r,s,t;
	COleDateTime CurDate;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLoggerView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CLoggerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CLoggerView)
	afx_msg void OnPaint();
	afx_msg void OnKillfocusCallsign();
	afx_msg void OnKillfocusPrevcont();
	afx_msg void OnKillfocusRegion();
	afx_msg void OnSelchangeModelist();
	afx_msg void OnEditchangeModelist();
	afx_msg void OnKillfocusSignalR();
	afx_msg void OnKillfocusSignalS();
	afx_msg void OnKillfocusSignalT();
	afx_msg void OnCommit();
	afx_msg void OnKillfocusComment();
	afx_msg void OnCancel();
	afx_msg void OnChangeCallsign();
	afx_msg void OnColumnclickDblist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClickDblist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDestroy();
	afx_msg void OnKillfocusName();
	afx_msg void OnKillfocusCity();
	afx_msg void OnKeydownDblist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangeBand();
	afx_msg void OnKillfocusFreq();
	afx_msg void OnSelchangeState();
	afx_msg void OnKillfocusNumxmit();
	afx_msg void OnSelchangeClass();
	afx_msg void OnSelchangeSection();
	afx_msg void OnKillfocusBand();
	afx_msg void OnKillfocusClass();
	afx_msg void OnKillfocusSection();
	afx_msg void OnEditchangeState();
	afx_msg void OnChgtime();
	afx_msg void OnEditcur();
	afx_msg void OnQsl();
	afx_msg void OnQslSent();
	afx_msg void OnSelchangeQsltyp();
	afx_msg void OnKillfocusQsltyp();
	afx_msg void OnKillfocusXmitpwr();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LoggerView_H__CBDD8DEF_3005_11D4_BDF4_0008C7D85476__INCLUDED_)
