// LoggerDoc.h : interface of the CLoggerDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LOGGERDOC_H__40D43D0E_6EB0_4AE6_81F1_54F8EADF1D67__INCLUDED_)
#define AFX_LOGGERDOC_H__40D43D0E_6EB0_4AE6_81F1_54F8EADF1D67__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CLoggerDoc : public CDocument
{
protected: // create from serialization only
	CLoggerDoc();
	DECLARE_DYNCREATE(CLoggerDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLoggerDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CLoggerDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CLoggerDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOGGERDOC_H__40D43D0E_6EB0_4AE6_81F1_54F8EADF1D67__INCLUDED_)
