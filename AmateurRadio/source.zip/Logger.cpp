// Logger.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Logger.h"

#include "MainFrm.h"
#include "ChildFrm.h"
#include "LoggerDoc.h"
#include "LoggerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLoggerApp

BEGIN_MESSAGE_MAP(CLoggerApp, CWinApp)
	//{{AFX_MSG_MAP(CLoggerApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_FILE_MRU_FILE1, OnFileMruFile1)
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_UPDATE_COMMAND_UI(ID_FILE_NEW, OnUpdateFileNew)
	ON_UPDATE_COMMAND_UI(ID_FILE_MRU_FILE1, OnUpdateFileMruFile1)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_UPDATE_COMMAND_UI(ID_FILE_OPEN, OnUpdateFileOpen)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLoggerApp construction

CLoggerApp::CLoggerApp()
{
	pDbase = NULL;
	Countries = NULL;
	pRecs = NULL;
	numRecs = 0;
}


CLoggerApp::~CLoggerApp()
{
	if (pDbase)
		{
		delete pDbase;
		pDbase = NULL;
		}
	if (Countries)
		delete Countries;
	Countries = NULL;
	if (pRecs)
		delete pRecs;
	pRecs = NULL;
	numRecs = 0;
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CLoggerApp object

CLoggerApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CLoggerApp initialization

BOOL CLoggerApp::InitInstance()
{
	//used to restore previous window pos from registry
	BOOL bMax;
	int  left, width,top,height;
	char path_buffer[_MAX_PATH];
   char drive[_MAX_DRIVE];
   char dir[_MAX_DIR];
   char fname[_MAX_FNAME];
   char ext[_MAX_EXT];
	char title[255];

	Enable3dControls();			// Call this when using MFC in a shared DLL

	SetRegistryKey(_T("AD5MQ"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	CMultiDocTemplate* pDocTemplate;
	pDocTemplate = new CMultiDocTemplate(
		IDR_LOGGERTYPE,
		RUNTIME_CLASS(CLoggerDoc),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CLoggerView));
	AddDocTemplate(pDocTemplate);

	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;

	//error logging
	CString ErrLg;
	ErrLg = GetMachineProfileString ("","ErrorLogFile","");
	if (!ErrLg.GetLength())
		{
		GetModuleFileName (NULL, path_buffer, _MAX_PATH);
		_splitpath (path_buffer, drive, dir, fname, ext );
		_makepath (path_buffer, drive, dir, "", "");
		CreateDirectory (path_buffer, NULL);
		_makepath (path_buffer, drive, dir, "Error", "Log");
		ErrLg = path_buffer;
		WriteMachineProfileString ("","ErrorLogFile",ErrLg);
		WriteMachineProfileString ("","LogError","Yes");
		}

	DBName = GetMachineProfileString ("Logger","CurDB",".\\db\\Log.mdb");
	pDbase = new Dbase (DBName);
	//get name back in case its first time
	pDbase->GetName (DBName);

	strcpy (title, (LPCSTR)DBName);
	SetWindowText (m_pMainWnd->GetSafeHwnd(), title);
	//stash in registry
	WriteMachineProfileString ("Logger","CurDB",(LPCSTR)DBName);

	Countries = new Country();

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	m_pDocManager->OnFileNew();

	//first set the position and size of the main window
	bMax = GetProfileInt ("Window", "Maximized", 0);
	left = GetProfileInt ("Window", "Left", 0);
	width = GetProfileInt ("Window", "Width", 0);
	top = GetProfileInt ("Window", "Top", 0);
	height = GetProfileInt ("Window", "Height", 0);

	if (width && height)
		{
		CRect rect (left, top, left+width, top+height);
		pMainFrame->MoveWindow (&rect, FALSE);
		}

	// The main window has been initialized, so show and update it.
	pMainFrame->ShowWindow(bMax?SW_SHOWMAXIMIZED:m_nCmdShow);
	pMainFrame->UpdateWindow();

	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CAboutDlg::OnInitDialog() 
{
	CString		strDate;
	CString		strCopyright;
	CDialog::OnInitDialog();
	
	strDate = __DATE__;
	strCopyright.Format ( "Copyright � 2002-%s. AD5MQ.", strDate.Right ( 4 ) );
	SetDlgItemText ( IDC_ABT_COPYRIGHT, strCopyright );
	return TRUE;
	
}

// App command to run the dialog
void CLoggerApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CLoggerApp message handlers
CLoggerView* CLoggerApp::GetView( )
{
	return pView;
}



void CLoggerApp::OnFileMruFile1() 
{
	char title[256];

	pDbase->ChangeDB();

	pDbase->GetName(DBName);

	strcpy (title, (LPCSTR)theApp.DBName);
	SetWindowText (m_pMainWnd->GetSafeHwnd(), title);

	WriteMachineProfileString ("Logger","CurDB",(LPCSTR)DBName);
	if (pView)
		pView->FillGridFromDB();
}

void CLoggerApp::OnFileNew() 
{
	char title[256];

	pDbase->ChangeDB();
	pDbase->GetName(DBName);

	strcpy (title, (LPCSTR)theApp.DBName);
	SetWindowText (m_pMainWnd->GetSafeHwnd(), title);

	WriteMachineProfileString ("Logger","CurDB",(LPCSTR)DBName);
	if (pView)
		pView->FillGridFromDB();
}

void CLoggerApp::OnUpdateFileNew(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable (TRUE);
}

void CLoggerApp::OnUpdateFileMruFile1(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable (TRUE);
}


void CLoggerApp::OnFileOpen() 
{
	char title[256];

	pDbase->ChangeDB();
	pDbase->GetName(DBName);

	strcpy (title, (LPCSTR)theApp.DBName);
	SetWindowText (m_pMainWnd->GetSafeHwnd(), title);

	WriteMachineProfileString ("Logger","CurDB",(LPCSTR)DBName);
	if (pView)
		pView->FillGridFromDB();
}

void CLoggerApp::OnUpdateFileOpen(CCmdUI* pCmdUI) 
{
		pCmdUI->Enable (TRUE);
}

