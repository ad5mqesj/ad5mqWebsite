// LoggerView_OLD.h : interface of the CLoggerView_OLD class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LoggerView_OLD_H__42696E1D_4708_4007_9619_FA679E6D8697__INCLUDED_)
#define AFX_LoggerView_OLD_H__42696E1D_4708_4007_9619_FA679E6D8697__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CLoggerView_OLD : public CFormView
{
protected: // create from serialization only
	CLoggerView_OLD();
	DECLARE_DYNCREATE(CLoggerView_OLD)

// Attributes
public:
	//{{AFX_DATA(CLoggerView_OLD)
	enum { IDD = IDD_LOG_VIEW };
	//}}AFX_DATA
	CLoggerDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLoggerView_OLD)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CLoggerView_OLD();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CLoggerView_OLD)
	afx_msg void OnPaint();
	afx_msg void OnCancel();
	afx_msg void OnCommit();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in LoggerView_OLD.cpp
inline CLoggerDoc* CLoggerView_OLD::GetDocument()
   { return (CLoggerDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LoggerView_OLD_H__42696E1D_4708_4007_9619_FA679E6D8697__INCLUDED_)
