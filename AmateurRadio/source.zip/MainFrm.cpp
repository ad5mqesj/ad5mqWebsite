// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include <fstream.h>
#include <stdio.h>
#include "Logger.h"

#include "MainFrm.h"
#include "UserDat.h"
#include "jdate.h"
#include "onfigRep1.h"
#include "ChgDbDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define MAXLINES		80
// placement of columns (in percent of total width)
#define STARTCOL		0.01
#define DATECOL		0.02
#define CALLSCOL		0.11
#define COUNTRYCOL	0.16
#define NAMECOL		0.22
#define CITYCOL		0.29
#define FRQCOL			0.40
#define COMMNTCOL		0.46
#define ENDCOL			0.95

extern CLoggerApp theApp;
/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	ON_COMMAND(ID_USERDAT, OnUserdat)
	ON_UPDATE_COMMAND_UI(ID_USERDAT, OnUpdateUserdat)
	ON_COMMAND(ID_REPORT, OnReport)
	ON_UPDATE_COMMAND_UI(ID_REPORT, OnUpdateReport)
	ON_COMMAND(ID_EXP_BOBY, OnExpBoby)
	ON_UPDATE_COMMAND_UI(ID_EXP_BOBY, OnUpdateExpBoby)
	ON_COMMAND(ID_EXPADIF, OnExpadif)
	ON_UPDATE_COMMAND_UI(ID_EXPADIF, OnUpdateExpadif)
	ON_COMMAND(ID_QSLREQ, OnQslreq)
	ON_UPDATE_COMMAND_UI(ID_QSLREQ, OnUpdateQslreq)
	//}}AFX_MSG_MAP
	// Global help commands
	ON_COMMAND(ID_HELP_FINDER, CMDIFrameWnd::OnHelpFinder)
	ON_COMMAND(ID_HELP, CMDIFrameWnd::OnHelp)
	ON_COMMAND(ID_CONTEXT_HELP, CMDIFrameWnd::OnContextHelp)
	ON_COMMAND(ID_DEFAULT_HELP, CMDIFrameWnd::OnHelpFinder)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMDIFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


void CMainFrame::OnClose() 
{
 	WINDOWPLACEMENT wp;

	//save window placement & size before exit
	GetWindowPlacement (&wp);
	theApp.WriteProfileInt ("Window","Maximized",wp.showCmd != SW_SHOWMAXIMIZED ? 0:1);
	theApp.WriteProfileInt ("Window","Left",wp.rcNormalPosition.left);
	theApp.WriteProfileInt ("Window","Width",wp.rcNormalPosition.right - wp.rcNormalPosition.left);
	theApp.WriteProfileInt ("Window","Top",wp.rcNormalPosition.top);
	theApp.WriteProfileInt ("Window","Height",wp.rcNormalPosition.bottom - wp.rcNormalPosition.top);
	CMDIFrameWnd::OnClose();
}

void CMainFrame::OnUserdat() 
{
	CUserDat cDlg;
	cDlg.m_Call = theApp.GetProfileString ("UserData","CallSign","");
	cDlg.m_City = theApp.GetProfileString ("UserData","City","");
	cDlg.m_Country = theApp.GetProfileString ("UserData","Country","");
	cDlg.m_Name = theApp.GetProfileString ("UserData","Name","");
	if (cDlg.DoModal() == IDOK)
		{
		theApp.WriteProfileString ("UserData","CallSign",cDlg.m_Call);
		theApp.WriteProfileString ("UserData","City",cDlg.m_City);
		theApp.WriteProfileString ("UserData","Country",cDlg.m_Country);
		theApp.WriteProfileString ("UserData","Name",cDlg.m_Name);
		}
}

void CMainFrame::OnUpdateUserdat(CCmdUI* pCmdUI) 
{
pCmdUI->Enable();
}

void CMainFrame::OnReport() 
{
	ConfigRep1 cDlg;
	CFont Font, *pOldFont;
	LOGFONT LogFont;

	LRecArray *pRecs;
	COleDateTime dt;
	LogRec Rec;
	int i;

	dt = COleDateTime::GetCurrentTime();
	COleDateTimeSpan span;
	span.SetDateTimeSpan (30,0,0,0);
	dt = dt - span;
	cDlg.m_Date = dt;
	if (cDlg.DoModal() != IDOK)
		dt.SetStatus ((COleDateTime::DateTimeStatus)1);

	pRecs = theApp.pDbase->GetForeignRecs (dt);
	if (!pRecs)
		return;
	line = 0;

	CPrintDialog PrintDlg(FALSE);		
	DOCINFO DocInfo = {16, "Contact Report\0", NULL };	
			
	AfxGetApp()->GetPrinterDeviceDefaults(&PrintDlg.m_pd);
	DEVMODE* pDevMode = (LPDEVMODE)GlobalLock(PrintDlg.m_pd.hDevMode);
	if (pDevMode)
		{
		pDevMode->dmOrientation = DMORIENT_LANDSCAPE;
		GlobalUnlock(PrintDlg.m_pd.hDevMode);
		}
	
	PrintDlg.m_pd.Flags |= PD_HIDEPRINTTOFILE | PD_NOPAGENUMS | PD_NOSELECTION;
	if (PrintDlg.DoModal() != IDOK) 
		return;

	m_dc.Attach(PrintDlg.GetPrinterDC());
	m_dc.StartDoc(&DocInfo);
	m_dc.StartPage();
	
	m_dc.SetMapMode(MM_TEXT);
	// retrieve device caps
	m_xext = m_dc.GetDeviceCaps(HORZRES);
	m_yext = m_dc.GetDeviceCaps(VERTRES);
	// create a font		
	ZeroMemory(&LogFont, sizeof(LOGFONT));
	strcpy(LogFont.lfFaceName, "MS Sans Serif");		

	LogFont.lfHeight = m_yext / MAXLINES;
	LogFont.lfWeight = FW_NORMAL;		
	m_lineheight = LogFont.lfHeight;

	Font.CreateFontIndirect(&LogFont);
	pOldFont = m_dc.SelectObject(&Font);
	
	bOnPrint = TRUE;

	for (i = 0;i <= pRecs->GetUpperBound() ;i++)
		{
		Rec = pRecs->GetAt (i);
		PrintLine (&m_dc, Rec);
		}
	m_dc.EndPage();
	m_dc.EndDoc();
	m_dc.SelectObject(pOldFont);
	m_dc.DeleteDC();
	delete pRecs;

}

void CMainFrame::OnUpdateReport(CCmdUI* pCmdUI) 
{
pCmdUI->Enable();
}

void CMainFrame::PrintLine(CDC* pDC, LogRec &Rec)
	{
	CRect cliprect;
	CString sString;
	CString sItem;
	CString perr;
	TEXTMETRIC Metrics;
	CString s;
	COleDateTime dt;

	CWaitCursor WaitCursor;

	try
		{
		pDC->GetTextMetrics(&Metrics);
		// start new page if necessary
		if (line == MAXLINES)
			{
			pDC->EndPage();
			pDC->StartPage();
			line = 0;
			}
		// print header at start of each page
		if (line == 0)
			PrintPageHeader(pDC, line);			
						
		// date
		cliprect.left = (int)(DATECOL * m_xext);
		cliprect.top = m_lineheight * line;
		cliprect.bottom = cliprect.top + Metrics.tmHeight;
		cliprect.right = (int)(CALLSCOL * m_xext) - (Metrics.tmAveCharWidth * 2);
		dt = TimeStampToCOleDateTime (JDateToTimeStamp (Rec.UTC_Time));
		s = dt.Format ("%Y %b %d  %H:%M:%S");

		if (bOnPrint) pDC->DrawText(s, &cliprect, DT_LEFT | DT_TOP);
		// call sign
		cliprect.left = (int)(CALLSCOL * m_xext);
		cliprect.top = m_lineheight * line;
		cliprect.bottom = cliprect.top + Metrics.tmHeight;
		cliprect.right = (int)(COUNTRYCOL * m_xext) - (Metrics.tmAveCharWidth * 2);
		if (bOnPrint) pDC->DrawText(Rec.CallSign, &cliprect, DT_LEFT | DT_TOP);
		// country
		cliprect.left = (int)(COUNTRYCOL * m_xext);
		cliprect.top = m_lineheight * line;
		cliprect.bottom = cliprect.top + Metrics.tmHeight;
		cliprect.right = (int)(NAMECOL * m_xext) - (Metrics.tmAveCharWidth * 2);
		if (bOnPrint) pDC->DrawText(Rec.Country, &cliprect, DT_LEFT | DT_TOP);
		// name
		cliprect.left = (int)(NAMECOL * m_xext);
		cliprect.top = m_lineheight * line;
		cliprect.bottom = cliprect.top + Metrics.tmHeight;
		cliprect.right = (int)(CITYCOL * m_xext) - (Metrics.tmAveCharWidth * 2);
		if (bOnPrint) pDC->DrawText(Rec.Name, &cliprect, DT_LEFT | DT_TOP);

		// city
		cliprect.left = (int)(CITYCOL * m_xext);
		cliprect.top = m_lineheight * line;
		cliprect.bottom = cliprect.top + Metrics.tmHeight;
		cliprect.right = (int)(FRQCOL * m_xext) - (Metrics.tmAveCharWidth * 2);
		if (bOnPrint) pDC->DrawText(Rec.City, &cliprect, DT_LEFT | DT_TOP);
		//Freq
		cliprect.left = (int)(FRQCOL * m_xext);
		cliprect.top = m_lineheight * line;
		cliprect.bottom = cliprect.top + Metrics.tmHeight;
		cliprect.right = (int)(COMMNTCOL * m_xext);
		s.Format ("%5.2f MHz",Rec.Freq);
		if (bOnPrint) pDC->DrawText(s, &cliprect, DT_LEFT | DT_TOP);
		// notes
		cliprect.left = (int)(COMMNTCOL * m_xext);
		cliprect.top = m_lineheight * line++;
		cliprect.bottom = cliprect.top + Metrics.tmHeight;
		cliprect.right = (int)(ENDCOL * m_xext);
		if (bOnPrint) pDC->DrawText(Rec.Comment, &cliprect, DT_LEFT | DT_TOP);
		} // try
	catch (CString err)
		{
		MessageBox(err, "Contact Report Print", MB_ICONERROR);
		return;
		}
	catch (AccessViolation)
		{
		MessageBox("Unknown Access Violation", "Contact Report Print", MB_ICONERROR);
		return;
		}
	}
	
void CMainFrame::PrintPageHeader(CDC* pDC, int &line)
	{
	CString sText, sTime;
	CString name, call;

	call = theApp.GetProfileString ("UserData","CallSign","");
	name = theApp.GetProfileString ("UserData","Name","");

	CTime time = CTime::GetCurrentTime();
	sTime = time.Format("%x") + "  " + time.Format("%X");
	sText.Format("Routine Foreign Contact via Amatuer Radio Report for %s (%s)",name, call);

	if (bOnPrint) pDC->TextOut((int)(STARTCOL * m_xext), m_lineheight * line, sText);
	line++;
	sTime = time.Format("%x");
	sText.Format ("Report issued on : %s, No Unusual questions or content was present in these contacts.",sTime);
	if (bOnPrint) pDC->TextOut((int)(STARTCOL * m_xext), m_lineheight * line, sText);
	sTime = time.Format("%x") + "  " + time.Format("%X");

	line += 2;	
	
	sText = "Date";
	if (bOnPrint) pDC->TextOut((int)(DATECOL * m_xext), m_lineheight * line, sText);
	sText = "Station";
	if (bOnPrint) pDC->TextOut((int)(CALLSCOL * m_xext), m_lineheight * line, sText);
	sText = "Country";
	if (bOnPrint) pDC->TextOut((int)(COUNTRYCOL * m_xext), m_lineheight * line, sText);
	sText = "Operator";
	if (bOnPrint) pDC->TextOut((int)(NAMECOL * m_xext), m_lineheight * line, sText);
	sText = "Location";
	if (bOnPrint) pDC->TextOut((int)(CITYCOL * m_xext), m_lineheight * line, sText);
	sText = "Frequency";
	if (bOnPrint) pDC->TextOut((int)(FRQCOL * m_xext), m_lineheight * line, sText);
	sText = "notes";
	if (bOnPrint) pDC->TextOut((int)(COMMNTCOL * m_xext), m_lineheight * line, sText);

	line++;
	if (bOnPrint) pDC->MoveTo((int)(STARTCOL * m_xext), m_lineheight * line);
	if (bOnPrint) pDC->LineTo((int)(ENDCOL * m_xext), m_lineheight * line);
	line++;
	}


void CMainFrame::OnExpBoby() 
	{
	char			szDirectory	[ _MAX_PATH ];
	CString			strDirectory;
	CString			strSelected;
	static char		szFilter[]			=	"Text File (*.txt)|"	"*.txt|" "|";
	ofstream			ofs;
	ConfigRep1		cDlg;
	CString			s;
	char				szComment[512];
	
	CChgDbDlg SelectDlg (TRUE, "txt", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter, AfxGetApp()->m_pMainWnd);
	SelectDlg.m_ofn.lpstrTitle = "Create a New export file";
	memset ( szDirectory, '\0', sizeof szDirectory );
	strDirectory = AfxGetApp()->GetProfileString ( "Change", "exportDirectory", "c:\\logger\\" );
	strcpy ( szDirectory,	strDirectory	);

	SelectDlg.m_ofn.lpstrInitialDir	=	szDirectory;

	if ( SelectDlg.DoModal() == IDCANCEL )
		return;

	strSelected = SelectDlg.GetPathName();
	ofs.open (strSelected, ios::out);
	//create header
	CString sText, sTime;
	CString name, call;

	call = theApp.GetProfileString ("UserData","CallSign","");
	name = theApp.GetProfileString ("UserData","Name","");

	CTime time = CTime::GetCurrentTime();
	sTime = time.Format("%x") + "  " + time.Format("%X");
	sText.Format("Foreign Contact Report for %s (%s)\n",name, call);

	ofs << sText << endl;
	CString strD;
	COleDateTime dt;
	dt = COleDateTime::GetCurrentTime();
	strD = dt.Format ("%d %B, %Y");
	sText.Format ("Report issued on : %s.\nNo Unusual content or questions were present in these contacts\n",strD);
	ofs << sText << endl;
	sText = "Full transcripts available on request\n";
	ofs << sText << endl;

	sText = "Date\t\t";
	sText += "Time\t\t";
	sText += "Station ";
	sText +="Country\t\t";
	sText += "Operator\t";
	sText += "Location\t\t";
	sText += "Frequency\t";
	sText += "notes";
	ofs << sText << endl;

	LRecArray *pRecs;
	LogRec Rec;
	int i;

	dt = COleDateTime::GetCurrentTime();
	COleDateTimeSpan span;
	span.SetDateTimeSpan (30,0,0,0);
	dt = dt - span;
	cDlg.m_Date = dt;
	if (cDlg.DoModal() != IDOK)
		dt.SetStatus ((COleDateTime::DateTimeStatus)1);
	dt = cDlg.m_Date;

	SYSTEMTIME sys;
	dt.GetAsSystemTime (sys);

	pRecs = theApp.pDbase->GetForeignRecs (dt);
	if (!pRecs)
		return;
	for (i = 0;i <= pRecs->GetUpperBound() ;i++)
		{
		Rec = pRecs->GetAt (i);

		dt = TimeStampToCOleDateTime (JDateToTimeStamp (Rec.UTC_Time));
		sText = dt.Format ("%Y %b %d \t%H:%M:%S\t");
		sText += Rec.CallSign;
		sText+="\t";
		sText += Rec.Country;
		sText+="\t";
		if (Rec.Country.GetLength() < 8)
			sText += "\t";
		sText += Rec.Name.Left (15);;
		sText+="\t";
		if (Rec.Name.GetLength() < 8)
			sText += "\t";
		sText += Rec.City.Left(15);
		sText+="\t";
		if (Rec.City.GetLength() < 8)
			sText += "\t\t";
		else
			sText += "\t";
		s.Format ("%5.3f MHz", Rec.Freq);
		sText += s; 
		sText+="\t";
		//strip out carriage returns
		strcpy (szComment, Rec.Comment);
		for (int ix = 0; ix < strlen (szComment); ix++)
			{
			if (szComment[ix] == '\r' || szComment[ix] == '\n')
				szComment[ix] = ' ';
			}
		sText += szComment;
		ofs << sText << endl;
		}
	delete pRecs;


	ofs.close();
	}

void CMainFrame::OnUpdateExpBoby(CCmdUI* pCmdUI) 
{
pCmdUI->Enable();
}

void CMainFrame::OnExpadif() 
{
	char			szDirectory	[ _MAX_PATH ];
	CString			strDirectory;
	CString			strSelected;
	static char		szFilter[]			=	"Text File (*.txt)|"	"*.txt|" "|";
	ofstream			ofs;
	ConfigRep1		cDlg;
	CString			s;

	
	CChgDbDlg SelectDlg (TRUE, "txt", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter, AfxGetApp()->m_pMainWnd);
	SelectDlg.m_ofn.lpstrTitle = "Create a New export file";
	memset ( szDirectory, '\0', sizeof szDirectory );
	strDirectory = AfxGetApp()->GetProfileString ( "Change", "exportDirectory", "c:\\logger\\" );
	strcpy ( szDirectory,	strDirectory	);

	SelectDlg.m_ofn.lpstrInitialDir	=	szDirectory;

	if ( SelectDlg.DoModal() == IDCANCEL )
		return;

	strSelected = SelectDlg.GetPathName();
	ofs.open (strSelected, ios::out);
	//create header
	CString sText, sTime;
	CString name, call;

	call = theApp.GetProfileString ("UserData","CallSign","");
	name = theApp.GetProfileString ("UserData","Name","");

	CTime time = CTime::GetCurrentTime();
	sTime = time.Format("%x") + "  " + time.Format("%X");
	sText.Format("<adif_ver:4>1.00\n");
	ofs << sText <<endl;

	LRecArray *pRecs;
	COleDateTime dt;
	LogRec Rec;
	int i;
	int len;

	dt = COleDateTime::GetCurrentTime();
	COleDateTimeSpan span;
	span.SetDateTimeSpan (30,0,0,0);
	dt = dt - span;
	cDlg.m_Date = dt;
	if (cDlg.DoModal() != IDOK)
		dt.SetStatus ((COleDateTime::DateTimeStatus)1);
	dt = cDlg.m_Date;

	SYSTEMTIME sys;
	dt.GetAsSystemTime (sys);

	pRecs = theApp.pDbase->GetRecsNewerThan (dt);
	if (!pRecs)
		{
		ofs.close();
		return;
		}
	for (i = 0;i <= pRecs->GetUpperBound() ;i++)
		{
		Rec = pRecs->GetAt (i);
		//first get the call sign and its length
		len = Rec.CallSign.GetLength();
		sText.Format ("<CALL:%d>%s",len,Rec.CallSign);
		ofs << sText;
		//now band
		len = Rec.Band.GetLength();
		sText.Format ("<BAND:%d>%s",len,Rec.Band);
		ofs << sText;
		//mode
		len = Rec.Mode.GetLength();
		sText.Format ("<MODE:%d>%s",len,Rec.Mode);
		ofs << sText;
		//date
		dt = TimeStampToCOleDateTime (JDateToTimeStamp (Rec.UTC_Time));
		s = dt.Format ("%Y%m%d");
		len = s.GetLength();
		sText.Format ("<QSO_DATE:%d:d>%s",len,s);
		ofs << sText;
		//time
		s = dt.Format ("%H%M");
		len = s.GetLength();
		sText.Format ("<TIME_OFF:%d>%s",len,s);
		ofs << sText;
		//operator (me)
		len = call.GetLength();
		sText.Format ("<OPERATOR:%d>%s",len,call);
		ofs << sText;

		//if available name
		len = Rec.Name.GetLength();
		if (len)
			{
			sText.Format ("<NAME:%d>%s",len,Rec.Name);
			ofs << sText;
			}
		//state
		len = Rec.State.GetLength();
		if (len)
			{
			sText.Format ("<STATE:%d>%s",len,Rec.State);
			ofs << sText;
			}
		//QTH
		if (Rec.Country.Find("USA") != -1)
			{
			len = Rec.City.GetLength();
			if (len)
				{
				sText.Format ("<QTH:%d>%s",len,Rec.City);
				ofs << sText;
				}
			}
		else
			{
			len = Rec.City.GetLength()+Rec.Country.GetLength();
			if (len)
				{
				s.Empty();
				if (Rec.City.GetLength())
					{
					len += 1;
					s = Rec.City;
					s += ",";
					}
				s += Rec.Country;
				sText.Format ("<QTH:%d>%s",len,s);
				ofs << sText;
				}
			}
		//notes
		len = Rec.Comment.GetLength();
		if (len)
			{
			sText.Format ("<NOTES:%d>%s",len,Rec.Comment);
			ofs << sText;
			}
		ofs << "<EOR>\n";
		}
	delete pRecs;


	ofs.close();
}

void CMainFrame::OnUpdateExpadif(CCmdUI* pCmdUI) 
{
pCmdUI->Enable();
}		

void CMainFrame::OnQslreq() 
	{
	char				szDirectory	[ _MAX_PATH ];
	CString			strDirectory;
	CString			strSelected;
	static char		szFilter[]			=	"Text File (*.txt)|"	"*.txt|" "|";
	ofstream			ofs;
	ConfigRep1		cDlg;
	CString			s;
	LRecArray		*pRecs;
	COleDateTime	dt;
	LogRec			Rec;
	int				i;
	int				len;

	CChgDbDlg SelectDlg (TRUE, "txt", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter, AfxGetApp()->m_pMainWnd);
	SelectDlg.m_ofn.lpstrTitle = "Create a New export file";
	memset ( szDirectory, '\0', sizeof szDirectory );
	strDirectory = AfxGetApp()->GetProfileString ( "Change", "exportDirectory", "c:\\logger\\" );
	strcpy ( szDirectory,	strDirectory	);

	SelectDlg.m_ofn.lpstrInitialDir	=	szDirectory;

	if ( SelectDlg.DoModal() == IDCANCEL )
		return;

	strSelected = SelectDlg.GetPathName();
	ofs.open (strSelected, ios::out);

	dt = COleDateTime::GetCurrentTime();
	COleDateTimeSpan span;
	span.SetDateTimeSpan (30,0,0,0);
	dt = dt - span;
	cDlg.m_Date = dt;
	if (cDlg.DoModal() != IDOK)
		dt.SetStatus ((COleDateTime::DateTimeStatus)1);
	dt = cDlg.m_Date;

	SYSTEMTIME sys;
	dt.GetAsSystemTime (sys);
	pRecs = theApp.pDbase->GetQSLReqs (dt);
	if (!pRecs)
		{
		ofs.close();
		return;
		}
	for (i = 0;i <= pRecs->GetUpperBound() ;i++)
		{
		Rec = pRecs->GetAt (i);
		s.Format ("%s, %s\n",Rec.CallSign,Rec.Comment);
		ofs << s;
		}//for each rec found

	delete pRecs;
	ofs.close();
	}//OnQslreq

void CMainFrame::OnUpdateQslreq(CCmdUI* pCmdUI) 
{
pCmdUI->Enable();
}
