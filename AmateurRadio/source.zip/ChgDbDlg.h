#if !defined(AFX_MYFILEDIALOG_H__BA18CE37_10B2_11D4_B114_00104B00E8F5__INCLUDED_)
#define AFX_MYFILEDIALOG_H__BA18CE37_10B2_11D4_B114_00104B00E8F5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyFileDialog.h : header file
//

#ifndef __TREECTLX_H__
#include "CtrlExt.h"
#endif	//	__TREECTLX_H__

/////////////////////////////////////////////////////////////////////////////
// CChgDbDlg dialog

class CChgDbDlg : public CFileDialog
{
	DECLARE_DYNAMIC(CChgDbDlg)

public:

	CChgDbDlg (	BOOL		bOpenFileDialog	= TRUE, // TRUE for FileOpen, FALSE for FileSaveAs
					LPCTSTR	lpszDefExt			= "mdb",
					LPCTSTR	lpszFileName		= "DAAAC",
					DWORD		dwFlags				= OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
					LPCTSTR	lpszFilter			= "DAAAC 4.0 Database (*.mdb)|*.mdb||",
					CWnd *	pParentWnd			= AfxGetApp()->m_pActiveWnd );

	~CChgDbDlg();

	// Dialog Data
	//{{AFX_DATA(CChgDbDlg)
	enum { IDD = IDD_CHG_DB_DLG };
	CListCtrlEx	m_RecentDatabasesList;
	CString		m_TextString;
	//}}AFX_DATA

	CRecentFileList	* m_pRecentFileList;

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFireDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CChgDbDlg)
	afx_msg void OnClickRecentDbList(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDblclkRecentDbList(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

virtual void OnInitDone();

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYFILEDIALOG_H__BA18CE37_10B2_11D4_B114_00104B00E8F5__INCLUDED_)
