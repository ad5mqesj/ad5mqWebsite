//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Logger.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_LOG_VIEW                    101
#define IDR_MAINFRAME                   128
#define IDR_LOGGERTYPE                  129
#define IDD_USSERDAT                    133
#define IDD_REPORT1                     134
#define IDC_REGION                      1001
#define IDC_UTC                         1002
#define IDC_CALLSIGN                    1003
#define IDC_PREVCONT                    1004
#define IDC_MODELIST                    1005
#define IDC_SIGNAL_R                    1006
#define IDC_SIGNAL_S                    1007
#define IDC_SIGNAL_T                    1008
#define IDC_COMMENT                     1009
#define IDC_COMMIT                      1010
#define IDC_CANCEL                      1011
#define IDC_STATE                       1012
#define IDC_NAME                        1013
#define IDC_ABT_COPYRIGHT               1013
#define IDC_CITY                        1014
#define IDC_DBLIST                      1015
#define IDC_CALL                        1016
#define IDC_FREQ                        1016
#define IDC_BAND                        1017
#define IDC_NUMXMIT                     1018
#define IDC_COUNTRY                     1019
#define IDC_CLASS                       1019
#define IDC_SECTION                     1020
#define IDC_STATESWORKED                1021
#define IDC_DATETIMEPICKER              1022
#define IDC_EDITCUR                     1022
#define IDC_DATETIMEPICKER2             1023
#define IDC_CHGTIME                     1023
#define IDC_TOTALCONT                   1024
#define IDC_QSL                         1025
#define IDC_QSL_SENT                    1026
#define IDC_QSLTYP                      1027
#define IDC_XMITPWR                     1028
#define IDD_CHG_DB_DLG                  23015
#define IDD_NEWDAY                      23016
#define ID_USERDAT                      32771
#define ID_REPORT                       32772
#define ID_EXP_BOBY                     32773
#define ID_EXPADIF                      32774
#define ID_QSLREQ                       32775
#define IDC_RECENT_DB_LIST              55353
#define IDC_TEXT_STRING                 55354

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
