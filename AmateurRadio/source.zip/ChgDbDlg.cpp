// MyFileDialog.cpp : implementation file
//

#include "stdafx.h"							//	Standard MFC Classes Definitions, Prototypes and Defines

#include <AfxAdv.h>							//	CRecentFileList
#include <Dlgs.h>								//	Common Dialog Resource Definitions
#include "resource.h"						//	Local Resource Definitions

#include "ChgDbDlg.h"						//	The CChgDbDlg Derived Class Definitions, Prototypes and Defines

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChgDbDlg

IMPLEMENT_DYNAMIC (CChgDbDlg, CFileDialog)

CChgDbDlg::CChgDbDlg(BOOL bOpenFileDialog, LPCTSTR lpszDefExt, LPCTSTR lpszFileName,
		DWORD dwFlags, LPCTSTR lpszFilter, CWnd* pParentWnd) :
		CFileDialog(bOpenFileDialog, lpszDefExt, lpszFileName, dwFlags, lpszFilter, pParentWnd)

	{
	//{{AFX_DATA_INIT(CChgDbDlg)
	m_TextString = _T ( "The Most Recently Accessed Databases" );
	//}}AFX_DATA_INIT

	//	#include <Fileopen.dlg> for Resource Block

	m_ofn.hInstance		=	AfxFindResourceHandle ( ( LPCTSTR ) IDD_CHG_DB_DLG, RT_DIALOG );
	m_ofn.lpstrTitle		=	"Change the Daaac 4.0 Database";
	m_ofn.Flags				|=	OFN_ENABLETEMPLATE;
	m_ofn.lpTemplateName	=	MAKEINTRESOURCE ( IDD_CHG_DB_DLG );

	m_pRecentFileList		=	new CRecentFileList ( 0, "Recent File List", "File%d", 10, MAX_PATH + 1 );

	}	//	CChgDbDlg()

CChgDbDlg::~CChgDbDlg()

	{

	//	Close the Recent File List

	if ( m_pRecentFileList )
		{

		//	Get the Path Name of the Selected Database ( Set in OnClickRecentDbList() )

		CString strSelected = GetPathName();

		//	Add the File to the Recent File List

		m_pRecentFileList->Add ( strSelected );

		//	Add the File to the Application's Recent File List

		AfxGetApp()->AddToRecentFileList ( strSelected );

		//	Write the File List Back to the Registry

		m_pRecentFileList->WriteList();

		//	Delete the Recent File List

		delete m_pRecentFileList;
		m_pRecentFileList = NULL;
		}

	}	//	CChgDbDlg::~CChgDbDlg()

BEGIN_MESSAGE_MAP(CChgDbDlg, CFileDialog)
	//{{AFX_MSG_MAP(CChgDbDlg)
	ON_NOTIFY(NM_CLICK, IDC_RECENT_DB_LIST, OnClickRecentDbList)
	ON_NOTIFY(NM_DBLCLK, IDC_RECENT_DB_LIST, OnDblclkRecentDbList)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CChgDbDlg::DoDataExchange ( CDataExchange * pDX )

	{
	CDialog::DoDataExchange ( pDX );

	//{{AFX_DATA_MAP(CChgDbDlg)
	DDX_Control	( pDX, IDC_RECENT_DB_LIST,	m_RecentDatabasesList	);
	DDX_Text		( pDX, IDC_TEXT_STRING,		m_TextString				);
	//}}AFX_DATA_MAP

	}	//	void CChgDbDlg::DoDataExchange ( CDataExchange * pDX )

void CChgDbDlg::OnInitDone()

	{

	//	#include <fileopen.dlg>

//	GetParent()->SetDlgItemText ( stc3, "Test This!" );

	m_RecentDatabasesList.AddColumn ( "Database",	0 );	m_RecentDatabasesList.SetColumnWidth ( 0, 100 );
	m_RecentDatabasesList.AddColumn ( "Modified",	1 );	m_RecentDatabasesList.SetColumnWidth ( 1, 150 );
	m_RecentDatabasesList.AddColumn ( "Path",			2 );	m_RecentDatabasesList.SetColumnWidth ( 2, 250 );

	if ( ! m_pRecentFileList ) return;

	m_pRecentFileList->ReadList();

	int i, j, nFiles = m_pRecentFileList->GetSize();

	for ( i = j = 0; i < nFiles; i++ )
		{

		WIN32_FILE_ATTRIBUTE_DATA	Win32FileAttributeData	= { 0LU };

		//	Hangs if Network File and Host is Offline

		if ( ! GetFileAttributesEx ( ( * m_pRecentFileList ) [ i ], GetFileExInfoStandard, &Win32FileAttributeData ) ) continue;

		COleDateTime	odtLastModified	( Win32FileAttributeData.ftLastWriteTime );
		CString			strLastModified	= odtLastModified.Format();

		CString			strPathName			= ( * m_pRecentFileList ) [ i ];
		CString			strDirectory		= strPathName.Left	( strPathName.ReverseFind ( '\\' )								);
		CString			strFileName			= strPathName.Right	( strPathName.GetLength() - strDirectory.GetLength() - 1	);

		m_RecentDatabasesList.AddItem ( j, 0, ( LPCSTR ) strFileName		);
		m_RecentDatabasesList.AddItem ( j, 1, ( LPCSTR ) strLastModified	);
		m_RecentDatabasesList.AddItem ( j, 2, ( LPCSTR ) strDirectory		);

		m_RecentDatabasesList.SetItemData ( j, i );

		j++;
		}

	CFileDialog::OnInitDone();

	}	//	OnInitDone()

void CChgDbDlg::OnClickRecentDbList ( NMHDR * pNMHDR, LRESULT * pResult )

	{

	//	Properly cast the Notification Message Header

	NM_LISTVIEW	* pListViewStruct	= ( NM_LISTVIEW * ) pNMHDR;

	//	Assure that the Item Number is Within Range

	if ( pListViewStruct->iItem < 0 || pListViewStruct->iSubItem >= m_pRecentFileList->GetSize() ) return;

	//	Assure that the Database Name was Clicked

	if ( pListViewStruct->iSubItem != 0 ) return;

	//	Get the Item Data and Assure that it is Within Range

	DWORD dwIndex = m_RecentDatabasesList.GetItemData ( pListViewStruct->iItem );

	if ( ( int ) dwIndex >= m_pRecentFileList->GetSize() ) return;

	//	Get the Path, Directory and File Information

	CString		strPathName			= ( * m_pRecentFileList ) [ dwIndex ];
	CString		strDirectory		= strPathName.Left	( strPathName.ReverseFind ( '\\' )								);
	CString		strFileName			= strPathName.Right	( strPathName.GetLength() - strDirectory.GetLength() - 1	);

	//	Select the Directory

	GetParent()->SetDlgItemText ( edt1, strDirectory );

	//	Force a Process of the Directory to Change to the Selected Directory

	GetParent()->SendMessage ( WM_COMMAND, IDOK );

	//	Select the File Name Within the Directory

	GetParent()->SetDlgItemText ( edt1, strPathName );

	//	Return Success

	* pResult = 0;

	}	//	void CChgDbDlg::OnClickRecentDbList ( NMHDR * pNMHDR, LRESULT * pResult )

void CChgDbDlg::OnDblclkRecentDbList ( NMHDR * pNMHDR, LRESULT * pResult )

	{

	//	Assure that We are Processing a Mouse Button Double Click From the Recent Database List

	if ( pNMHDR->code != NM_DBLCLK || pNMHDR->idFrom != IDC_RECENT_DB_LIST ) return;

	//	Inform the Dialog Box that We are Done

	GetParent()->PostMessage ( WM_COMMAND, IDOK );

	//	Tell MFC that We Processed This Notify Message

	* pResult = 0;

	}	//	void CChgDbDlg::OnDblclkRecentDbList ( NMHDR * pNMHDR, LRESULT * pResult )
