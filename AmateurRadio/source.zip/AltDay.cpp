// AltDay.cpp : implementation file
//

#include "stdafx.h"
#include "Logger.h"
#include "AltDay.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// AltDay dialog


AltDay::AltDay(CWnd* pParent /*=NULL*/)
	: CDialog(AltDay::IDD, pParent)
{
	//{{AFX_DATA_INIT(AltDay)
	m_Date = COleDateTime::GetCurrentTime();
	m_time = COleDateTime::GetCurrentTime();
	//}}AFX_DATA_INIT
}


void AltDay::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(AltDay)
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER, m_Date);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER2, m_time);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(AltDay, CDialog)
	//{{AFX_MSG_MAP(AltDay)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// AltDay message handlers
