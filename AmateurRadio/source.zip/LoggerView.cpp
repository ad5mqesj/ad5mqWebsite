// LoggerView.cpp : implementation of the CLoggerView class
//

#include "stdafx.h"
#include "Logger.h"

#include "LoggerDoc.h"
#include "LoggerView.h"
#include "JDate.h"
#include "AltDay.h"

#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CLoggerApp theApp;

static char Titles [NUMCOLS][25] = {"Call Sign","# Prev. Cont.","Name","City","State","Country","Mode","Time","Signal","Comment"};
typedef struct 
	{
	double LowerLim;
	double UpperLim;
	}FLims;

FLims	FreqLims[25] = {{1.8,2.0},{3.5,4.0},{7.0,7.3},{10.0,10.15},{14.0,14.35},
							 {18.068,18.168},{21.0,21.45},{24.89,24.99},{28.0,29.7},
							 {50.0,54.0},{144.0,148.0},{222.0,225.0},{420.0,450.0},
							 {902.0,928.0},{1240.0,1300.0},{2300.0,2450.0},{5650.0,5925.0},
							 {10000.0,10500.0},{24000.0,24250.0},{47000.0,47200.0},{755000.0,81000.0},
							 {119980.0,120020.0},{142000.0,149000.0},{241000.0,250000.0}};
/////////////////////////////////////////////////////////////////////////////
// CLoggerView
BOOL	CLoggerView::fReverseSortOrder	= FALSE;
HWND	CLoggerView::hListWnd				= NULL;

IMPLEMENT_DYNCREATE(CLoggerView, CFormView)

BEGIN_MESSAGE_MAP(CLoggerView, CFormView)
	//{{AFX_MSG_MAP(CLoggerView)
	ON_WM_PAINT()
	ON_EN_KILLFOCUS(IDC_CALLSIGN, OnKillfocusCallsign)
	ON_EN_KILLFOCUS(IDC_PREVCONT, OnKillfocusPrevcont)
	ON_EN_KILLFOCUS(IDC_REGION, OnKillfocusRegion)
	ON_CBN_SELCHANGE(IDC_MODELIST, OnSelchangeModelist)
	ON_CBN_EDITCHANGE(IDC_MODELIST, OnEditchangeModelist)
	ON_EN_KILLFOCUS(IDC_SIGNAL_R, OnKillfocusSignalR)
	ON_EN_KILLFOCUS(IDC_SIGNAL_S, OnKillfocusSignalS)
	ON_EN_KILLFOCUS(IDC_SIGNAL_T, OnKillfocusSignalT)
	ON_BN_CLICKED(IDC_COMMIT, OnCommit)
	ON_EN_KILLFOCUS(IDC_COMMENT, OnKillfocusComment)
	ON_EN_CHANGE(IDC_CALLSIGN, OnChangeCallsign)
	ON_NOTIFY(LVN_COLUMNCLICK, IDC_DBLIST, OnColumnclickDblist)
	ON_NOTIFY(NM_CLICK, IDC_DBLIST, OnClickDblist)
	ON_WM_DESTROY()
	ON_EN_KILLFOCUS(IDC_NAME, OnKillfocusName)
	ON_EN_KILLFOCUS(IDC_CITY, OnKillfocusCity)
	ON_NOTIFY(LVN_KEYDOWN, IDC_DBLIST, OnKeydownDblist)
	ON_CBN_SELCHANGE(IDC_BAND, OnSelchangeBand)
	ON_EN_KILLFOCUS(IDC_FREQ, OnKillfocusFreq)
	ON_CBN_SELCHANGE(IDC_STATE, OnSelchangeState)
	ON_EN_KILLFOCUS(IDC_NUMXMIT, OnKillfocusNumxmit)
	ON_CBN_SELCHANGE(IDC_CLASS, OnSelchangeClass)
	ON_CBN_SELCHANGE(IDC_SECTION, OnSelchangeSection)
	ON_CBN_KILLFOCUS(IDC_BAND, OnKillfocusBand)
	ON_CBN_KILLFOCUS(IDC_CLASS, OnKillfocusClass)
	ON_CBN_KILLFOCUS(IDC_SECTION, OnKillfocusSection)
	ON_CBN_EDITCHANGE(IDC_STATE, OnEditchangeState)
	ON_BN_CLICKED(IDC_CHGTIME, OnChgtime)
	ON_BN_CLICKED(IDC_EDITCUR, OnEditcur)
	ON_BN_CLICKED(IDC_CANCEL, OnCancel)
	ON_BN_CLICKED(IDC_QSL, OnQsl)
	ON_BN_CLICKED(IDC_QSL_SENT, OnQslSent)
	ON_CBN_SELCHANGE(IDC_QSLTYP, OnSelchangeQsltyp)
	ON_CBN_KILLFOCUS(IDC_QSLTYP, OnKillfocusQsltyp)
	ON_EN_KILLFOCUS(IDC_XMITPWR, OnKillfocusXmitpwr)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLoggerView construction/destruction

CLoggerView::CLoggerView()
	: CFormView(CLoggerView::IDD)
{
	//{{AFX_DATA_INIT(CLoggerView)
	//}}AFX_DATA_INIT
	numCols = NUMCOLS;
	r=5;
	s=9;
	t=9;
	DefModeIx = 3;
}

CLoggerView::~CLoggerView()
{
}

void CLoggerView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLoggerView)
	DDX_Control(pDX, IDC_DBLIST, m_DbList);
	//}}AFX_DATA_MAP
}

BOOL CLoggerView::PreCreateWindow(CREATESTRUCT& cs)
{
	BOOL bRet = CFormView::PreCreateWindow(cs);
	return bRet;
}

void CLoggerView::OnInitialUpdate()
{  
	char text[50];

	CFormView::OnInitialUpdate();
	
	ResizeParentToFit();
	GetParent( )->ShowWindow(SW_SHOWMAXIMIZED);	
	theApp.pView = this;
	hListWnd = m_DbList.GetSafeHwnd();

	m_DbList.SetExtendedStyle(m_DbList.GetExtendedStyle()|LVS_EX_FULLROWSELECT);	
	GetColWidths();
	SetHeaders();

	FillGridFromDB();
	GetDlgItem (IDC_EDITCUR)->EnableWindow (FALSE);

	CurRec.iMode = DefModeIx;

	SendDlgItemMessage (IDC_MODELIST, CB_GETLBTEXT,CurRec.iMode, (LPARAM)(LPCSTR)text);
	CurRec.Mode = text;

	SetDlgItemText (IDC_MODELIST,text);

}

void CLoggerView::FillGridFromDB()
	{
	CString s;
	COleDateTime dt;
	LogRec Rec;
	
	double Freq = CurRec.Freq;
	int bandIx, ModeIx;
	CString band, mode;

	bandIx = CurRec.BandIx;
	ModeIx = CurRec.iMode;
	band = CurRec.Band;
	mode = CurRec.Mode;

	CurRec.ClearRec();

	CurRec.BandIx = bandIx;;
	CurRec.iMode = ModeIx;
	CurRec.Band = band;
	CurRec.Mode = mode;
	CurRec.Freq = Freq;
//	CurRec.ClearRec();
//	CurRec.iMode = DefModeIx;
//	SendDlgItemMessage (IDC_MODELIST, CB_GETLBTEXT,CurRec.iMode, (LPARAM)(LPCSTR)text);
//	CurRec.Mode = text;

	if (theApp.pRecs)
		{
		delete theApp.pRecs;
		theApp.pRecs = NULL;
		theApp.numRecs = 0;
		}
	m_DbList.DeleteAllItems ();
	theApp.pDbase->GetAllLogRecs ((long &)theApp.numRecs, theApp.pRecs);
	if (!theApp.numRecs || !theApp.pRecs)
		return;
	FillGrid();
	ShowSet();

	}//FillGridFromDB

void CLoggerView::FillGrid()
	{
	CString s;
	COleDateTime dt;
	LogRec Rec;
	
	m_DbList.DeleteAllItems ();
	for (int i = 0; i < theApp.numRecs; i++)
		{
		Rec = theApp.pRecs->GetAt (i);
		m_DbList.InsertItem(i, Rec.CallSign);
		m_DbList.SetItemText (i, 0, Rec.CallSign);
		s.Format ("%d", Rec.nContacts);
		m_DbList.SetItemText (i, 1, s);
		m_DbList.SetItemText (i, 2, Rec.Name);
		m_DbList.SetItemText (i, 3, Rec.City);
		m_DbList.SetItemText (i, 4, Rec.State);
		m_DbList.SetItemText (i, 5, Rec.Country);
		m_DbList.SetItemText (i, 6, Rec.Mode);
		dt = TimeStampToCOleDateTime (JDateToTimeStamp (Rec.UTC_Time));
		s = dt.Format ("%d %B, %Y %H:%M:%S");
		m_DbList.SetItemText (i, 7, s);
		m_DbList.SetItemText (i, 8, Rec.Sig_Rep);
		m_DbList.SetItemText (i, 9, Rec.Comment);
		m_DbList.SetItemData (i,i);
		}	

	}//FillGrid


void CLoggerView::PutColWidths( )
{
	CString sText;
	CString sN;

	sText = "";
	
	for (int cnt = 0; cnt < NUMCOLS; cnt++)
		{
		sN.Format("%d", m_DbList.GetColumnWidth(cnt));
		sText += sN;
		sText += '\t';
		}
	theApp.WriteProfileString("Logger", "LogDBColWidths", sText);
}

void CLoggerView::GetColWidths( )
{
	CString sText;
	CString sS1;
	int cnt = 0;
	char* pChar;

	ZeroMemory(ColWidths, sizeof(ColWidths));

	sText = theApp.GetProfileString("Logger","LogDBColWidths",  "");
	
	for ( ; ; )
		{
		pChar = strchr(sText, '\t');
		if (pChar == NULL) 
			break;
		*pChar = 0;
		sS1 = pChar + 1;
		sText.ReleaseBuffer( );
		ColWidths[cnt] = atoi(sText);
		sText = sS1;
		++cnt;
		}
}

void CLoggerView::SetHeaders( )
{
	CDC* pDC;
	int Width, Cnt;

	pDC = GetDC( );
	for (Cnt = 0; Cnt < NUMCOLS; Cnt++)
		{
		if ((Width = ColWidths[Cnt]) <= 0)
			Width = pDC->GetTextExtent(Titles[Cnt]).cx;
		m_DbList.InsertColumn(Cnt, Titles[Cnt], LVCFMT_LEFT, Width);
		}

	// hidden column for hidden index number
	m_DbList.AddColumn("", Cnt);	
	m_DbList.SetColumnWidth (Cnt, 1);
}

/////////////////////////////////////////////////////////////////////////////
// CLoggerView diagnostics

#ifdef _DEBUG
void CLoggerView::AssertValid() const
{
	CFormView::AssertValid();
}

void CLoggerView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CLoggerDoc* CLoggerView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CLoggerDoc)));
	return (CLoggerDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CLoggerView message handlers

	// Set the status indicators and state data to proper default values

// display the current time, countdown time, and paint the current state for all indicators
void CLoggerView::OnPaint() 
{
	CPaintDC dc(this);
}


void CLoggerView::EnableControls( )
{
	// These set the RUN control buttons
//	GetDlgItem(IDC_MAIN_RUN)->EnableWindow(theApp.RunState != green);
}


/////////////////////////////////////////////////////////////////////////////
void CLoggerView::ShowSet( )
{
	CString str;

	SetDlgItemText (IDC_CALLSIGN, CurRec.CallSign);
	SetDlgItemInt (IDC_PREVCONT,CurRec.nContacts,FALSE);

	SetDlgItemText (IDC_NAME, CurRec.Name);
	CurRec.BandIx = SendDlgItemMessage (IDC_BAND, CB_SELECTSTRING,-1, (LPARAM)(LPCSTR)CurRec.Band);
	str.Format ("%8.3f",CurRec.Freq);
	SetDlgItemText (IDC_FREQ, str);

	SetDlgItemText (IDC_CITY, CurRec.City);
	CurRec.StateIx = SendDlgItemMessage (IDC_STATE, CB_SELECTSTRING,-1, (LPARAM)(LPCSTR)CurRec.State);
	if (CurRec.StateIx == -1)
		SetDlgItemText (IDC_STATE, CurRec.State);

	int numState = theApp.pDbase->GetNumberofStates();
	SetDlgItemInt (IDC_STATESWORKED, numState, FALSE);

	int total = theApp.pDbase->GetTotal();
	SetDlgItemInt (IDC_TOTALCONT, total, FALSE);
		
	SetDlgItemText (IDC_REGION, CurRec.Country);
	CurRec.iMode = SendDlgItemMessage (IDC_MODELIST, CB_SELECTSTRING,-1, (LPARAM)(LPCSTR)CurRec.Mode);
	if (CurRec.iMode == -1)
		SetDlgItemText (IDC_MODELIST, CurRec.Mode);

	SetDlgItemInt (IDC_NUMXMIT, CurRec.numXmit, FALSE);
	CurRec.ixClass = SendDlgItemMessage (IDC_CLASS, CB_SELECTSTRING,-1, (LPARAM)(LPCSTR)CurRec.Class);
	if (CurRec.ixClass == -1)
		SetDlgItemText (IDC_CLASS, CurRec.Class);
	CurRec.ixSection = SendDlgItemMessage (IDC_SECTION, CB_SELECTSTRING,-1, (LPARAM)(LPCSTR)CurRec.Section);
	if (CurRec.ixSection == -1)
		SetDlgItemText (IDC_SECTION, CurRec.Section);
	
	sscanf ((LPCSTR)CurRec.Sig_Rep, "%d:%d:%d",&r,&s,&t);
	SetDlgItemInt (IDC_SIGNAL_R, r, FALSE);
	SetDlgItemInt (IDC_SIGNAL_S, s, FALSE);
	SetDlgItemInt (IDC_SIGNAL_T, t, FALSE);

	COleDateTime dt = TimeStampToCOleDateTime (JDateToTimeStamp (CurRec.UTC_Time));
	CString date = dt.Format ("%d %B, %Y %H:%M:%S");
	SetDlgItemText (IDC_UTC, date);
	SetDlgItemText (IDC_COMMENT, CurRec.Comment);

	SendDlgItemMessage (IDC_QSL,BM_SETCHECK,CurRec.bQSL, 0l);
	SendDlgItemMessage (IDC_QSL_SENT,BM_SETCHECK,CurRec.bQSL_Sent, 0l);
	if (CurRec.XmitPower < 0 || CurRec.XmitPower > 1000)
		CurRec.XmitPower = 0;
	SetDlgItemInt (IDC_XMITPWR, CurRec.XmitPower, FALSE);
	if (CurRec.QSLType >= EQSLCC && CurRec.QSLType <= VIABURO)
		SendDlgItemMessage (IDC_QSLTYP, CB_SETCURSEL ,(int)CurRec.QSLType,0l);
	else
		SetDlgItemText (IDC_QSLTYP, "");



}



void CLoggerView::OnChangeCallsign() 
{
	CString s, cunt;

	GetDlgItemText (IDC_CALLSIGN, s);
	s.MakeUpper();
	cunt = theApp.Countries->FindCountry (s);
	if (cunt.GetLength())
		SetDlgItemText (IDC_REGION, cunt);
			
}
void CLoggerView::OnKillfocusCallsign() 
{
	LogRec	*pRec;
	GetDlgItemText (IDC_CALLSIGN, CurRec.CallSign);
	pRec = theApp.pDbase->GetRecByCallSign (CurRec.CallSign);

	if (pRec)
		{
		if (pRec->CallSign.GetLength())
			{
			CurRec = *pRec;
			CurRec.UTC_Time = GetCurrentJdTime();
			CurRec.RecTime = COleDateTime::GetCurrentTime();
			CurRec.nContacts = theApp.pDbase->GetNumContacts (pRec->CallSign);
			ShowSet();
			}
		delete pRec;
		}
	else
		{
		CString CallSign = CurRec.CallSign;
		//!!
		double Freq = CurRec.Freq;
		int bandIx, ModeIx;
		CString band, mode;

		bandIx = CurRec.BandIx;
		ModeIx = CurRec.iMode;
		band = CurRec.Band;
		mode = CurRec.Mode;

		CurRec.ClearRec();

		CurRec.BandIx = bandIx;;
		CurRec.iMode = ModeIx;
		CurRec.Band = band;
		CurRec.Mode = mode;
		CurRec.Freq = Freq;
//		CurRec.ClearRec();
		CurRec.CallSign = CallSign;
		CurRec.nContacts = 1;
//	CurRec.iMode = DefModeIx;
//	SendDlgItemMessage (IDC_MODELIST, CB_GETLBTEXT,CurRec.iMode, (LPARAM)(LPCSTR)text);
//	CurRec.Mode = text;
		CurRec.Country = theApp.Countries->FindCountry (CurRec.CallSign);
		ShowSet();
		}
}

void CLoggerView::OnKillfocusPrevcont() 
{
	CurRec.nContacts = GetDlgItemInt (IDC_PREVCONT,NULL,FALSE);
	CurRec.nContacts++;
}

void CLoggerView::OnKillfocusRegion() 
{
	GetDlgItemText (IDC_REGION, CurRec.Country);
}

void CLoggerView::OnKillfocusName() 
{
	GetDlgItemText (IDC_NAME, CurRec.Name);
}

void CLoggerView::OnSelchangeBand() 
{
char text[255];
CString str;

CurRec.BandIx = SendDlgItemMessage (IDC_BAND, CB_GETCURSEL,0,0l);
if (CurRec.BandIx > -1)
	{
	SendDlgItemMessage (IDC_BAND, CB_GETLBTEXT,CurRec.BandIx, (LPARAM)(LPCSTR)text);
	CurRec.Band = text;
	//start freq at lower limit
	CurRec.Freq = FreqLims[CurRec.BandIx].LowerLim;
	if (CurRec.iMode == 3)
		CurRec.Freq += 0.07;
	str.Format ("%4.8f",CurRec.Freq);
	SetDlgItemText (IDC_FREQ, str);
	} 
}

void CLoggerView::OnKillfocusBand() 
{
	CString str;
	int ix;
	GetDlgItemText (IDC_BAND, str);
	ix = SendDlgItemMessage (IDC_BAND, CB_SELECTSTRING,-1, (LPARAM)(LPCSTR)str);
		if (ix > -1)
			{
			CurRec.Band = str;
			CurRec.BandIx = ix;
			//start freq at lower limit
			CurRec.Freq = FreqLims[CurRec.BandIx].LowerLim;
			if (CurRec.iMode == 3)
				CurRec.Freq += 0.07;
			str.Format ("%4.8f",CurRec.Freq);
			SetDlgItemText (IDC_FREQ, str);
			}
}

void CLoggerView::OnKillfocusFreq() 
{
CString s;
	GetDlgItemText (IDC_FREQ, s);
	CurRec.Freq = atof (s);
	if (CurRec.BandIx > -1)
		{
		if (CurRec.Freq < FreqLims[CurRec.BandIx].LowerLim ||
			 CurRec.Freq > FreqLims[CurRec.BandIx].UpperLim)
			{
			MessageBox ("The frequency you entered is out of band!","User Error",MB_OK|MB_SYSTEMMODAL);
			GetDlgItem (IDC_FREQ)->SetFocus();
			SendDlgItemMessage (IDC_FREQ, EM_SETSEL, 0,(LPARAM)-1l);
			}
		}
		
}

void CLoggerView::OnSelchangeState() 
{
char text[255];

CurRec.StateIx = SendDlgItemMessage (IDC_STATE, CB_GETCURSEL,0,0l);
if (CurRec.StateIx > -1)
	{
	SendDlgItemMessage (IDC_STATE, CB_GETLBTEXT,CurRec.StateIx, (LPARAM)(LPCSTR)text);
	CurRec.State = text;
	} 
}

void CLoggerView::OnEditchangeState() 
{
char text[255];

CurRec.StateIx = SendDlgItemMessage (IDC_STATE, CB_GETCURSEL,0,0l);
if (CurRec.StateIx > -1)
	{
	SendDlgItemMessage (IDC_STATE, CB_GETLBTEXT,CurRec.StateIx, (LPARAM)(LPCSTR)text);
	CurRec.State = text;
	} 
else
	GetDlgItemText (IDC_STATE, CurRec.State);
}

void CLoggerView::OnKillfocusNumxmit() 
{
	CurRec.numXmit = GetDlgItemInt (IDC_NUMXMIT, NULL, FALSE);
	if (CurRec.numXmit < 1 || CurRec.numXmit > 50)
		CurRec.numXmit = 1;
}

void CLoggerView::OnSelchangeClass() 
{
char text[255];

CurRec.ixClass = SendDlgItemMessage (IDC_CLASS, CB_GETCURSEL,0,0l);
if (CurRec.ixClass > -1)
	{
	SendDlgItemMessage (IDC_CLASS, CB_GETLBTEXT,CurRec.ixClass, (LPARAM)(LPCSTR)text);
	CurRec.Class = text;
	} 
}

void CLoggerView::OnKillfocusClass() 
{
	CString str;
	int ix;
	GetDlgItemText (IDC_CLASS, str);
	ix = SendDlgItemMessage (IDC_CLASS, CB_SELECTSTRING,-1, (LPARAM)(LPCSTR)str);
		if (ix > -1)
			{
			CurRec.Class = str;
			CurRec.ixClass = ix;
			}
}

void CLoggerView::OnSelchangeSection() 
{
char text[255];

CurRec.ixSection = SendDlgItemMessage (IDC_SECTION, CB_GETCURSEL,0,0l);
if (CurRec.ixSection > -1)
	{
	SendDlgItemMessage (IDC_SECTION, CB_GETLBTEXT,CurRec.ixSection, (LPARAM)(LPCSTR)text);
	CurRec.Section = text;
	} 
}

void CLoggerView::OnKillfocusSection() 
{
	CString str;
	int ix;
	GetDlgItemText (IDC_SECTION, str);
	ix = SendDlgItemMessage (IDC_SECTION, CB_SELECTSTRING,-1, (LPARAM)(LPCSTR)str);
		if (ix > -1)
			{
			CurRec.Section = str;
			CurRec.ixSection = ix;
			}
}

void CLoggerView::OnKillfocusCity() 
{
	GetDlgItemText (IDC_CITY, CurRec.City);
}

void CLoggerView::OnSelchangeModelist() 
{
char text[255];

CurRec.iMode = SendDlgItemMessage (IDC_MODELIST, CB_GETCURSEL,0,0l);
if (CurRec.iMode > -1)
	{
	DefModeIx = CurRec.iMode;
	SendDlgItemMessage (IDC_MODELIST, CB_GETLBTEXT,CurRec.iMode, (LPARAM)(LPCSTR)text);
	CurRec.Mode = text;
	} 
}

void CLoggerView::OnEditchangeModelist() 
{
char text[255];

CurRec.iMode = SendDlgItemMessage (IDC_MODELIST, CB_GETCURSEL,0,0l);
if (CurRec.iMode > -1)
	{
	SendDlgItemMessage (IDC_MODELIST, CB_GETLBTEXT,CurRec.iMode, (LPARAM)(LPCSTR)text);
	CurRec.Mode = text;
	} 
else
	GetDlgItemText (IDC_MODELIST, CurRec.Mode);
}

void CLoggerView::OnKillfocusSignalR() 
{
	r = GetDlgItemInt (IDC_SIGNAL_R, NULL, FALSE);
	if (r < 0 || r > 5)
		r = 5;

}

void CLoggerView::OnKillfocusSignalS() 
{
	s = GetDlgItemInt (IDC_SIGNAL_S, NULL, FALSE);
	if (s < 0 || s > 9)
		s = 9;
}

void CLoggerView::OnKillfocusSignalT() 
{
	t = GetDlgItemInt (IDC_SIGNAL_T, NULL, FALSE);
	if (t < 0 || t > 9)
		t = 9;
}

void CLoggerView::OnKillfocusComment() 
{
	GetDlgItemText (IDC_COMMENT, CurRec.Comment);
}

void CLoggerView::OnCommit() 
{
	
	if (GetDlgItem (IDC_COMMIT) != GetFocus())
		{
		((CDialog *)this)->NextDlgCtrl();
		return;
		}
	if (!CurRec.CallSign.GetLength())
		return;

	CurRec.nContacts = theApp.pDbase->GetNumContacts (CurRec.CallSign);
	CurRec.nContacts++;

	CurRec.Sig_Rep.Format ("%d:%d:%d",r,s,t);
	if (CurDate.GetStatus() || CurDate.m_dt < 10.0)
		{
		CurRec.UTC_Time = GetCurrentJdTime();
		CurRec.RecTime = CurrentGmtTime();
		}
	else
		{
		CurRec.RecTime = CurDate;
		CurRec.UTC_Time = CurDate.m_dt + 2415018.5; //Add jd ( 12, 30, 1899, 0, 0, 0, 0 );
		//now we've used it so zap it
		CurDate.SetStatus (COleDateTime::invalid);
		}
	GetDlgItemText (IDC_REGION, CurRec.Country);

	GetDlgItemText (IDC_BAND, CurRec.Band);
	GetDlgItemText (IDC_STATE, CurRec.State);
	GetDlgItemText (IDC_CLASS, CurRec.Class);
	GetDlgItemText (IDC_SECTION, CurRec.Section);
	GetDlgItemText (IDC_MODELIST, CurRec.Mode);

	//CheckRec (CurRec)
	theApp.pDbase->PutNewLogEntry (CurRec);
	if (!theApp.pRecs)	
		theApp.pRecs = new LRecArray;

	theApp.pRecs->Add (CurRec);
	theApp.numRecs++;
	FillGrid();
	
	double Freq = CurRec.Freq;
	int bandIx, ModeIx;
	CString band, mode;

	bandIx = CurRec.BandIx;
	ModeIx = CurRec.iMode;
	band = CurRec.Band;
	mode = CurRec.Mode;

	CurRec.ClearRec();

	CurRec.BandIx = bandIx;;
	CurRec.iMode = ModeIx;
	CurRec.Band = band;
	CurRec.Mode = mode;
	CurRec.Freq = Freq;
	GetDlgItem (IDC_EDITCUR)->EnableWindow (FALSE);
	ShowSet();
}

void CLoggerView::OnCancel() 
{
	double Freq = CurRec.Freq;
	int bandIx, ModeIx;
	CString band, mode;
//	char text[50];

	GetDlgItem (IDC_EDITCUR)->EnableWindow (FALSE);
	bandIx = CurRec.BandIx;
	ModeIx = CurRec.iMode;
	band = CurRec.Band;
	mode = CurRec.Mode;

	CurRec.ClearRec();
	CurRec.BandIx = bandIx;;
	CurRec.iMode = ModeIx;
	CurRec.Band = band;
	CurRec.Mode = mode;
	CurRec.Freq = Freq;

	ShowSet();
}



void CLoggerView::OnColumnclickDblist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	//	Properly cast the Notification Message Header
	NM_LISTVIEW * pListViewStruct = ( NM_LISTVIEW * ) pNMHDR;

	//	Which Column?
	int nCol = pListViewStruct->iSubItem;

	m_DbList.SortItems (ListViewCompareProc, nCol );
	fReverseSortOrder = !fReverseSortOrder;
	*pResult = 0;
}

void CLoggerView::OnClickDblist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	POSITION pos = m_DbList.GetFirstSelectedItemPosition();
	if (!pos)
		return;
	int ix = m_DbList.GetNextSelectedItem (pos);
	if (ix < 0)
		return;
	int ArIx = m_DbList.GetItemData (ix);
	if (ArIx < 0 || ArIx >= theApp.numRecs)
		return;
	CurRec = theApp.pRecs->GetAt (ArIx);
	ShowSet();
	GetDlgItem (IDC_EDITCUR)->EnableWindow (TRUE);

	*pResult = 0;
}

void CLoggerView::OnDestroy() 
{
	PutColWidths();
	CFormView::OnDestroy();
}

int CALLBACK CLoggerView::ListViewCompareProc ( LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort )

	{
	int			nResult = 0;

	int			ixParam1;
	int			ixParam2;

	char			szText1 [ MAX_PATH + 1 ];
	char			szText2 [ MAX_PATH + 1 ];

	LV_FINDINFO	lvFindInfo = { LVFI_PARAM };

	if ( ! hListWnd ) return 0;

	lvFindInfo.flags = LVFI_PARAM;

	lvFindInfo.lParam = lParam1;	ixParam1 = ListView_FindItem ( hListWnd, -1, &lvFindInfo );
	lvFindInfo.lParam = lParam2;	ixParam2 = ListView_FindItem ( hListWnd, -1, &lvFindInfo );

	ListView_GetItemText ( hListWnd, ixParam1, lParamSort, szText1, sizeof szText1 - 1 );
	ListView_GetItemText ( hListWnd, ixParam2, lParamSort, szText2, sizeof szText2 - 1 );

	szText1 [ sizeof szText1 - 1 ] = szText2 [ sizeof szText2 - 1 ] = '\0';

	nResult = strcmp ( szText1, szText2 );

	return fReverseSortOrder ? -nResult : +nResult;

	}	//	ListViewCompareProc()





void CLoggerView::OnKeydownDblist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_KEYDOWN* pLVKeyDow = (LV_KEYDOWN*)pNMHDR;
	*pResult = 0;

	int nItemCount = m_DbList.GetItemCount( );
	POSITION pos = m_DbList.GetFirstSelectedItemPosition();
	if (!pos)
		return;
	int ix = m_DbList.GetNextSelectedItem (pos);

	if (pLVKeyDow->wVKey == VK_DELETE)
		{
		LogRec rec;
		int ArIx = m_DbList.GetItemData (ix);
		if (ArIx < 0 || ArIx >= theApp.numRecs)
			return;
		rec = theApp.pRecs->GetAt (ArIx);

		if (rec.RecKey.GetLength())
			{
			if (MessageBox ("Are you sure?","Confirm",MB_YESNO) == IDYES)
				theApp.pDbase->DeleteRecbyKey (rec.RecKey);
			}
		FillGridFromDB();

	double Freq = CurRec.Freq;
	int bandIx, ModeIx;
	CString band, mode;

	bandIx = CurRec.BandIx;
	ModeIx = CurRec.iMode;
	band = CurRec.Band;
	mode = CurRec.Mode;

	CurRec.ClearRec();

	CurRec.BandIx = bandIx;;
	CurRec.iMode = ModeIx;
	CurRec.Band = band;
	CurRec.Mode = mode;
	CurRec.Freq = Freq;
//		CurRec.ClearRec();
		ShowSet();
		return;
		}//delete

	if (pLVKeyDow->wVKey != VK_UP && pLVKeyDow->wVKey != VK_DOWN)
		return;
	if (pLVKeyDow->wVKey == VK_UP)
		ix--;
	else 
		ix++;
	if (ix < 0 || ix >= nItemCount)
		return;
	int ArIx = m_DbList.GetItemData (ix);
	if (ArIx < 0 || ArIx >= theApp.numRecs)
		return;
	CurRec = theApp.pRecs->GetAt (ArIx);
	ShowSet();
		
}


void CLoggerView::OnChgtime() 
{
	AltDay cDlg;
	COleDateTime dt;

	cDlg.m_Date = CurrentGmtTime();
	dt = CurrentGmtTime();
	cDlg.m_time.SetTime (dt.GetHour(),dt.GetMinute(), dt.GetSecond());

	if (cDlg.DoModal() == IDOK)
		{
		CurDate.SetDateTime (cDlg.m_Date.GetYear(), cDlg.m_Date.GetMonth(), cDlg.m_Date.GetDay(),
								  cDlg.m_time.GetHour(), cDlg.m_time.GetMinute(), cDlg.m_time.GetSecond());
		CurDate.SetStatus (COleDateTime::valid);
		}
	else
		CurDate.SetStatus (COleDateTime::invalid);

//	COleDateTime dt = TimeStampToCOleDateTime (JDateToTimeStamp (CurRec.UTC_Time));
	CString date = CurDate.Format ("%d %B, %Y %H:%M:%S");
	SetDlgItemText (IDC_UTC, date);
}

void CLoggerView::OnEditcur() 
{
	if (GetDlgItem (IDC_EDITCUR) != GetFocus())
		{
		((CDialog *)this)->NextDlgCtrl();
		return;
		}
	if (!CurRec.CallSign.GetLength())
		return;

	CurRec.Sig_Rep.Format ("%d:%d:%d",r,s,t);

	GetDlgItemText (IDC_REGION, CurRec.Country);

	GetDlgItemText (IDC_BAND, CurRec.Band);
	GetDlgItemText (IDC_STATE, CurRec.State);
	GetDlgItemText (IDC_CLASS, CurRec.Class);
	GetDlgItemText (IDC_SECTION, CurRec.Section);
	GetDlgItemText (IDC_MODELIST, CurRec.Mode);

	if (CurDate.GetStatus() != COleDateTime::invalid && CurDate.m_dt > 100.0)
		{
		CurRec.RecTime = CurDate;
		CurRec.UTC_Time = CurDate.m_dt + 2415018.5; //Add jd ( 12, 30, 1899, 0, 0, 0, 0 );
		}
	//CheckRec (CurRec)
	theApp.pDbase->EditLogEntry (CurRec);

	FillGridFromDB();
	
	double Freq = CurRec.Freq;
	int bandIx, ModeIx;
	CString band, mode;

	bandIx = CurRec.BandIx;
	ModeIx = CurRec.iMode;
	band = CurRec.Band;
	mode = CurRec.Mode;

	CurRec.ClearRec();

	CurRec.BandIx = bandIx;;
	CurRec.iMode = ModeIx;
	CurRec.Band = band;
	CurRec.Mode = mode;
	CurRec.Freq = Freq;
	ShowSet();
	

	GetDlgItem (IDC_EDITCUR)->EnableWindow (FALSE);
}

void CLoggerView::OnQsl() 
{
	if (SendDlgItemMessage (IDC_QSL,BM_GETCHECK,0, 0l))
		CurRec.bQSL = true;
	else
		CurRec.bQSL = false;
}

void CLoggerView::OnQslSent() 
{

	if (SendDlgItemMessage (IDC_QSL_SENT,BM_GETCHECK,0, 0l))
		CurRec.bQSL_Sent = true;
	else
		CurRec.bQSL_Sent = false;
}

void CLoggerView::OnSelchangeQsltyp() 
{
char text[255];
CString str;

CurRec.QSLType = (QSLTYPE)SendDlgItemMessage (IDC_QSLTYP, CB_GETCURSEL,0,0l);
if (CurRec.QSLType > -1)
	{
	SendDlgItemMessage (IDC_QSLTYP, CB_GETLBTEXT,CurRec.QSLType, (LPARAM)(LPCSTR)text);
	} 
}

void CLoggerView::OnKillfocusQsltyp() 
{
char text[255];
CString str;

CurRec.QSLType = (QSLTYPE)SendDlgItemMessage (IDC_QSLTYP, CB_GETCURSEL,0,0l);
if (CurRec.QSLType > -1)
	{
	SendDlgItemMessage (IDC_QSLTYP, CB_GETLBTEXT,CurRec.QSLType, (LPARAM)(LPCSTR)text);
	} 
}

void CLoggerView::OnKillfocusXmitpwr() 
{
	CurRec.XmitPower = GetDlgItemInt (IDC_XMITPWR, NULL, FALSE);
}
